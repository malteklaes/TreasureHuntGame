package View;

import clientMap.IMap;

/**
 * to display all game relevant information like map and meta data (game round,
 * game strategy, ...)
 * 
 * @author Malte
 *
 */
public interface IView {

	/**
	 * main function to display all relevant information an pipe them to the
	 * output/console
	 */
	public void show(String information);

	/**
	 * major task is to print the freshly updated game map, but also display some
	 * additional information like game round, game strategy and other conditions
	 * 
	 * @throws DisplayException
	 */
	public String drawGameMap(IMap gameMap) throws DisplayException;

}
