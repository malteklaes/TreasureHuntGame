package client.main;

/**
 * 
 * regulates the interaction status between server and client and the result of
 * a game
 * 
 * @author Malte
 *
 */
public enum EInteractionState {
	GeneralFailure, ServerFailure, NormalTerminated_WON, NormalTerminated_LOST
}
