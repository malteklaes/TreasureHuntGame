package clientMap;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientFullMap implements IMap {

	private static Logger logger = LoggerFactory.getLogger(ClientFullMap.class);

	private I2DGrid basicFullGrid;
	private Coordinate fortCoordinate;
	private int max_x_size = 0;
	private int max_y_size = 0;

	/**
	 * @param fortCoordinate
	 */
	public ClientFullMap(List<MapNode> nodeList) {
		basicFullGrid = new MapGrid(nodeList);
		this.setUpMetaData();
		logger.debug("ClientFullMap was set up with all meta data.");
	}

	/**
	 * @param basicFullGrid
	 * @param max_x_size
	 * @param max_y_size
	 */
	public ClientFullMap(I2DGrid basicFullGrid, int max_x_size, int max_y_size) {
		this.basicFullGrid = basicFullGrid;
		this.max_x_size = max_x_size;
		this.max_y_size = max_y_size;
		this.setUpMetaData();
		logger.debug("ClientFullMap was set up with all meta data.");
	}

	/**
	 * updates real coordinates of the given mapGrid
	 */
	private void setUpMetaData() {
		logger.debug("setting up ClientFullMap with all meta data.");
		int x_dim = 0;
		int y_dim = 0;
		for (Map.Entry<Coordinate, MapNode> elem : this.basicFullGrid.getGrid().entrySet()) {
			x_dim = elem.getValue().getCoordinate().getX_coord();
			y_dim = elem.getValue().getCoordinate().getY_coord();
			if (x_dim > this.max_x_size)
				this.max_x_size = x_dim;
			if (y_dim > this.max_y_size)
				this.max_y_size = y_dim;
			if (elem.getValue().getFortState() == EFortState.MyFortPresent)
				this.fortCoordinate = elem.getKey();
		}
		this.max_x_size++; // because coordinates starts at 0
		this.max_y_size++;
	}

	@Override
	public IMap createMap() {
		return this;
	}

	@Override
	public MapNode readMapEntry(Coordinate coordinate) {
		logger.debug("ClientFullMap entry with coordinate {} will be read.", coordinate);
		if (this.basicFullGrid.getField(coordinate) == null) {
			logger.warn("coordinate could not been found in client full map!");
			throw new MapException("coordinate could not been found in client full map!");
		}
		return this.basicFullGrid.getField(coordinate);
	}

	@Override
	public I2DGrid getGrid() {
		return this.basicFullGrid;
	}

	@Override
	public Coordinate getFort() {
		return this.fortCoordinate;
	}

	@Override
	public int getXDimension() {
		return this.max_x_size;
	}

	@Override
	public int getYDimension() {
		return this.max_y_size;
	}

	@Override
	public IMap deepCopy() {
		return new ClientFullMap(this.basicFullGrid.deepCopy(), this.max_x_size, this.max_y_size);
	}

	@Override
	public String toString() {
		String gras = "\033[0;32m" + "\uD83C\uDF33" + "\033[0m "; // green
		String mountain = "\033[0;31m" + "\u26F0" + "\033[0m "; // red
		String water = "\033[0;34m" + "\uD83C\uDF0A" + "\033[0m "; // blue
		String ownFort = "\033[1;37m" + "\uD83C\uDFF0" + "\033[0m "; // white
		String enemyFort = "\033[1;37m" + "\uD83C\uDFF0" + "\033[0m "; // white
		String figure = "\033[1;36m" + "F" + "\033[0m "; // own figure

		String result = "";
		Coordinate drawCoordinate = new Coordinate(0, 0);
		for (int y = 0; y <= max_y_size; y++) {
			for (int x = 0; x <= max_x_size; x++) {
				drawCoordinate.setX_coord(x);
				drawCoordinate.setY_coord(y);
				if (this.basicFullGrid.getField(drawCoordinate) != null) {
					ETerrainType terrainType = this.basicFullGrid.getField(drawCoordinate).getTerrainType();
					if (this.basicFullGrid.getField(drawCoordinate).getFortState() == EFortState.NoOrUnknownFortState
							&& this.basicFullGrid.getField(drawCoordinate)
									.getPlayerPositionState() == EPlayerPositionState.NoPlayerPresent) {
						switch (terrainType) {
						case Gras:
							result += gras;
							break;
						case Mountain:
							result += mountain;
							break;
						case Water:
							result += water;
							break;
						}
					} else if (this.basicFullGrid.getField(drawCoordinate)
							.getPlayerPositionState() == EPlayerPositionState.MyPlayerPosition) {
						result += figure;
					} else if (this.basicFullGrid.getField(drawCoordinate)
							.getFortState() == EFortState.EnemyFortPresent) {
						result += enemyFort;
					} else {
						result += ownFort;
					}
				}

			}
			result += "\n";
		}

		return result;
	}

}
