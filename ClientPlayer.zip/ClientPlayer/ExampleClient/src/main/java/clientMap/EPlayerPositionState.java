package clientMap;

/**
 * enum defines which player is on a particular node in the grid
 * [NoPlayerPresent, EnemyPlayerPosition, MyPlayerPosition, BothPlayerPosition]
 * 
 * @author Malte
 *
 */
public enum EPlayerPositionState {
	NoPlayerPresent, EnemyPlayerPosition, MyPlayerPosition, BothPlayerPosition

}
