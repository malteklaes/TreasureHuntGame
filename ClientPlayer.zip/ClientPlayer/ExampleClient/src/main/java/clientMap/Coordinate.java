package clientMap;

import java.util.Comparator;
import java.util.Objects;

/**
 * basic 2D representation in a grid
 * 
 * @author Malte
 *
 */
public class Coordinate implements Comparator<Coordinate>, Comparable<Coordinate> {

	private int x_coord;
	private int y_coord;

	/**
	 * @param x_coord (not null)
	 * @param y_coord (not null)
	 */
	public Coordinate(int x_coord, int y_coord) {
		this.x_coord = x_coord;
		this.y_coord = y_coord;
	}

	/**
	 * @param coordinates (not null)
	 */
	public Coordinate(Coordinate coordinates) {
		this.x_coord = coordinates.x_coord;
		this.y_coord = coordinates.y_coord;
	}

	public Coordinate deepCopy() {
		int result_x = x_coord;
		int result_y = y_coord;
		return new Coordinate(result_x, result_y);
	}

	/**
	 * get x_coord
	 * 
	 * @return int
	 */
	public int getX_coord() {
		return x_coord;
	}

	/**
	 * set x_coord
	 * 
	 * @param x_coord (int)
	 */
	public void setX_coord(int x_coord) {
		this.x_coord = x_coord;
	}

	/**
	 * get y_coord
	 * 
	 * @return int
	 */
	public int getY_coord() {
		return y_coord;
	}

	/**
	 * set y_coord
	 * 
	 * @param y_coord (int)
	 */
	public void setY_coord(int y_coord) {
		this.y_coord = y_coord;
	}

	/**
	 * outputs all of both variables x_coord and y_coord
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return "[" + x_coord + ", " + y_coord + "]";
	}

	/**
	 * hashs with both variables
	 * 
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(x_coord, y_coord);
	}

	/**
	 * equals, only if x_coord and y_coord are equal
	 * 
	 * @return boolean
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		return x_coord == other.x_coord && y_coord == other.y_coord;
	}

	/**
	 * important for a possible ordering in a TreeMap.
	 * 
	 * Compares two Coordinates by firstly their x_coordinate and if equal secondly
	 * by their y_coordinate. Hereby -1 means o1 is smaller and early in a 2D Grid
	 * than o2. (Compares its two arguments for order. Returns a negative integer,
	 * zero, or a positive integer as the first argument is less than, equal to, or
	 * greater than the second. source:
	 * https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html#compare-T-T-)
	 * 
	 * @return int (-1,0,1)
	 */
	@Override
	public int compare(Coordinate o1, Coordinate o2) {
		if (o1 == null)
			return 1;
		if (o2 == null)
			return -1;
		if (o1.x_coord < o2.x_coord)
			return -1;
		if (o1.x_coord > o2.x_coord)
			return 1;
		else {
			if (o1.y_coord < o2.y_coord)
				return -1;
			if (o1.y_coord > o2.y_coord)
				return 1;
			return 0;
		}
	}

	@Override
	public int compareTo(Coordinate o) {
		return this.compare(this, o);
	}

}
