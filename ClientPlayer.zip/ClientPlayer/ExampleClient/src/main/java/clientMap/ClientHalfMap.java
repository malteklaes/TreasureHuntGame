package clientMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ClientHalfMap is more than a Grid with (1) specific dimension
 * (halfMap-dimension) and (2) with
 * 
 * @author Malte
 *
 */
public class ClientHalfMap implements IMap {

	private static Logger logger = LoggerFactory.getLogger(ClientHalfMap.class);

	private final int mountain_fields = 5;
	private final int gras_fields = 24;
	private final int water_fields = 7;
	private final int max_x_size = 10;
	private final int max_y_size = 5;

	// basicGrid is just a shallow with now fields in it
	private MapGrid basicGrid = new MapGrid(mountain_fields, gras_fields, water_fields);
	private Coordinate fortCoordinate;

	/**
	 * normal constructor
	 */
	public ClientHalfMap() {
		this.createMap();
		logger.debug("ClientHalfMap was set up with all meta data.");
	}

	/**
	 * Contructor for testing purpose
	 */
	public ClientHalfMap(MapGrid testGrid) {
		this.basicGrid = testGrid;
		this.fortCoordinate = this.basicGrid.getGridBuilder().searchForOptimalFortNode(basicGrid, max_x_size,
				max_y_size);
		basicGrid.getField(this.fortCoordinate).setFortState(EFortState.MyFortPresent);
		logger.debug("ClientHalfMap was set up with all meta data.");
	}

	@Override
	public ClientHalfMap createMap() {
		logger.debug("setting up ClientHalfMap with all meta data.");
		// [1] fill shallow grid with actual gras-/mountain-/water-fields
		this.basicGrid.generateGrid(max_x_size, max_y_size);

		// [2] finally set fort coordinates and complete the map-creation
		this.fortCoordinate = this.basicGrid.getGridBuilder().searchForOptimalFortNode(basicGrid, max_x_size,
				max_y_size);
		basicGrid.getField(this.fortCoordinate).setFortState(EFortState.MyFortPresent);
		return this;
	}

	@Override
	public MapNode readMapEntry(Coordinate coordinate) {
		logger.debug("ClientHalfMap entry with coordinate {} will be read.", coordinate);
		if (this.basicGrid.getField(coordinate) == null) {
			logger.warn("coordinate could not been found in client half map!");
			throw new MapException("coordinate could not been found in client half map!");
		}
		return this.basicGrid.getField(coordinate);
	}

	@Override
	public I2DGrid getGrid() {
		return basicGrid;
	}

	@Override
	public Coordinate getFort() {
		return fortCoordinate;
	}

	@Override
	public int getXDimension() {
		return this.max_x_size;
	}

	@Override
	public int getYDimension() {
		return this.max_y_size;
	}

	@Override
	public IMap deepCopy() {
		return new ClientFullMap(this.basicGrid.deepCopy(), this.max_x_size, this.max_y_size);
	}

	@Override
	public String toString() {
		String gras = "\033[0;32m" + "\uD83C\uDF33" + "\033[0m ";
		String mountain = "\033[0;31m" + "\u26F0" + "\033[0m ";
		String water = "\033[0;34m" + "\uD83C\uDF0A" + "\033[0m ";
		String fort = "\033[1;37m" + "\uD83C\uDFF0" + "\033[0m ";

		String result = "";
		Coordinate drawCoordinate = new Coordinate(0, 0);
		for (int y = 0; y <= max_y_size; y++) {
			for (int x = 0; x <= max_x_size; x++) {
				drawCoordinate.setX_coord(x);
				drawCoordinate.setY_coord(y);
				ETerrainType terrainType = this.basicGrid.getField(drawCoordinate).getTerrainType();
				if (this.basicGrid.getField(drawCoordinate).getFortState() == EFortState.NoOrUnknownFortState) {
					switch (terrainType) {
					case Gras:
						result += gras;
						break;
					case Mountain:
						result += mountain;
						break;
					case Water:
						result += water;
						break;
					}
				} else {
					result += fort;
				}

			}
			result += "\n";
		}

		return result;
	}

}
