package clientMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * validates both ClientHalfMap and ClientFullMap in form as an I2DGrid
 * 
 * @author Malte
 *
 */
public class MapValidator {

	private static Logger logger = LoggerFactory.getLogger(MapValidator.class);

	private I2DGrid gridToBeValidated;

	/*
	 * private final int mountain_fields = 5; private final int gras_fields = 24;
	 * private final int water_fields = 7; private final int max_x_size = 10;
	 * private final int max_y_size = 5;
	 */

	/**
	 * @param gridToBeValidated
	 */
	public MapValidator(I2DGrid gridToBeValidated) {
		this.gridToBeValidated = gridToBeValidated;
		logger.debug("a MapValidator was succefully instanciated.");
	}

	/**
	 * checks, if ...
	 * 
	 * @return boolean
	 */
	public boolean checkForEnoughFields(int grasShouldValue, int mountainShouldValue, int waterShouldValue,
			int x_dimension, int y_dimension) {
		if (this.gridToBeValidated == null) {
			logger.warn("the grid which should be validated is null.");
			return false;
		} else {
			int counterGras = 0;
			int counterMountain = 0;
			int counterUpWater = 0;

			Coordinate drawCoordinate = new Coordinate(0, 0);
			for (int y = 0; y < y_dimension; y++) {
				for (int x = 0; x < x_dimension; x++) {
					drawCoordinate.setX_coord(x);
					drawCoordinate.setY_coord(y);
					ETerrainType terrainType = this.gridToBeValidated.getField(drawCoordinate).getTerrainType();
					// [1] checks gras amount
					if (terrainType == ETerrainType.Gras) {
						counterGras++;
					}
					// [2] checks mountain amount
					if (terrainType == ETerrainType.Mountain) {
						counterMountain++;
					}
					// [3] checks water amount
					if (terrainType == ETerrainType.Water) {
						counterUpWater++;
					}
				}
			}
			logger.debug("each ETerrainType was recognized in sufficient numbers.");
			return (grasShouldValue <= counterGras && mountainShouldValue <= counterMountain
					&& waterShouldValue <= counterUpWater);
		}
	}

	/**
	 * checks, if there are more than 4 water fields on long x-side (4/10) or more
	 * than 2 water fields on short y-side (2/5)
	 * 
	 * @return boolean
	 */
	public boolean checkForWaterOnEdge(int x_dimension, int y_dimension) {
		if (this.gridToBeValidated == null) {
			logger.warn("the grid which should be validated is null.");
			return false;
		} else {
			int counterLeftSide = 0;
			int counterRightSide = 0;
			int CounterUpSide = 0;
			int CounterBottomSide = 0;

			Coordinate drawCoordinate = new Coordinate(0, 0);
			for (int y = 0; y < y_dimension; y++) {
				for (int x = 0; x < x_dimension; x++) {
					drawCoordinate.setX_coord(x);
					drawCoordinate.setY_coord(y);
					ETerrainType terrainType = this.gridToBeValidated.getField(drawCoordinate).getTerrainType();
					// [1] checks left side
					if (drawCoordinate.getX_coord() == 0 && terrainType == ETerrainType.Water) {
						counterLeftSide++;
					}
					// [2] checks right side
					if (drawCoordinate.getX_coord() == 9 && terrainType == ETerrainType.Water) {
						counterRightSide++;
					}
					// [3] checks up side
					if (drawCoordinate.getY_coord() == 0 && terrainType == ETerrainType.Water) {
						CounterUpSide++;
					}
					// [4] checks bottom side
					if (drawCoordinate.getY_coord() == 4 && terrainType == ETerrainType.Water) {
						CounterBottomSide++;
					}
				}
			}

			return (counterLeftSide <= 2 && counterRightSide <= 2 && CounterUpSide <= 4 && CounterBottomSide <= 4);
		}
	}

	/**
	 * checks, if given Grid (HalfMap with 50 fields total) contains any fields,
	 * which can not be reached
	 * 
	 * @return boolean (false, if islands were found)
	 */
	public boolean checkForIsland(int x_dimension, int y_dimension) {
		if (this.gridToBeValidated == null)
			return false;
		else {
			// [1] initial coordinate is a no water field
			Coordinate initCoord = this.findStartPoint(x_dimension, y_dimension);

			// [2] start flood fill algorithm
			I2DGrid testGrid = new MapGrid(((MapGrid) gridToBeValidated).getGrid(), 0, 0, 0);
			this.floodFillAlgorithm(testGrid, initCoord, x_dimension, y_dimension);
			logger.debug("the grid was successfully examined on island and too much water.");
			return testGrid.countWaterNodes() == 50;
		}
	}

	/**
	 * finds the start point for flood fill algorithm, which should not be a water
	 * field. Pre-Condition: (1) Will never be called, if this.gridToBeValidated ==
	 * null and (2) grid which is evaluated has at least one field which is no water
	 * field.
	 * 
	 * @return Coordinate (which is only technical null, but since Pre-Condition
	 *         should not be null)
	 */
	private Coordinate findStartPoint(int x_dimension, int y_dimension) {
		for (int x = 0; x < x_dimension; x++) {
			for (int y = 0; y < y_dimension; y++) {
				Coordinate initialCoord = new Coordinate(x, y);
				if (this.gridToBeValidated.getField(initialCoord).getTerrainType() != ETerrainType.Water)
					return initialCoord;
			}
		}
		return null;
	}

	/**
	 * checks if the reachable fields were water fields and if not, paints over them
	 * as water fields. The Result should be a Grid which consist purely of water
	 * fields (== is flooded all over).
	 * 
	 * @param testGrid  (Grid will be changed during check-up)
	 * @param initCoord
	 */
	private void floodFillAlgorithm(I2DGrid testGrid, Coordinate initCoord, int x_dimension, int y_dimension) {
		int x_value = initCoord.getX_coord();
		int y_value = initCoord.getY_coord();
		// [1] Check if Coordinate is out of bounds or this field is already water
		if (x_value < 0 || x_dimension <= x_value || y_value < 0 || y_dimension <= y_value
				|| testGrid.getField(initCoord).getTerrainType() == ETerrainType.Water) {
		}
		// return;
		else {
			// [2] paint field as water
			testGrid.setFieldTerrain(initCoord, ETerrainType.Water);
			// [3] go on in all four directions recursively
			this.floodFillAlgorithm(testGrid, new Coordinate(x_value + 1, y_value), x_dimension, y_dimension);
			this.floodFillAlgorithm(testGrid, new Coordinate(x_value - 1, y_value), x_dimension, y_dimension);
			this.floodFillAlgorithm(testGrid, new Coordinate(x_value, y_value + 1), x_dimension, y_dimension);
			this.floodFillAlgorithm(testGrid, new Coordinate(x_value, y_value - 1), x_dimension, y_dimension);
		}
	}

}
