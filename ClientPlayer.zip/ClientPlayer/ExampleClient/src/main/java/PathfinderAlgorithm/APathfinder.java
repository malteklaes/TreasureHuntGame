package PathfinderAlgorithm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.Coordinate;
import clientMap.EPlayerPositionState;
import clientMap.ETerrainType;
import clientMap.IMap;
import clientMap.MapNode;
import messagesbase.messagesfromclient.EMove;

/**
 * defines strategy to find desired object:
 * 
 * @author Malte
 *
 */
public abstract class APathfinder {

	private static Logger logger = LoggerFactory.getLogger(APathfinder.class);

	protected IMap gameMap;
	protected int minX, maxX, minY, maxY;
	protected List<EMove> actualPath_EMove;
	protected List<Coordinate> actualPath;
	protected MyBFS bfs;

	protected Coordinate priorPosition;
	protected Coordinate actualPosition;

	protected EMove nextMove;

	protected boolean allEyesOnTreasre;
	protected Coordinate treasuresCoordinate;
	protected Coordinate fortsCoordinate;
	protected boolean fortHuntActivated;

	/**
	 * @param gameMap
	 * @param minX
	 * @param maxX
	 * @param minY
	 * @param maxY
	 */
	public APathfinder(IMap gameMap, int minX, int maxX, int minY, int maxY) {
		this.gameMap = gameMap;
		this.minX = minX;
		this.maxX = maxX;
		this.minY = minY;
		this.maxY = maxY;
	}

	/**
	 * central method to calculate path (has to be overriden in derived classes)
	 * 
	 * @param freshGameMap
	 * @param fortInSight
	 * @return
	 * @throws MovementException
	 */
	public EMove calculateNextStep(IMap freshGameMap, boolean desiredObject) throws MovementException {
		return EMove.Up;
	}

	/**
	 * arranges procedure for finding a way to desired object
	 * 
	 * @return
	 */
	protected List<Coordinate> prepareWholePath() {
		List<Coordinate> path = new ArrayList<>();
		path = this.calulateAllValidMountains();
		path.add(0, this.priorPosition);
		logger.debug("successfully prepared the whole path.");
		return path;
	}

	// *
	/**
	 * calculates all Coordinates of gras fields which are not covered by mountain
	 * and are valid. So in total #result == #gesamt - 1 - #mountainsrelated
	 *
	 * @param mountainRelated
	 * @return
	 */
	protected List<Coordinate> calculateNonMountainCoordinates(List<Coordinate> mountainRelated) {
		List<Coordinate> nonMountainsPinPoints = new ArrayList<>();
		if (gameMap != null) {
			for (Map.Entry<Coordinate, MapNode> elem : gameMap.getGrid().getGrid().entrySet()) {
				if (this.isValidCoordinate(elem.getKey()) && !mountainRelated.contains(elem.getValue()))
					nonMountainsPinPoints.add(elem.getKey());
			}
		}
		nonMountainsPinPoints.removeAll(mountainRelated);
		logger.debug("succesfully calculates all non mountain related coordinates.");
		return nonMountainsPinPoints;
	}

	// *
	/**
	 * calculates all fields around mounatin, so 8 each mountain, so result.size()
	 * == (pinpoint.size -1)*8 [-1 because of the non mountain start field]
	 * 
	 * @param pinPoints
	 * @return
	 */
	protected List<Coordinate> calculateAllFieldsCoveredByMountain(List<Coordinate> pinPoints) {
		// first point is fort so no mountain
		pinPoints.remove(0);
		List<Coordinate> result = new ArrayList<>();
		for (Coordinate coord : pinPoints) {
			Coordinate coord_north = new Coordinate(coord.getX_coord(), coord.getY_coord() + 1);
			Coordinate coord_north_west = new Coordinate(coord.getX_coord() + 1, coord.getY_coord() + 1);
			Coordinate coord_north_east = new Coordinate(coord.getX_coord() - 1, coord.getY_coord() + 1);
			Coordinate coord_south = new Coordinate(coord.getX_coord(), coord.getY_coord() - 1);
			Coordinate coord_south_west = new Coordinate(coord.getX_coord() + 1, coord.getY_coord() - 1);
			Coordinate coord_south_east = new Coordinate(coord.getX_coord() - 1, coord.getY_coord() - 1);
			Coordinate coord_east = new Coordinate(coord.getX_coord() - 1, coord.getY_coord());
			Coordinate coord_west = new Coordinate(coord.getX_coord() + 1, coord.getY_coord());
			// own
			if (!result.contains(coord))
				result.add(coord);
			// north
			if (!result.contains(coord_north) && this.isValidCoordinate(coord_north))
				result.add(coord_north);
			if (!result.contains(coord_north_west) && this.isValidCoordinate(coord_north_west))
				result.add(coord_north_west);
			if (!result.contains(coord_north_east) && this.isValidCoordinate(coord_north_east))
				result.add(coord_north_east);
			// south
			if (!result.contains(coord_south) && this.isValidCoordinate(coord_south))
				result.add(coord_south);
			if (!result.contains(coord_south_west) && this.isValidCoordinate(coord_south_west))
				result.add(coord_south_west);
			if (!result.contains(coord_south_east) && this.isValidCoordinate(coord_south_east))
				result.add(coord_south_east);
			// east
			if (!result.contains(coord_east) && this.isValidCoordinate(coord_east))
				result.add(coord_east);
			// west
			if (!result.contains(coord_west) && this.isValidCoordinate(coord_west))
				result.add(coord_west);
		}
		result.stream().distinct().collect(Collectors.toList());
		logger.debug("succesfully calculated all fields covered by mountains.");
		return result;
	}

	/**
	 * converts given path made from Coordinate to a path made from EMove
	 * 
	 * @param path
	 * @return
	 */
	protected List<EMove> convertToEMove(List<Coordinate> path) {
		List<EMove> moves = new ArrayList<>();
		if (path != null) {
			for (int i = 0; i < path.size() - 1; i++) {
				Coordinate curr = path.get(i);
				Coordinate next = path.get(i + 1);
				if (next.getX_coord() > curr.getX_coord()) {
					moves.add(EMove.Right);
				} else if (next.getX_coord() < curr.getX_coord()) {
					moves.add(EMove.Left);
				} else if (next.getY_coord() > curr.getY_coord()) {
					moves.add(EMove.Down);
				} else {
					moves.add(EMove.Up);
				}
			}
		}
		logger.debug("succesfully converts a list of coordinate to a list of EMoves.");
		return moves;
	}

	/**
	 * calculates all mountains in a game map with given limits (minX, ...)
	 * 
	 * @return
	 */
	private List<Coordinate> calulateAllValidMountains() {
		List<Coordinate> mountains = new ArrayList<>();
		if (gameMap != null) {
			for (Map.Entry<Coordinate, MapNode> elem : gameMap.getGrid().getGrid().entrySet()) {
				if (this.isValidCoordinate(elem.getKey()) && elem.getValue().getTerrainType() == ETerrainType.Mountain)
					mountains.add(elem.getKey());
			}
		}
		logger.debug("succesfully calculated all valid mountains within the given zone.");
		return mountains;
	}

	/**
	 * checks if an incoming coord is a valid coordinate (in limits and no water
	 * field)
	 * 
	 * @param coord
	 * @return
	 */
	private boolean isValidCoordinate(Coordinate coord) {
		int x = coord.getX_coord();
		int y = coord.getY_coord();
		return x >= minX && x <= maxX && y >= minY && y <= maxY && this.gameMap.getGrid().getField(coord) != null
				&& this.gameMap.getGrid().getField(coord).getTerrainType() != ETerrainType.Water;
	}

	/**
	 * calculates own position depending on an existing game map
	 * 
	 * @return
	 */
	protected Coordinate calculateOwnPosition() {
		Coordinate ownPlayerPosition = new Coordinate(0, 0);
		boolean ownPlayerHasBeenSeen = false;
		for (Map.Entry<Coordinate, MapNode> elem : this.gameMap.getGrid().getGrid().entrySet()) {
			if (elem.getValue().getPlayerPositionState() == EPlayerPositionState.MyPlayerPosition
					|| elem.getValue().getPlayerPositionState() == EPlayerPositionState.BothPlayerPosition) {
				ownPlayerHasBeenSeen = true;
				ownPlayerPosition = elem.getKey();
			}
		}
		logger.debug("succesfully calculated own position.");
		return ownPlayerPosition;
	}

	/**
	 * calculates own position depending on an existing game map
	 * 
	 * @return
	 */
	private Coordinate calculateEnemyPosition() {
		Coordinate enemyPlayerPosition = new Coordinate(0, 0);
		for (Map.Entry<Coordinate, MapNode> elem : this.gameMap.getGrid().getGrid().entrySet()) {
			if (elem.getValue().getPlayerPositionState() == EPlayerPositionState.EnemyPlayerPosition) {
				enemyPlayerPosition = elem.getKey();
			}
		}
		logger.debug("succesfully calculated enemys position.");
		return enemyPlayerPosition;

	}

	/**
	 * copies incoming List deeply
	 * 
	 * @param originalList
	 * @return
	 */
	protected List<Coordinate> deepListCopy(List<Coordinate> originalList) {
		List<Coordinate> deepCopy = new ArrayList<>();
		for (Coordinate coord : originalList) {
			deepCopy.add(new Coordinate(coord.getX_coord(), coord.getY_coord()));
		}
		logger.debug("succesfully copied original list deeply to a new list of coordinates.");
		return deepCopy;
	}

}
