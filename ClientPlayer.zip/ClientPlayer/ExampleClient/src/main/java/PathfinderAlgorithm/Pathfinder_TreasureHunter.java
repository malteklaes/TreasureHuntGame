package PathfinderAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.Coordinate;
import clientMap.ETreasureState;
import clientMap.IMap;
import clientMap.MapNode;
import messagesbase.messagesfromclient.EMove;

/**
 * defines strategy to find own treasure: in the own zone firstly go after all
 * mountains and than all other gras field, which are left
 * 
 * @author Malte
 *
 */
public class Pathfinder_TreasureHunter extends APathfinder {

	private static Logger logger = LoggerFactory.getLogger(Pathfinder_TreasureHunter.class);

	/**
	 * @param gameMap
	 * @param minX
	 * @param maxX
	 * @param minY
	 * @param maxY
	 * @throws MovementException
	 */
	public Pathfinder_TreasureHunter(IMap gameMap, int minX, int maxX, int minY, int maxY) throws MovementException {
		super(gameMap, minX, maxX, minY, maxY);
		// [1] set other fields
		super.actualPath = new ArrayList<>();
		super.actualPath_EMove = new ArrayList<>();
		// [2] initialize Depth-First-Search Algorithm with special boundaries
		super.bfs = new MyBFS(super.gameMap, super.minX, super.maxX, super.minY, super.maxY);
		super.priorPosition = super.gameMap.getFort();
		super.nextMove = EMove.Up; // random inital move which is not taken in counter by server
		super.allEyesOnTreasre = false;
		super.treasuresCoordinate = new Coordinate(0, 0);
		// [3] set up path to find treasure
		super.actualPath = this.calculateWholePath(super.prepareWholePath());
		super.actualPath_EMove = super.convertToEMove(super.actualPath);
		super.nextMove = super.actualPath_EMove.remove(0);
		logger.debug("all necessary meta information for calculate path was succesfully set up.");
	}

	@Override
	public EMove calculateNextStep(IMap freshGameMap, boolean treasureInSight) throws MovementException {
		// System.out.println("own zone: " + minX + ", " + maxX + ", " + minY + ", " +
		// maxY);
		// [1] first refresh map to calculate correct own position
		super.gameMap = freshGameMap;
		// [2] second refresh own position
		actualPosition = super.calculateOwnPosition();

		// [3] if treasure was sighted, a path to there will be calculated
		if (treasureInSight && !allEyesOnTreasre) {
			logger.debug("strategy has changed and therefor path has changed to treasure.");
			this.peelOutTreasureCoordinate();
			actualPath = bfs.findShortestPath(actualPosition, treasuresCoordinate);
			allEyesOnTreasre = true;
			actualPath_EMove = super.convertToEMove(super.actualPath);
			nextMove = actualPath_EMove.remove(0);
			priorPosition = actualPosition;
		}

		// [4] represents normal search for treasure
		if (!treasureInSight) {
			if (actualPosition == new Coordinate(0, 0) || priorPosition == new Coordinate(0, 0)) {
			}
			if (!actualPosition.equals(priorPosition)) {
				if (!actualPath_EMove.isEmpty()) {
					nextMove = actualPath_EMove.remove(0);
				}
				priorPosition = actualPosition;
			}
			logger.debug("a next move has succesfully been calculated. " + nextMove);
			return nextMove;
		} else {
			if (!actualPosition.equals(priorPosition)) {
				nextMove = super.actualPath_EMove.remove(0);
				priorPosition = actualPosition;
				logger.debug("a next move has succesfully been calculated. " + nextMove);
				return nextMove;
			} else {
				priorPosition = actualPosition;
				logger.debug("a next move has succesfully been calculated. " + nextMove);
				return nextMove;
			}
		}
	}

	/**
	 * calulate the whole route from point to point and creates a whole path
	 * 
	 * @param pinPoints
	 * @return
	 * @throws MovementException
	 */
	private List<Coordinate> calculateWholePath(List<Coordinate> pinPoints) throws MovementException {
		// [1] find first all mountains
		List<Coordinate> result = new ArrayList<>();

		// [2] calculates all fields related to mountains
		List<Coordinate> deepCopyPinPoints = super.deepListCopy(pinPoints);
		List<Coordinate> allFieldsCoveredByMountain = super.calculateAllFieldsCoveredByMountain(deepCopyPinPoints);

		// [3] add gras fields, which are undiscovered and non mountain related
		List<Coordinate> nonMountainsPinPoints = super.calculateNonMountainCoordinates(allFieldsCoveredByMountain);
		Collections.reverse(nonMountainsPinPoints);

		// [4] all pinpoints are added up to generate one path
		List<Coordinate> allPinPoints = pinPoints;
		allPinPoints.addAll(nonMountainsPinPoints);

		for (int i = 0; i < allPinPoints.size() - 1; i++) {
			List<Coordinate> help = new ArrayList<>();
			result.addAll(bfs.findShortestPath(allPinPoints.get(i), allPinPoints.get(i + 1)));
			result.remove(result.size() - 1);

		}
		logger.debug("a whole path has successfully calculated for find treasure.");
		return result;
	}

	/**
	 * calculates coordinates of own treasure
	 */
	private void peelOutTreasureCoordinate() {
		for (Map.Entry<Coordinate, MapNode> elem : super.gameMap.getGrid().getGrid().entrySet()) {
			if (elem.getValue().getTreasureState() == ETreasureState.MyTreasureIsPresent) {
				treasuresCoordinate = elem.getKey();
			}
		}

	}

}
