package PathfinderAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.Coordinate;
import clientMap.EFortState;
import clientMap.IMap;
import clientMap.MapNode;
import messagesbase.messagesfromclient.EMove;

/**
 * defines strategy to find enemys fort: after transit to enemys zone firstly go
 * after all mountains and than all other gras field, which are left
 * 
 * @author Malte
 *
 */
public class Pathfinder_FortHunter extends APathfinder {

	private static Logger logger = LoggerFactory.getLogger(Pathfinder_FortHunter.class);

	/**
	 * @param super.gameMap
	 * @param super.minX
	 * @param super.maxX
	 * @param super.minY
	 * @param super.maxY
	 */
	public Pathfinder_FortHunter(IMap gameMap, int minX, int maxX, int minY, int maxY) {
		super(gameMap, minX, maxX, minY, maxY);
		// [1] set other fields
		super.actualPath = new ArrayList<>();
		super.actualPath_EMove = new ArrayList<>();
		// [2] initialize Depth-First-Search Algorithm with special boundaries
		super.bfs = new MyBFS(super.gameMap, super.minX, super.maxX, super.minY, super.maxY);
		super.priorPosition = super.calculateOwnPosition(); // get start position at the beginning
		super.nextMove = EMove.Up; // random inital move which is not taken in counter by server
		super.allEyesOnTreasre = false;
		super.fortsCoordinate = new Coordinate(0, 0);
		super.fortHuntActivated = true;
		logger.debug("all necessary meta information for calculate path was succesfully set up.");
	}

	@Override
	public EMove calculateNextStep(IMap freshgameMap, boolean fortInSight) throws MovementException {
		logger.debug("start to calculate optimal path.");
		// [1] first refresh map to calculate correct own position
		super.gameMap = freshgameMap;
		// [2] second refresh own position
		super.actualPosition = super.calculateOwnPosition();

		// [3] just once all the path to hunt enemy fort is set up here
		if (super.fortHuntActivated) {
			logger.debug("strategy has changed and therefor path has changed to enemys fort.");
			super.priorPosition = super.actualPosition;
			super.actualPath = this.calculateWholePath(super.prepareWholePath());
			super.actualPath_EMove = super.convertToEMove(super.actualPath);
			super.nextMove = super.actualPath_EMove.remove(0);
			super.fortHuntActivated = false;
		}

		// [4] if fort was sighted from mountain view path to there will be calculated
		if (fortInSight && !super.allEyesOnTreasre) {
			this.peelOutfortCoordinate();
			super.actualPath = bfs.findShortestPath(super.actualPosition, super.fortsCoordinate);
			super.allEyesOnTreasre = true;
			super.actualPath_EMove = super.convertToEMove(super.actualPath);
			super.nextMove = super.actualPath_EMove.remove(0);
			super.priorPosition = super.actualPosition;
		}
		// [5] if player is on transition to enemys zone or searching there for enemys
		// fort
		if (!fortInSight) {
			if (!super.actualPosition.equals(super.priorPosition)) {
				if (!super.actualPath_EMove.isEmpty()) {
					super.nextMove = super.actualPath_EMove.remove(0);
				}
				super.priorPosition = super.actualPosition;
			}
			logger.debug("a next move has succesfully been calculated. " + nextMove);
			return super.nextMove;
		} else {
			if (!super.actualPosition.equals(super.priorPosition)) {
				super.nextMove = super.actualPath_EMove.remove(0);
				super.priorPosition = super.actualPosition;
				logger.debug("a next move has succesfully been calculated. " + nextMove);
				return super.nextMove;
			} else {
				super.priorPosition = super.actualPosition;
				logger.debug("a next move has succesfully been calculated. " + nextMove);
				return super.nextMove;
			}
		}
	}

	/**
	 * calulates the whole route from point to point and creates a whole path
	 * 
	 * @param pinPoints
	 * @return
	 * @throws MovementException
	 */
	private List<Coordinate> calculateWholePath(List<Coordinate> pinPoints) throws MovementException {
		// [1] find first all mountains
		List<Coordinate> result = new ArrayList<>();

		// [2] calculates all fields related to mountains
		List<Coordinate> deepCopyPinPoints = super.deepListCopy(pinPoints);
		List<Coordinate> allFieldsCoveredByMountain = super.calculateAllFieldsCoveredByMountain(deepCopyPinPoints);

		// [3] add gras fields, which are undiscovered and non mountain related
		List<Coordinate> nonMountainsPinPoints = super.calculateNonMountainCoordinates(allFieldsCoveredByMountain);
		Collections.reverse(nonMountainsPinPoints);

		// [4] all pinpoints are added up to generate one path
		List<Coordinate> allPinPoints = pinPoints;
		allPinPoints.addAll(nonMountainsPinPoints);

		MyBFS bfs_transition = new MyBFS(super.gameMap, 0, super.gameMap.getXDimension() - 1, 0,
				super.gameMap.getYDimension() - 1);
		for (int i = 0; i < allPinPoints.size() - 1; i++) {
			List<Coordinate> help = new ArrayList<>();
			result.addAll(bfs_transition.findShortestPath(allPinPoints.get(i), allPinPoints.get(i + 1)));
			result.remove(result.size() - 1);

		}
		logger.debug("a whole path has successfully calculated for finding enemys fort.");
		return result;
	}

	/**
	 * calculates coordinates of enemys fort
	 */
	private void peelOutfortCoordinate() {
		for (Map.Entry<Coordinate, MapNode> elem : this.gameMap.getGrid().getGrid().entrySet()) {
			if (elem.getValue().getFortState() == EFortState.EnemyFortPresent) {
				fortsCoordinate = elem.getKey();
			}
		}

	}

}
