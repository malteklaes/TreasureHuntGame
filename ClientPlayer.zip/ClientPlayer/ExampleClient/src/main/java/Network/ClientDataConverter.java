package Network;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientGame.EGameState;
import clientMap.ClientFullMap;
import clientMap.Coordinate;
import clientMap.EFortState;
import clientMap.EPlayerPositionState;
import clientMap.ETerrainType;
import clientMap.IMap;
import clientMap.MapNode;
import messagesbase.messagesfromclient.ETerrain;
import messagesbase.messagesfromclient.PlayerHalfMap;
import messagesbase.messagesfromclient.PlayerHalfMapNode;
import messagesbase.messagesfromserver.EPlayerGameState;
import messagesbase.messagesfromserver.FullMap;
import messagesbase.messagesfromserver.FullMapNode;
import messagesbase.messagesfromserver.PlayerState;

/**
 * class which converts all kind of data interchanged with a external server
 * 
 * @author Malte
 *
 */
public class ClientDataConverter {

	private static Logger logger = LoggerFactory.getLogger(ClientDataConverter.class);

	// ##########################################################################################################################################
	// CONVERT MAP RELATED
	// ##########################################################################################################################################

	/**
	 * DIRECTION: client -> server (converts a given gameMap to a PlayerHalfMap
	 * (represented by a set))
	 * 
	 * 
	 * @param playerID (not null)
	 * @param gameMap  (not null, but will be checked)
	 * @return PlayerHalfMap (might be null, since gameMap can be null)
	 */
	public PlayerHalfMap convertHalfMap_CS(String playerID, IMap gameMap) {
		// [1] build elementary playerHalfMapNode-type (set)
		Set<PlayerHalfMapNode> set = new HashSet<>();
		// [2] fill set
		if (gameMap != null && gameMap.getGrid() != null) {
			for (Map.Entry<Coordinate, MapNode> elem : gameMap.getGrid().getGrid().entrySet()) {
				Coordinate coord = elem.getKey();
				MapNode mapNode = elem.getValue();
				boolean fortPresent = (mapNode.getFortState() == EFortState.MyFortPresent);
				// [3] convert ETerrainType to ETerrain
				ETerrain eTerrain = this.convertTerrainTypes_CS(mapNode.getTerrainType());
				// [4] finally add to set
				set.add(new PlayerHalfMapNode(coord.getX_coord(), coord.getY_coord(), fortPresent, eTerrain));
			}
		}
		logger.debug("succesfully converts a gameMap to a PlayerHalfMap.");
		return new PlayerHalfMap(playerID, set);
	}

	/**
	 * DIRECTION: server -> client (converts FullMap to IMap)
	 * 
	 * @param fullMap (not null)
	 * @return IMap
	 */
	public IMap convertFullMap_SC(FullMap fullMap) {
		List<MapNode> nodeList = new ArrayList<>();
		fullMap.getMapNodes().forEach(fullMapNode -> {
			try {
				nodeList.add(this.convertFullMapNode_SC(fullMapNode));
			} catch (ConversionException e) {
				logger.error("no treasure state could by found while converting with this error: {}.", e);
				e.printStackTrace();
			}
		});
		logger.debug("succesfully converts a FullMap to IMap.");
		return new ClientFullMap(nodeList);
	}

	/**
	 * DIRECTION: server -> client (converts a given FullMapNode to MapNode, to do
	 * so, it extract and stores all necessary information (Coordinate,
	 * ETerrainType, ETreasureState,EFortState, EPlayerPositionState) into new
	 * MapNode
	 * 
	 * @param fullMapNode
	 * @return MapNode
	 * @throws ConversionException
	 */
	public MapNode convertFullMapNode_SC(FullMapNode fullMapNode) throws ConversionException {
		Coordinate coordinate = new Coordinate(fullMapNode.getX(), fullMapNode.getY());
		ETerrainType terrainType = this.convertETerrain_SC(fullMapNode.getTerrain());
		clientMap.ETreasureState treasureState = this.convertTreasueState_SC(fullMapNode.getTreasureState());
		EFortState fortState = this.convertFortState_SC(fullMapNode.getFortState());
		EPlayerPositionState playerPositionState = this.convertPlayerState_SC(fullMapNode.getPlayerPositionState());
		logger.debug("succesfully converts a FullMapNode to MapNode.");
		return new MapNode(coordinate, terrainType, treasureState, fortState, playerPositionState);
	}

	/**
	 * DIRECTION: server -> client (converts PlayerState to
	 * NetworkPlayerRepresentation)
	 * 
	 * @param playerState (not null)
	 * @return
	 */
	public NetworkPlayerRepresentation convertPlayerState_SC(PlayerState playerState) {
		logger.debug("converting a PlayerState to a NetworkPlayerRepresentation.");
		return new NetworkPlayerRepresentation(playerState.getFirstName(), playerState.getLastName(),
				playerState.getUAccount(), playerState.getUniquePlayerID(), playerState.hasCollectedTreasure());
	}

	// ##########################################################################################################################################
	// CONVERT PLAYER MOVE RELATED
	// ##########################################################################################################################################

	// ##########################################################################################################################################
	// CONVERT ENUM RELATED
	// ##########################################################################################################################################

	/**
	 * DIRECTION: server -> client (converts a given
	 * messagesbase.messagesfromserver.ETreasureState to clientMap.ETreasureState)
	 * 
	 * @param eTreasureState
	 * @return clientMap.ETreasureState
	 * @throws ConversionException
	 */
	private clientMap.ETreasureState convertTreasueState_SC(
			messagesbase.messagesfromserver.ETreasureState eTreasureState) throws ConversionException {
		switch (eTreasureState) {
		case NoOrUnknownTreasureState:
			logger.debug("succesfully converts a ETreasureState to clientMap.ETreasureState.");
			return clientMap.ETreasureState.NoOrUnknownTreasureState;
		case MyTreasureIsPresent:
			logger.debug("succesfully converts a ETreasureState to clientMap.ETreasureState.");
			return clientMap.ETreasureState.MyTreasureIsPresent;

		default:
			logger.error("no treasure state could by found while converting.");
			throw new ConversionException("no treasure state could by found while converting.");
		}
	}

	/**
	 * DIRECTION: server -> client (converts a given
	 * messagesbase.messagesfromserver.EFortState to clientMap.EFortState)
	 * 
	 * @param eTreasureState
	 * @return clientMap.ETreasureState
	 * @throws ConversionException
	 */
	private clientMap.EFortState convertFortState_SC(messagesbase.messagesfromserver.EFortState eFortState)
			throws ConversionException {
		switch (eFortState) {
		case NoOrUnknownFortState:
			logger.debug("succesfully converts a EFortState to clientMap.EFortState.");
			return clientMap.EFortState.NoOrUnknownFortState;
		case MyFortPresent:
			logger.debug("succesfully converts a EFortState to clientMap.EFortState.");
			return clientMap.EFortState.MyFortPresent;
		case EnemyFortPresent:
			logger.debug("succesfully converts a EFortState to clientMap.EFortState.");
			return clientMap.EFortState.EnemyFortPresent;

		default:
			logger.error("no fort state could by found while converting.");
			throw new ConversionException("no fort state could by found while converting.");
		}
	}

	/**
	 * DIRECTION: server -> client (converts a given
	 * messagesbase.messagesfromserver.EPlayerPositionState to
	 * clientMap.EPlayerPositionState)
	 * 
	 * @param eTreasureState
	 * @return clientMap.ETreasureState
	 * @throws ConversionException
	 */
	private clientMap.EPlayerPositionState convertPlayerState_SC(
			messagesbase.messagesfromserver.EPlayerPositionState ePlayerPositionState) throws ConversionException {
		switch (ePlayerPositionState) {
		case NoPlayerPresent:
			logger.debug("succesfully converts a EPlayerPositionState to clientMap.EPlayerPositionState.");
			return clientMap.EPlayerPositionState.NoPlayerPresent;
		case MyPlayerPosition:
			logger.debug("succesfully converts a EPlayerPositionState to clientMap.EPlayerPositionState.");
			return clientMap.EPlayerPositionState.MyPlayerPosition;
		case EnemyPlayerPosition:
			logger.debug("succesfully converts a EPlayerPositionState to clientMap.EPlayerPositionState.");
			return clientMap.EPlayerPositionState.EnemyPlayerPosition;
		case BothPlayerPosition:
			logger.debug("succesfully converts a EPlayerPositionState to clientMap.EPlayerPositionState.");
			return clientMap.EPlayerPositionState.BothPlayerPosition;

		default:
			logger.error("no player position state could by found while converting.");
			throw new ConversionException("no player position state could by found while converting.");
		}
	}

	/**
	 * DIRECTION: server -> client (converts a given EPlayerGameState to EGameState)
	 * 
	 * @param ePlayerGameState
	 * @return EGameState
	 * @throws ConversionException
	 */
	public EGameState convertEPlayerGameState_SC(EPlayerGameState ePlayerGameState) throws ConversionException {
		switch (ePlayerGameState) {
		case MustWait:
			logger.debug("succesfully converts a EPlayerGameState to EGameState.");
			return EGameState.MustWait;
		case MustAct:
			logger.debug("succesfully converts a EPlayerGameState to EGameState.");
			return EGameState.MustAct;
		case Won:
			logger.debug("succesfully converts a EPlayerGameState to EGameState.");
			return EGameState.Won;
		case Lost:
			logger.debug("succesfully converts a EPlayerGameState to EGameState.");
			return EGameState.Lost;

		default:
			logger.error("no EPlayerGameState was found while converting.");
			throw new ConversionException("no EPlayerGameState was found while converting.");
		}
	}

	/**
	 * DIRECTION: server -> client (converts a given ETerrain to ETerrainType)
	 * 
	 * @param eTerrain
	 * @return ETerrainType
	 */
	private ETerrainType convertETerrain_SC(ETerrain eTerrain) {
		ETerrainType eTerrainType = null;
		switch (eTerrain) {
		case Grass:
			logger.debug("ETerrain to ETerrainType.");
			eTerrainType = ETerrainType.Gras;
			break;
		case Mountain:
			logger.debug("ETerrain to ETerrainType.");
			eTerrainType = ETerrainType.Mountain;
			break;
		case Water:
			logger.debug("ETerrain to ETerrainType.");
			eTerrainType = ETerrainType.Water;
			break;
		}
		return eTerrainType;
	}

	/**
	 * DIRECTION: client -> server (converts an ETerrainType to an ETerrain)
	 * 
	 * @param eTerrainType
	 * @return ETerrain
	 */
	private ETerrain convertTerrainTypes_CS(ETerrainType eTerrainType) {
		ETerrain eTerrain = null;
		switch (eTerrainType) {
		case Gras:
			logger.debug("ETerrainType to an ETerrain.");
			eTerrain = ETerrain.Grass;
			break;
		case Mountain:
			logger.debug("ETerrainType to an ETerrain.");
			eTerrain = ETerrain.Mountain;
			break;
		case Water:
			logger.debug("ETerrainType to an ETerrain.");
			eTerrain = ETerrain.Water;
			break;
		}
		return eTerrain;
	}

}
