package Network;

/**
 * Exception regarding: register client at server went wrong
 * 
 * @author Malte
 *
 */
public class RegistrationException extends Exception {
	public RegistrationException(String message) {
		super("regarding client registration: " + message);
	}
}
