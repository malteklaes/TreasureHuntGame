package Network;

/**
 * Exception regarding: there was an error while converting data
 * 
 * @author Malte
 *
 */
public class ConversionException extends Exception {

	public ConversionException(String message) {
		super("regarding conversion of data: " + message);
	}

}
