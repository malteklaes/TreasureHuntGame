package Network;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * bundles all necessary information about a player
 * 
 * @author Malte
 *
 */
public class NetworkPlayerRepresentation {

	private static Logger logger = LoggerFactory.getLogger(NetworkPlayerRepresentation.class);

	private String student_firstname;
	private String student_lastname;
	private String student_uaccount;
	private String playerID;
	private boolean collectedTreasure;

	/**
	 * @param student_firstname
	 * @param student_lastname
	 * @param student_uaccount
	 * @param playerID
	 * @param collectedTreasure
	 */
	public NetworkPlayerRepresentation(String student_firstname, String student_lastname, String student_uaccount,
			String playerID, boolean collectedTreasure) {
		this.student_firstname = student_firstname;
		this.student_lastname = student_lastname;
		this.student_uaccount = student_uaccount;
		this.playerID = playerID;
		this.collectedTreasure = collectedTreasure;
		logger.debug("Succesfully bundles all information of one player.");
	}

	/**
	 * @return the student_firstname
	 */
	public String getStudent_firstname() {
		return student_firstname;
	}

	/**
	 * @return the student_lastname
	 */
	public String getStudent_lastname() {
		return student_lastname;
	}

	/**
	 * @return the student_uaccount
	 */
	public String getStudent_uaccount() {
		return student_uaccount;
	}

	/**
	 * @return the playerID
	 */
	public String getPlayerID() {
		return playerID;
	}

	/**
	 * @return the collectedTreasure
	 */
	public boolean hasCollectedTreasure() {
		return collectedTreasure;
	}

	@Override
	public String toString() {
		return "NetworkPlayerRepresentation [student_firstname=" + student_firstname + ", student_lastname="
				+ student_lastname + ", student_uaccount=" + student_uaccount + ", playerID=" + playerID
				+ ", collectedTreasure=" + collectedTreasure + "]";
	}

}
