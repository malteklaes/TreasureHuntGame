package Network;

/**
 * Exception regarding: send player movement went wrong
 * 
 * @author Malte
 *
 */
public class SendPlayerMovementExcpetion extends Exception {
	public SendPlayerMovementExcpetion(String message) {
		super("regarding sending movement to server: " + message);
	}
}
