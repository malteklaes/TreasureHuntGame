package clientGame;

import java.util.Objects;

/**
 * class bundles information about the dimension of a certain zone
 * 
 * @author Malte
 *
 */
public class ZoneDimension {

	private int x_min;
	private int x_max;
	private int y_min;
	private int y_max;

	/**
	 * [x_min, x_max, y_min, y_max]
	 * 
	 * @param x_min
	 * @param x_max
	 * @param y_min
	 * @param y_max
	 */
	public ZoneDimension(int x_min, int x_max, int y_min, int y_max) {
		this.x_min = x_min;
		this.x_max = x_max;
		this.y_min = y_min;
		this.y_max = y_max;
	}

	/**
	 * @return the x_min
	 */
	public int getX_min() {
		return x_min;
	}

	/**
	 * @return the x_max
	 */
	public int getX_max() {
		return x_max;
	}

	/**
	 * @return the y_min
	 */
	public int getY_min() {
		return y_min;
	}

	/**
	 * @return the y_max
	 */
	public int getY_max() {
		return y_max;
	}

	@Override
	public int hashCode() {
		return Objects.hash(x_max, x_min, y_max, y_min);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZoneDimension other = (ZoneDimension) obj;
		return x_max == other.x_max && x_min == other.x_min && y_max == other.y_max && y_min == other.y_min;
	}

	/**
	 * string-representation for testing and debugging purpose
	 */
	public String toString() {
		return "ZoneDimension [" + x_min + "," + x_max + ", " + y_min + ", " + y_max + "]";
	}

}
