package clientGame;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.IMap;

/**
 * is a observable object, which listener (like IView-objects) are listen to
 * 
 * @author Malte
 *
 */
public class GameModel {

	private static Logger logger = LoggerFactory.getLogger(GameModel.class);

	private final PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
	private IMap gameMap;
	private boolean clientRegistered = false;
	private boolean gameStarted = false;
	private boolean gameTerminated = false;
	private String gameTerminationDescription = "";
	private EGameStrategy gameStrategy;

	public GameModel() {
	}

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		changeSupport.addPropertyChangeListener(pcl);
		logger.debug("a listener has added this model: {}", pcl.toString());
	}

	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		changeSupport.removePropertyChangeListener(pcl);
		logger.debug("a listener has been removed from this model: {}", pcl.toString());
	}

	public void setGameMap(IMap gameMap) {
		IMap beforeMap = gameMap.deepCopy();
		this.gameMap = gameMap;
		changeSupport.firePropertyChange("gameMap", beforeMap, gameMap);
		logger.debug("game Map was changed and property was fired.");
	}

	public void setGameStarted(boolean gameStarted) {
		boolean beforeGameStarted = this.gameStarted;
		this.gameStarted = gameStarted;
		changeSupport.firePropertyChange("gameStarted", beforeGameStarted, gameStarted);
		logger.debug("game has started and property was fired.");
	}

	public void setClientRegistered(boolean clientRegistered) {
		boolean beforeClientRegistered = this.clientRegistered;
		this.clientRegistered = clientRegistered;
		changeSupport.firePropertyChange("clientRegistered", beforeClientRegistered, clientRegistered);
		logger.debug("client has successfully registered and property was fired.");
	}

	public void setGameTerminated(boolean gameTerminated) {
		boolean beforeGameTerminated = this.gameTerminated;
		this.gameTerminated = gameTerminated;
		changeSupport.firePropertyChange("gameTerminated", beforeGameTerminated, gameTerminated);
		logger.debug("game has been terminated and property was fired.");
	}

	public void setGameTerminationDescription(String gameTerminationDescription) {
		String beforeGameTerminationDescription = this.gameTerminationDescription;
		this.gameTerminationDescription = gameTerminationDescription;
		changeSupport.firePropertyChange("gameTerminationDescription", beforeGameTerminationDescription,
				gameTerminationDescription);
		logger.debug("game game has been terminated, a description was given and property was fired.");
	}

	public void setGameStrategy(EGameStrategy gameStrategy) {
		EGameStrategy beforeGameStrategy = this.gameStrategy;
		this.gameStrategy = gameStrategy;
		changeSupport.firePropertyChange("gameStrategy", beforeGameStrategy, gameStrategy);
		logger.debug("game strategy was changed and property was fired.");
	}

	public IMap getGameMap() {
		return gameMap;
	}

	public EGameStrategy getGameStrategy() {
		return gameStrategy;
	}

	@Override
	public String toString() {
		return "GameModel [changeSupport=" + changeSupport + ", gameMap= \n" + gameMap + ", clientRegistered="
				+ clientRegistered + ", gameStarted=" + gameStarted + ", gameTerminated=" + gameTerminated
				+ ", gameTerminationDescription=" + gameTerminationDescription + "]";
	}

	/**
	 * setter ONLY for testing purpose
	 * 
	 * @param testGameMap
	 */
	public void setGameMap_TestPurpose(IMap testGameMap) {
		this.gameMap = testGameMap;
	}

}
