package clientGame;

/**
 * controls current game status
 * 
 * @author Malte
 *
 */
public enum EGameState {
	MustAct, MustWait, Lost, Won
}
