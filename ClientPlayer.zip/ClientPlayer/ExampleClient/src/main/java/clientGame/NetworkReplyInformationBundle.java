package clientGame;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import Network.NetworkPlayerRepresentation;
import clientMap.IMap;

public class NetworkReplyInformationBundle {

	private static Logger logger = LoggerFactory.getLogger(NetworkReplyInformationBundle.class);

	private EGameState gameState;
	private IMap gameMap;
	private NetworkPlayerRepresentation myPlayer;
	private NetworkPlayerRepresentation enemyPlayer;

	public NetworkReplyInformationBundle() {
	}

	/**
	 * @param gameState
	 * @param gameMap
	 * @param myPlayer
	 * @param enemyPlayer
	 */
	public NetworkReplyInformationBundle(EGameState gameState, IMap gameMap, NetworkPlayerRepresentation myPlayer,
			NetworkPlayerRepresentation enemyPlayer) {
		this.gameState = gameState;
		this.gameMap = gameMap;
		this.myPlayer = myPlayer;
		this.enemyPlayer = enemyPlayer;
		logger.debug("Network Reply Information Bundle was initially updated.");
	}

	/**
	 * @return the gameState
	 */
	public EGameState getGameState() {
		return gameState;
	}

	/**
	 * @return the gameMap
	 */
	public IMap getGameMap() {
		return gameMap;
	}

	/**
	 * @return the myPlayer
	 */
	public NetworkPlayerRepresentation getMyPlayer() {
		return myPlayer;
	}

	/**
	 * @return the enemyPlayer
	 */
	public NetworkPlayerRepresentation getEnemyPlayer() {
		return enemyPlayer;
	}

	public void updateAllInformation(EGameState gameState, IMap gameMap, NetworkPlayerRepresentation myPlayer,
			NetworkPlayerRepresentation enemyPlayer) {
		this.gameState = gameState;
		this.gameMap = gameMap;
		this.myPlayer = myPlayer;
		this.enemyPlayer = enemyPlayer;
		logger.debug("Network Reply Information Bundle was updated.");
	}

	@Override
	public String toString() {
		return "NetworkReplyInformationBundle [gameState=" + gameState + ", gameMap=\n" + gameMap + ", myPlayer="
				+ myPlayer + ", enemyPlayer=" + enemyPlayer + "]";
	}

}
