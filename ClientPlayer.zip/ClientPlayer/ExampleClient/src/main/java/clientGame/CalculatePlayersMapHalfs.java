package clientGame;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.Coordinate;
import clientMap.IMap;

/**
 * is a support class for the game strategy and calculates: (1) dimension of
 * map, (2) dimension of treasureZone and opponentFortZone
 * 
 * @author Malte
 *
 */
public class CalculatePlayersMapHalfs {

	private static Logger logger = LoggerFactory.getLogger(CalculatePlayersMapHalfs.class);

	private IMap gameMap;
	private Coordinate ownStartPosition = new Coordinate(0, 0);
	private boolean isSquare;

	private ZoneDimension treasureZone;
	private ZoneDimension opponentFortZone;

	/**
	 * @param gameMap
	 */
	public CalculatePlayersMapHalfs(IMap gameMap) {
		this.gameMap = gameMap;
		// GoF facade for correct procedure
		// [1] calculate own position
		ownStartPosition = this.gameMap.getFort();
		logger.debug("OwnPosition: {}", ownStartPosition.toString());
		// [2] rectangle or square
		this.determineFieldType();
		// [3] set zone Dimension for specific search (treasure first, opponent fort
		// second)
		if (isSquare) {
			logger.debug("game Map is square");
			this.setZoneDimension_Square();
		} else {
			logger.debug("game Map is rectangle");
			this.setZoneDimension_Rectangle();
		}
	}

	// [2]
	// -------------------------------------------------------------------------------------------------

	/**
	 * determines whether this is a rectangle or a square
	 */
	private void determineFieldType() {
		isSquare = this.gameMap.getXDimension() == this.gameMap.getYDimension();
	}

	/**
	 * @return the isSquare
	 */
	public boolean isSquare() {
		return isSquare;
	}

	// [3]
	// -------------------------------------------------------------------------------------------------
	/**
	 * sets zoneDimension for treasure-Hunt and (afterwards) opponent's fort-Hunt
	 */
	private void setZoneDimension_Square() {
		int x = this.ownStartPosition.getX_coord();
		int y = this.ownStartPosition.getY_coord();
		// case startPosition is: above
		if (x <= 5 && y <= 5) {
			System.out.println("Square oben");
			this.treasureZone = new ZoneDimension(0, 9, 0, 4);
			this.opponentFortZone = new ZoneDimension(0, 9, 5, 9);
		}
		// case startPosition is: below
		else if (y > 5) {
			System.out.println("Square unten");
			this.treasureZone = new ZoneDimension(0, 9, 5, 9);
			this.opponentFortZone = new ZoneDimension(0, 9, 0, 4);
		}
		// case startPosition is: right
		else if (x > 5) {
			System.out.println("Square rechts");
			this.treasureZone = new ZoneDimension(5, 9, 0, 9);
			this.opponentFortZone = new ZoneDimension(0, 4, 0, 9);
		}
		// case startPosition is: left
		else {
			System.out.println("Square links");
			this.treasureZone = new ZoneDimension(0, 4, 0, 9);
			this.opponentFortZone = new ZoneDimension(5, 9, 0, 9);
		}
	}

	/**
	 * sets zoneDimension for treasure-Hunt and (afterwards) opponent's fort-Hunt
	 */
	private void setZoneDimension_Rectangle() {
		int x = this.ownStartPosition.getX_coord();
		int y = this.ownStartPosition.getY_coord();

		if (this.gameMap.getXDimension() == 5) {
			// case startPosition is: above
			if (y > 10) {
				this.treasureZone = new ZoneDimension(0, 4, 0, 9);
				this.opponentFortZone = new ZoneDimension(0, 4, 10, 19);
			}
			// case startPosition is: below
			else {
				this.treasureZone = new ZoneDimension(0, 4, 10, 19);
				this.opponentFortZone = new ZoneDimension(0, 4, 0, 9);
			}

		} else {
			// case startPosition is: right
			if (x > 10) {
				this.treasureZone = new ZoneDimension(10, 19, 0, 4);
				this.opponentFortZone = new ZoneDimension(0, 9, 0, 4);
			}
			// case startPosition is: left
			else {
				this.treasureZone = new ZoneDimension(0, 9, 0, 4);
				this.opponentFortZone = new ZoneDimension(10, 19, 0, 4);
			}

		}
	}

	// -------------------------------------------------------------------------------------------------

	public Coordinate getOwnStartPosition() {
		return ownStartPosition;
	}

	public ZoneDimension getTreasureZone() {
		return treasureZone;
	}

	public ZoneDimension getOpponentFortZone() {
		return opponentFortZone;
	}

	/**
	 * string-representation for testing and debugging purpose
	 */
	public String toString() {
		String shape = (this.isSquare) ? "square" : "rectangle";

		return "Meta: " + shape + ", treasureZone:" + this.treasureZone.toString() + ", opponentFortZone:"
				+ this.opponentFortZone.toString();
	}

}
