package clientMap;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class clientMap_Test {

	// negativ
	@Test
	public void gridWithRightDimensions_lookForCoordinateOutOfDimension_ThrowsMapException() {
		// arrange
		ClientHalfMap clientHalfMap = new ClientHalfMap();

		// act
		Executable testCode = () -> clientHalfMap.readMapEntry(new Coordinate(10, 2));

		// assert
		assertThrows(MapException.class, testCode,
				"ought to throw an exception because coordinate-parameter is out of bounds");
	}

}
