package clientMap;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class Coordinate_Test {

	@Test
	public void emptyObject_build_notnull() {
		Coordinate coord;

		coord = new Coordinate(0, 0);

		assertNotNull(coord);
	}

}
