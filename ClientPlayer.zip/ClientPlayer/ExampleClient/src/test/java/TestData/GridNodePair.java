package TestData;

import clientMap.Coordinate;
import clientMap.MapNode;

/**
 * bundles information about a data pair Coordinate (data1) and a correspondant
 * MapNode (data2)
 * 
 * @author Malte
 *
 */
public class GridNodePair {

	private Coordinate data1;
	private MapNode data2;

	/**
	 * @param data1
	 * @param data2
	 */
	public GridNodePair(Coordinate data1, MapNode data2) {
		super();
		this.data1 = data1;
		this.data2 = data2;
	}

	/**
	 * @return the data1
	 */
	public Coordinate getData1() {
		return data1;
	}

	/**
	 * @return the data2
	 */
	public MapNode getData2() {
		return data2;
	}

}
