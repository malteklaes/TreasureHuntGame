package clientGame;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import TestData.GridTestData;
import clientMap.ClientFullMap;
import clientMap.IMap;
import clientMap.MapGrid;

public class CalculatePlayersMapHalfs_Test {

	@ParameterizedTest
	@MethodSource("produceOwnZoneEdges")
	public void getSqaureMap_analyseGameMap_RecognizeTreasureZone(IMap gameMap, ZoneDimension treasureZone) {
		// arrange
		CalculatePlayersMapHalfs gameMapAnalyzer = new CalculatePlayersMapHalfs(gameMap);
		// act
		ZoneDimension treasureZoneDimension = gameMapAnalyzer.getTreasureZone();

		// assert
		assertEquals(treasureZone, treasureZoneDimension);
	}

	@ParameterizedTest
	@MethodSource("produceEnemyZoneEdges")
	public void getSqaureMap_analyseGameMap_RecognizeEnemysZone(IMap gameMap, ZoneDimension enemyZone) {
		// arrange
		CalculatePlayersMapHalfs gameMapAnalyzer = new CalculatePlayersMapHalfs(gameMap);
		// act
		ZoneDimension enemyZoneDimension = gameMapAnalyzer.getOpponentFortZone();

		// assert
		assertEquals(enemyZone, enemyZoneDimension);
	}

	@Test
	public void getRectangleMap_anaylseRectangleGameMap_RecoginzeOwnAndEnemysZone() {
		// arrange
		// scenario: 20x5 rectangle map, where enemys zone is on the left, own zone is
		// on the right side
		IMap gameMap = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_rectangle_20x5_1()), 20, 5);
		CalculatePlayersMapHalfs gameMapAnalyzer = new CalculatePlayersMapHalfs(gameMap);
		ZoneDimension enemyZoneDimension = new ZoneDimension(0, 9, 0, 4);
		ZoneDimension ownZoneDimension = new ZoneDimension(10, 19, 0, 4);

		// act
		ZoneDimension testEnemyDim = gameMapAnalyzer.getOpponentFortZone();
		ZoneDimension testownDim = gameMapAnalyzer.getTreasureZone();

		// assert
		assertEquals(enemyZoneDimension, testEnemyDim);
		assertEquals(ownZoneDimension, testownDim);
	}

	@Test
	public void getRectangleMap_anaylseRectangleGameMap_RecoginzeRectangleMap() {
		// arrange
		// on the right side
		IMap gameMap = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_rectangle_20x5_1()), 20, 5);
		CalculatePlayersMapHalfs gameMapAnalyzer;

		// act
		gameMapAnalyzer = new CalculatePlayersMapHalfs(gameMap);
		boolean isSquare = gameMapAnalyzer.isSquare();

		// assert
		assertEquals(false, isSquare);
	}

	private static Stream<Arguments> produceOwnZoneEdges() {
		// map where own fort is "below" (if y is big) and enemys fort is "above" (if y
		// is low)
		IMap gameMapBELOW = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_2()), 10, 10);
		// map where own fort is "above"and enemys fort is "below"
		IMap gameMapABOVE = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_3()), 10, 10);
		ZoneDimension ownFortBelow = new ZoneDimension(0, 9, 5, 9);
		ZoneDimension ownFortAbove = new ZoneDimension(0, 9, 0, 4);
		return Stream.of(Arguments.of(gameMapBELOW, ownFortBelow), Arguments.of(gameMapABOVE, ownFortAbove));
	}

	private static Stream<Arguments> produceEnemyZoneEdges() {
		// map where enemys fort is "above" (if y is low)
		IMap gameMapABOVE = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_2()), 10, 10);
		// map where own fort is "above"and enemys fort is "below"
		IMap gameMapBELOW = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_3()), 10, 10);
		ZoneDimension enemysFortBelow = new ZoneDimension(0, 9, 5, 9);
		ZoneDimension enemysFortAbove = new ZoneDimension(0, 9, 0, 4);
		return Stream.of(Arguments.of(gameMapABOVE, enemysFortAbove), Arguments.of(gameMapBELOW, enemysFortBelow));
	}

}
