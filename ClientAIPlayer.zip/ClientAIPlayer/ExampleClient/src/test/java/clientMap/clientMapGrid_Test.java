package clientMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Test;

import TestData.GridTestData;

public class clientMapGrid_Test {

	@Test
	public void EmptyHalfMap_createGrid_NewHalfMapNotEmpty() {
		// arrange
		ClientHalfMap halfMap10x5;

		// act
		halfMap10x5 = new ClientHalfMap();

		// assert
		assertNotNull(halfMap10x5);
	}

	@Test
	public void gridGras38Mountain5Water7_countCorrectlyFields_CorrectFieldsWereCounted() {
		// arrange
		MapGrid grid10x5 = new MapGrid(GridTestData.test_validGrid_rectangle_10x5_1());

		// act
		int grasNodes = grid10x5.countGrasNodes();
		int mountainNodes = grid10x5.countMountainNodes();
		int waterNodes = grid10x5.countWaterNodes();

		// assert
		assertEquals(grasNodes, 38);
		assertEquals(mountainNodes, 5);
		assertEquals(waterNodes, 7);
	}

//	@Test
//	void testGenerateGrid() {
//		// Arrange
//		MapGenerator gridBuilder = new MapGenerator();
//		int xDimension = 5;
//		int yDimension = 5;
//		int amountGrasField = 5;
//		int amountMountainField = 5;
//		int amountWaterField = 5;
//		MapGrid mapGrid = new MapGrid(amountGrasField, amountMountainField, amountWaterField);
//		mapGrid.setGridBuilder(gridBuilder);
//
//		// Act
//		MapGrid newGrid = mapGrid.generateGrid(xDimension, yDimension);
//
//		// Assert
//		assertNotNull(newGrid);
//		assertEquals(xDimension * yDimension, newGrid.getGrid().size());
//	}

//	@Test
//	void testGetField() {
//		// Arrange
//		Coordinate coordinate = new Coordinate(0, 0);
//		MapNode node = new MapNode(coordinate, ETerrainType.GRAS);
//		Map<Coordinate, MapNode> grid = new HashMap<>();
//		grid.put(coordinate, node);
//		MapGrid mapGrid = new MapGrid(grid, 0, 1, 0);
//
//		// Act
//		MapNode result = mapGrid.getField(coordinate);
//
//		// Assert
//		assertNotNull(result);
//		assertEquals(node, result);
//	}
//
//	@Test
//	void testDeepCopy() {
//		// Arrange
//		MapGenerator gridBuilder = new MapGenerator();
//		int xDimension = 5;
//		int yDimension = 5;
//		MapGrid mapGrid = new MapGrid(xDimension, yDimension);
//		mapGrid.setGridBuilder(gridBuilder);
//
//		// Act
//		I2DGrid copiedGrid = mapGrid.deepCopy();
//
//		// Assert
//		assertNotNull(copiedGrid);
//		assertTrue(copiedGrid instanceof MapGrid);
//		assertEquals(mapGrid.getGrid().size(), ((MapGrid) copiedGrid).getGrid().size());
//	}
//
//	@Test
//	void testCountGrasNodes() {
//		// Arrange
//		int xDimension = 5;
//		int yDimension = 5;
//		MapGrid mapGrid = new MapGrid(xDimension, yDimension);
//
//		// Act
//		int count = mapGrid.countGrasNodes();
//
//		// Assert
//		assertEquals(xDimension * yDimension, count);
//	}
//
//	@Test
//	void testCountMountainNodes() {
//		// Arrange
//		int xDimension = 5;
//		int yDimension = 5;
//		MapGrid mapGrid = new MapGrid(xDimension, yDimension);
//
//		// Act
//		int count = mapGrid.countMountainNodes();
//
//		// Assert
//		assertEquals(0, count);
//	}
//
//	@Test
//	void testCountWaterNodes() {
//		// Arrange
//		int xDimension = 5;
//		int yDimension = 5;
//		MapGrid mapGrid = new MapGrid(xDimension, yDimension);
//
//		// Act
//		int count = mapGrid.countWaterNodes();
//
//		// Assert
//		assertEquals(0, count);
//	}
//
//	@Test
//	void testGetNonExistingField() {
//		// Arrange
//		Coordinate coordinate = new Coordinate(10, 10);
//		MapGrid mapGrid = new MapGrid(5, 5, 0);
//
//		// Act
//		MapNode result = mapGrid.getField(coordinate);
//
//		// Assert
//		assertNull(result);
//	}

}
