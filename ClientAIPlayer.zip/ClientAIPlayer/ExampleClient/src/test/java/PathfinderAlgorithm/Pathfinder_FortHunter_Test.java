package PathfinderAlgorithm;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import TestData.GridTestData;
import clientMap.ClientFullMap;
import clientMap.MapGrid;
import messagesbase.messagesfromclient.EMove;

class Pathfinder_FortHunter_Test {

	// mockito
	@Test
	public void foundTreasureAsSteppingOnMountain_switchPath_GoUp() throws MovementException {
		// arrange
		Pathfinder_TreasureHunter pathfinderTreasureHuntingMock = mock(Pathfinder_TreasureHunter.class);
		ClientFullMap clientFullGameMap = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_1()),
				10, 10); // map is arranged, that the own player only has to go up to reach the treasure,
							// this the algorithm of AI has to find
		// act
		when(pathfinderTreasureHuntingMock.calculateNextStep(clientFullGameMap, true))
				.thenReturn(messagesbase.messagesfromclient.EMove.Up);

		// assert
		assertEquals(messagesbase.messagesfromclient.EMove.Up,
				pathfinderTreasureHuntingMock.calculateNextStep(clientFullGameMap, true));
	}

	@Test
	public void foundEnemysFortAsSteppingOnMountain_switchPath_GoUp() throws MovementException {
		// arrange
		ClientFullMap gameMap = new ClientFullMap(new MapGrid(GridTestData.test_validGrid_sqaure_10x10_2()), 10, 10);
		Pathfinder_FortHunter pathfinderTreasureHuntingMock = new Pathfinder_FortHunter(gameMap, 0, 9, 0, 4);
		// act
		EMove nextMove = pathfinderTreasureHuntingMock.calculateNextStep(gameMap, true);

		// assert
		assertEquals(EMove.Up, nextMove);
	}

}
