package TestData;

import java.util.Map;
import java.util.TreeMap;

import clientMap.Coordinate;
import clientMap.EFortState;
import clientMap.EPlayerPositionState;
import clientMap.ETerrainType;
import clientMap.ETreasureState;
import clientMap.MapNode;

/**
 * provides different grids (square, rectangle, halfGrids, fullGrids) for
 * testing purpose
 * 
 * @author Malte
 *
 */
public class GridTestData {

	/**
	 * dimension: 10x5
	 * 
	 * gras: 38
	 * 
	 * mountain: 5
	 * 
	 * water: 7
	 * 
	 * fort: no fort
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_rectangle_10x5_1() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 10;
		int y_dimension = 5;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 5. column
			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			}
			// 7. column
			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 9. column
			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * dimension: 10x5
	 * 
	 * gras: 38
	 * 
	 * mountain: 5
	 * 
	 * water: 7
	 * 
	 * fort: fort
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_rectangle_10x5_2() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 10;
		int y_dimension = 5;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 5. column
			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F1_P0(x, y).getData2());
					}
				}

			}
			// 7. column
			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 9. column
			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * dimension: 10x10
	 * 
	 * gras: 76
	 * 
	 * mountain: 10
	 * 
	 * water: 14
	 * 
	 * infos: fort (enemy fort in upper part and own fort in part below), treasure
	 * and both playerposition
	 * 
	 * scenario: own player almost reach onw treasure (up)
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_sqaure_10x10_1() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 10;
		int y_dimension = 10;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(gras_T0_F2_P0(x, y).getData1(), gras_T0_F2_P0(x, y).getData2()); // enemy fort
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P2(x, y).getData1(), mountain_T0_F0_P2(x, y).getData2());// enemy player
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 5. column
			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(gras_T0_F1_P0(x, y).getData1(), gras_T0_F1_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else if (x == 6) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 7) {
						grid.put(gras_T1_F0_P0(x, y).getData1(), gras_T1_F0_P0(x, y).getData2()); // here own treasure
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 7. column
			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P1(x, y).getData1(), mountain_T0_F0_P1(x, y).getData2()); // here own
																											// player
					} else if (y == 8) {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 9. column
			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * dimension: 10x10
	 * 
	 * gras: 76
	 * 
	 * mountain: 10
	 * 
	 * water: 14
	 * 
	 * infos: fort (enemy fort in upper part and own fort in part below), treasure
	 * and both playerposition
	 * 
	 * scenario: own player almost reach enemys fort (up)
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_sqaure_10x10_2() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 10;
		int y_dimension = 10;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(gras_T0_F2_P0(x, y).getData1(), gras_T0_F2_P0(x, y).getData2()); // enemy fort
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P1(x, y).getData1(), mountain_T0_F0_P1(x, y).getData2());// here own
																											// player
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P2(x, y).getData1(), mountain_T0_F0_P2(x, y).getData2());// enemy player
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 5. column
			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(gras_T0_F1_P0(x, y).getData1(), gras_T0_F1_P0(x, y).getData2()); // own fort
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else if (x == 6) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 7) {
						grid.put(gras_T1_F0_P0(x, y).getData1(), gras_T1_F0_P0(x, y).getData2()); // here own treasure
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 7. column
			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 9. column
			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * dimension: 10x10
	 * 
	 * gras: 76
	 * 
	 * mountain: 10
	 * 
	 * water: 14
	 * 
	 * infos: fort (own fort in upper part and enemy fort in part below), treasure
	 * and both playerposition
	 * 
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_sqaure_10x10_3() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 10;
		int y_dimension = 10;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(gras_T0_F1_P0(x, y).getData1(), gras_T0_F1_P0(x, y).getData2()); // own fort
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			} else if (x == 2) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P1(x, y).getData1(), mountain_T0_F0_P1(x, y).getData2()); // here own
																											// player
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P2(x, y).getData1(), mountain_T0_F0_P2(x, y).getData2());// enemy player
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 9) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 5. column
			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(gras_T0_F2_P0(x, y).getData1(), gras_T0_F2_P0(x, y).getData2()); // enemy fort
					} else if (y == 8) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else if (x == 6) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 7) {
						grid.put(gras_T1_F0_P0(x, y).getData1(), gras_T1_F0_P0(x, y).getData2()); // here own treasure
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 7. column
			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 7) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 9. column
			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 6) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 8) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}

			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * dimension: 20x5
	 * 
	 * gras: 74
	 * 
	 * mountain: 12
	 * 
	 * water: 14
	 * 
	 * infos: fort (enemy fort in left part and own fort in right part), treasure
	 * and both playerposition
	 * 
	 * scenario: own player almost reach enemys fort (up)
	 * 
	 * @return
	 */
	public static Map<Coordinate, MapNode> test_validGrid_rectangle_20x5_1() {

		Map<Coordinate, MapNode> grid = new TreeMap<>();
		int x_dimension = 20;
		int y_dimension = 5;

		for (int x = 0; x < x_dimension; x++) {
			// 1. column
			if (x == 1) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(gras_T0_F2_P0(x, y).getData1(), gras_T0_F2_P0(x, y).getData2()); // enemy fort
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P1(x, y).getData1(), mountain_T0_F0_P1(x, y).getData2());// here own
																											// player
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 3) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 5) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 7) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 9) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// ----------------------------------------------------------------------------------------------
			// 1. column
			else if (x == 11) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(gras_T0_F2_P0(x, y).getData1(), gras_T0_F1_P0(x, y).getData2()); // own fort
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P1(x, y).getData1(), mountain_T0_F0_P2(x, y).getData2());// here enemy
																											// player
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}
			// 3. column
			else if (x == 13) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 15) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 17) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(water_T0_F0_P0(x, y).getData1(), water_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			}

			else if (x == 19) {
				for (int y = 0; y < y_dimension; y++) {
					if (y == 1) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 2) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else if (y == 3) {
						grid.put(mountain_T0_F0_P0(x, y).getData1(), mountain_T0_F0_P0(x, y).getData2());
					} else {
						grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
					}
				}
			} else {
				for (int y = 0; y < y_dimension; y++) {
					grid.put(gras_T0_F0_P0(x, y).getData1(), gras_T0_F0_P0(x, y).getData2());
				}
			}

		}
		return grid;
	}

	/**
	 * returns a gras field
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair gras_T0_F0_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Gras,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.NoPlayerPresent));
	}

	/**
	 * 
	 * returns a gras field with own fort on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair gras_T0_F1_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Gras,
						ETreasureState.NoOrUnknownTreasureState, EFortState.MyFortPresent,
						EPlayerPositionState.NoPlayerPresent));
	}

	/**
	 * returns a gras field with enemys fort on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair gras_T0_F2_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Gras,
						ETreasureState.NoOrUnknownTreasureState, EFortState.EnemyFortPresent,
						EPlayerPositionState.NoPlayerPresent));
	}

	/**
	 * returns a gras field with own treasure on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair gras_T1_F0_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Gras, ETreasureState.MyTreasureIsPresent,
						EFortState.NoOrUnknownFortState, EPlayerPositionState.NoPlayerPresent));
	}

	/**
	 * returns a gras field with own player on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair gras_T_F0_P1(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Gras,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.MyPlayerPosition));
	}

	/**
	 * returns a mountain field
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair mountain_T0_F0_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Mountain,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.NoPlayerPresent));
	}

	/**
	 * returns a mountain field with own player on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair mountain_T0_F0_P1(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Mountain,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.MyPlayerPosition));
	}

	/**
	 * returns a mountain field with enemy player on it
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair mountain_T0_F0_P2(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Mountain,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.EnemyPlayerPosition));
	}

	/**
	 * returns a water field
	 * 
	 * @param x_coord
	 * @param y_coord
	 * @return
	 */
	private static GridNodePair water_T0_F0_P0(int x_coord, int y_coord) {
		return new GridNodePair(new Coordinate(x_coord, y_coord),
				new MapNode(new Coordinate(x_coord, y_coord), ETerrainType.Water,
						ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
						EPlayerPositionState.NoPlayerPresent));
	}
}
