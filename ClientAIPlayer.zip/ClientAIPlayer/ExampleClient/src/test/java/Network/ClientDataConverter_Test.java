package Network;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Test;

import TestData.GridTestData;
import clientMap.ClientHalfMap;
import clientMap.Coordinate;
import clientMap.ETerrainType;
import clientMap.IMap;
import clientMap.MapGrid;
import clientMap.MapNode;
import messagesbase.messagesfromclient.ETerrain;
import messagesbase.messagesfromclient.PlayerHalfMap;
import messagesbase.messagesfromserver.EFortState;
import messagesbase.messagesfromserver.EPlayerPositionState;
import messagesbase.messagesfromserver.ETreasureState;
import messagesbase.messagesfromserver.FullMapNode;

public class ClientDataConverter_Test {

	@Test
	public void haveClientDataConverter_convertToFullMapNode_GotMapNode() throws ConversionException {
		// arrange
		FullMapNode fullMapNode = new FullMapNode(ETerrain.Grass, EPlayerPositionState.BothPlayerPosition,
				ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState, 6, 6);
		ClientDataConverter cdc = new ClientDataConverter();
		MapNode expected = new MapNode(new Coordinate(6, 6), ETerrainType.Gras,
				clientMap.ETreasureState.NoOrUnknownTreasureState, clientMap.EFortState.NoOrUnknownFortState,
				clientMap.EPlayerPositionState.BothPlayerPosition);

		// act
		MapNode result = cdc.convertFullMapNode_SC(fullMapNode);

		// assert
		assertEquals(expected, result);

	}

	@Test
	public void haveClientDataConverter_convertHalfMap_ResultNotNull() {
		// arrange
		IMap gameMap = new ClientHalfMap(new MapGrid(GridTestData.test_validGrid_rectangle_10x5_1()));
		ClientDataConverter cdc = new ClientDataConverter();
		PlayerHalfMap result;

		// act
		result = cdc.convertHalfMap_CS("ID", gameMap);

		// assert
		assertNotNull(result);

	}

}
