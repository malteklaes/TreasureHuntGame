package View;

/**
 * Exception regarding: there was an error with displaying game related
 * information
 * 
 * @author Malte
 *
 */
public class DisplayException extends Exception {
	public DisplayException(String message) {
		super("regarding display game information: " + message);
	}
}
