package View;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import client.main.MainClient;
import clientGame.EGameStrategy;
import clientGame.GameModel;
import clientMap.ClientFullMap;
import clientMap.Coordinate;
import clientMap.EFortState;
import clientMap.EPlayerPositionState;
import clientMap.ETerrainType;
import clientMap.ETreasureState;
import clientMap.IMap;

/**
 * is a listener to an observable (game model) and shows all relevant
 * information during a game to console
 * 
 * @author Malte
 *
 */
public class CLIGameView implements PropertyChangeListener, IView {

	private static Logger logger = LoggerFactory.getLogger(CLIGameView.class);

	private static final String gras = Colors.GREEN + "\uD83C\uDF33" + Colors.RESET + " ";
	private static final String mountain = Colors.RED + "\u26F0" + Colors.RESET + " ";
	private static final String water = Colors.BLUE + "\uD83C\uDF0A" + Colors.RESET + " ";
	private static final String ownFort = Colors.WHITE_BOLD + "F" + Colors.RESET + " ";
	private static final String enemyFort = Colors.BLACK_BOLD + "F" + Colors.RESET + " ";
	private static final String figure = Colors.CYAN_BOLD + "P" + Colors.RESET + " ";
	private static final String enemyFigure = Colors.BLACK_BOLD + "E" + Colors.RESET + " ";
	private static final String bothFigure = Colors.PURPLE_BOLD_BRIGHT + "X" + Colors.RESET + " ";
	private static final String treasure = Colors.YELLOW_BOLD + "T" + Colors.RESET + " ";

	private String gameStrategy;
	private boolean treasureFound;
	private int gameRound;

	private MainClient clientController;

	/**
	 * @param clientController
	 * @param gameModel
	 */
	public CLIGameView(MainClient clientController, GameModel gameModel) {
		this.clientController = clientController;
		this.gameStrategy = "";
		this.treasureFound = false;
		gameRound = 0;
		gameModel.addPropertyChangeListener(this);
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		Object source = evt.getSource();
		Object newValue = evt.getNewValue();

		if (source instanceof GameModel) {

			if (evt.getPropertyName().equals("gameMap") && newValue instanceof ClientFullMap) {
				ClientFullMap newMap = (ClientFullMap) evt.getNewValue();
				try {
					this.show(this.drawGameMap(newMap));
					logger.debug("the game map was succesfully displayed.");
				} catch (DisplayException e) {
					logger.error("the game could not succesfully displayed. This error occured: {}", e);
					e.printStackTrace();
				}
			}

			else if (evt.getPropertyName().equals("gameStarted") && newValue instanceof Boolean) {
				this.show(Colors.CYAN_BOLD + "Game has started: " + ((boolean) evt.getNewValue()) + Colors.RESET);
				logger.debug("the game start status was succesfully displayed.");
			} else if (evt.getPropertyName().equals("clientRegistered") && newValue instanceof Boolean) {
				this.show(Colors.CYAN_BOLD + "Client has registered: " + ((boolean) evt.getNewValue()) + Colors.RESET);
				logger.debug("the client registration approval was successfully displayed.");
			} else if (evt.getPropertyName().equals("gameTerminated") && newValue instanceof Boolean) {
				this.show(Colors.CYAN_BOLD + "Game has terminated: " + ((boolean) evt.getNewValue()) + Colors.RESET);
				logger.debug("the game termination status was successfully displayed.");
			} else if (evt.getPropertyName().equals("gameTerminationDescription") && newValue instanceof String) {
				this.show(Colors.RED_UNDERLINED + "Game result: " + ((String) evt.getNewValue()) + Colors.RESET);
				logger.debug("the game termination description was successfully displayed.");
			} else if (evt.getPropertyName().equals("gameStrategy") && newValue instanceof EGameStrategy) {
				this.show(Colors.CYAN_UNDERLINED + "Game strategy: "
						+ this.convertEGameStratetgyToString((EGameStrategy) evt.getNewValue()) + Colors.RESET);
				logger.debug("the new game strategy was successfully displayed.");
			}
		}

	}

	/**
	 * converts a game strategy to output (String) in order do be able to display
	 * this information
	 * 
	 * @param gameStrategy
	 * @return
	 */
	private String convertEGameStratetgyToString(EGameStrategy gameStrategy) {
		switch (gameStrategy) {
		case EnemyFortHunting:
			this.gameStrategy = Colors.PURPLE_UNDERLINED + "Strategy: Enemy Fort Hunting." + Colors.RESET;
			this.treasureFound = true;
			logger.debug("game strategy has been successfully matched and updated.");
			return "Treasure collected! \nEnemys Fort Hunting Strategy";
		default:
			this.gameStrategy = Colors.PURPLE_UNDERLINED + "Strategy: Treasure Hunting." + Colors.RESET;
			logger.debug("game strategy has been successfully matched and updated.");
			return "Treasure Hunting Strategy";
		}

	}

	@Override
	public void show(String information) {
		logger.debug("fresh information are about to be displayed in the console.");
		System.out.println(Colors.YELLOW_BOLD + "=============== GAME INFO ==============" + Colors.RESET);
		System.out.println(information);
		System.out.println(Colors.YELLOW_BOLD + "========================================" + Colors.RESET);
	}

	@Override
	public String drawGameMap(IMap gameMap) throws DisplayException {
		if (gameMap != null) {
			int max_x_size = gameMap.getXDimension();
			int max_y_size = gameMap.getYDimension();

			String result = "\n";
			Coordinate drawCoordinate = new Coordinate(0, 0);
			for (int y = 0; y <= max_y_size; y++) {
				for (int x = 0; x <= max_x_size; x++) {
					drawCoordinate.setX_coord(x);
					drawCoordinate.setY_coord(y);
					if (gameMap.getGrid().getField(drawCoordinate) != null) {
						ETerrainType terrainType = gameMap.getGrid().getField(drawCoordinate).getTerrainType();
						// [1] player positions
						if (gameMap.getGrid().getField(drawCoordinate)
								.getPlayerPositionState() == EPlayerPositionState.MyPlayerPosition) {
							result += figure;
						} else if (gameMap.getGrid().getField(drawCoordinate)
								.getPlayerPositionState() == EPlayerPositionState.EnemyPlayerPosition) {
							result += enemyFigure;
						} else if (gameMap.getGrid().getField(drawCoordinate)
								.getPlayerPositionState() == EPlayerPositionState.BothPlayerPosition) {
							result += bothFigure;
						}
						// [2] treasure present
						else if (gameMap.getGrid().getField(drawCoordinate)
								.getTreasureState() == ETreasureState.MyTreasureIsPresent) {
							result += treasure;
						}
						// [3] fort present
						else if (gameMap.getGrid().getField(drawCoordinate)
								.getFortState() == EFortState.MyFortPresent) {
							result += ownFort;
						} else if (gameMap.getGrid().getField(drawCoordinate)
								.getFortState() == EFortState.EnemyFortPresent) {
							result += enemyFort;
						}
						// [4] regular fields position
						else if (gameMap.getGrid().getField(drawCoordinate)
								.getFortState() == EFortState.NoOrUnknownFortState
								&& gameMap.getGrid().getField(drawCoordinate)
										.getPlayerPositionState() == EPlayerPositionState.NoPlayerPresent) {
							switch (terrainType) {
							case Gras:
								result += gras;
								break;
							case Mountain:
								result += mountain;
								break;
							case Water:
								result += water;
								break;
							}
						}
					}

				}
				result += "\n";
			}

			// add games round
			this.gameRound++;
			result += "Spielrunde: ";
			result += (this.gameRound < 100) ? this.gameRound + "\n"
					: Colors.RED + this.gameRound + Colors.RESET + "\n";
			// add if treasure is found
			result += (!this.treasureFound) ? Colors.BLACK + "Treasure not yet found." + Colors.RESET + "\n"
					: Colors.YELLOW + "Treasure found." + Colors.RESET + "\n";
			// add strategy
			result += this.gameStrategy;
			logger.debug("all game related information can properly be displayed.");
			return result;
		} else {
			logger.error("an error has been occured while trying to print game map and all relevant information.");
			throw new DisplayException(
					"an error has been occured while trying to print game map and all relevant information.");
		}
	}

}
