package clientGame;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import PathfinderAlgorithm.MovementException;
import PathfinderAlgorithm.Pathfinder_FortHunter;
import PathfinderAlgorithm.Pathfinder_TreasureHunter;
import clientMap.Coordinate;
import clientMap.EFortState;
import clientMap.ETreasureState;
import clientMap.IMap;
import clientMap.MapNode;

/**
 * AI: handles and manage everything since MainClient is in play-Mode, so is an
 * AI to proceed in the game by using a pathfinder (for next step calculation)
 * and manage to switch to different strategy, as soon as the own treasure is
 * found
 * 
 * @author Malte
 *
 */
public class GameController {

	private static Logger logger = LoggerFactory.getLogger(GameController.class);

	private GameModel gameModel;
	private boolean recordedPathSet;
	private NetworkReplyInformationBundle netReplyInfoBundle;
	private Pathfinder_TreasureHunter pathfinder_treasureHunter;
	private Pathfinder_FortHunter pathfinder_FortHunter;
	private boolean phaseOneTreasureAiming;
	private boolean phaseTwoEnemyFortAiming;
	private CalculatePlayersMapHalfs calculatePlayersMapHalfs;

	/**
	 * @param gameModel
	 */
	public GameController(GameModel gameModel, NetworkReplyInformationBundle netReplyInfoBundle) {
		this.gameModel = gameModel;
		this.netReplyInfoBundle = netReplyInfoBundle;
		this.recordedPathSet = false;
		this.phaseOneTreasureAiming = true;
		this.phaseTwoEnemyFortAiming = false;
	}

	/**
	 * GoF facade for the procedure: first the pathfinder is set up, than depending
	 * on the game state (whether treasure has been found), the player changes
	 * strategy by change from own half to opponent half
	 * 
	 * @return
	 * @throws MovementException
	 */
	public messagesbase.messagesfromclient.EMove decideNextMovement() throws MovementException {
		// sets and calculates initially condition for game
		if (!this.recordedPathSet) {
			this.recordedPathSet = true;
			// [1] set up calculatePlayersMapHalfs
			this.calculatePlayersMapHalfs = new CalculatePlayersMapHalfs(this.gameModel.getGameMap());
			logger.debug("players position was calculated.");

			// [2] set up pathfinder
			this.setUpPathfinder(this.calculatePlayersMapHalfs.getTreasureZone(),
					this.calculatePlayersMapHalfs.getOpponentFortZone());
			logger.debug("pathfinder was successfully set up.");
		}

		// [3] update strategy (treasure-Hunt or opponent's fort-Hunt)
		this.updateStrategy();
		if (phaseOneTreasureAiming && !phaseTwoEnemyFortAiming) {
			logger.info("treasure finding strategy");
			this.gameModel.setGameStrategy(EGameStrategy.TreasureHunting);
			return pathfinder_treasureHunter.calculateNextStep(this.gameModel.getGameMap(), this.treasureInSight());
		} else {
			logger.info("enemy fort finding strategy");
			this.gameModel.setGameStrategy(EGameStrategy.EnemyFortHunting);
			return pathfinder_FortHunter.calculateNextStep(this.gameModel.getGameMap(), this.fortInSight());
		}
	}

	/**
	 * integrate a chosen pathfind-strategy/-algorithm
	 * 
	 * @throws MovementException
	 */
	private void setUpPathfinder(ZoneDimension treasureZone, ZoneDimension opponentFortZone) throws MovementException {
		IMap gameMap = this.gameModel.getGameMap();

		// [1] sets up pathfinder to find own treasure
		this.pathfinder_treasureHunter = new Pathfinder_TreasureHunter(gameMap, treasureZone.getX_min(),
				treasureZone.getX_max(), treasureZone.getY_min(), treasureZone.getY_max());

		// [2] sets up pathfinder to find enemys fort
		this.pathfinder_FortHunter = new Pathfinder_FortHunter(gameMap, opponentFortZone.getX_min(),
				opponentFortZone.getX_max(), opponentFortZone.getY_min(), opponentFortZone.getY_max());
	}

	/**
	 * supports strategy by retrieving information whether a treasure is found
	 */
	private void updateStrategy() {
		if (this.netReplyInfoBundle != null && this.netReplyInfoBundle.getMyPlayer() != null) {
			phaseOneTreasureAiming = (this.netReplyInfoBundle.getMyPlayer().hasCollectedTreasure()) ? false : true;
			phaseTwoEnemyFortAiming = (this.netReplyInfoBundle.getMyPlayer().hasCollectedTreasure()) ? true : false;
		}
	}

	/**
	 * supports pathfinder and messages if treasure is in sight but yet not
	 * collected
	 * 
	 * @return
	 */
	private boolean treasureInSight() {
		if (this.gameModel != null && this.gameModel.getGameMap() != null
				&& this.gameModel.getGameMap().getGrid() != null) {
			for (Map.Entry<Coordinate, MapNode> elem : this.gameModel.getGameMap().getGrid().getGrid().entrySet()) {
				if (elem.getValue().getTreasureState() == ETreasureState.MyTreasureIsPresent) {
					logger.debug("treasure has been sighted.");
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * supports pathfinder and messages if enemys fort is in sight but yet not
	 * collected
	 * 
	 * @return
	 */
	private boolean fortInSight() {
		if (this.gameModel != null && this.gameModel.getGameMap() != null
				&& this.gameModel.getGameMap().getGrid() != null) {
			for (Map.Entry<Coordinate, MapNode> elem : this.gameModel.getGameMap().getGrid().getGrid().entrySet()) {
				if (elem.getValue().getFortState() == EFortState.EnemyFortPresent) {
					logger.debug("enemys fort has been sighted.");
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * string-representation for testing and debugging purpose
	 */
	public String toString() {
		return "GameController: " + this.gameModel.toString();
	}

	/**
	 * getter only for testing purpose
	 * 
	 * @return
	 */
	public GameModel getGameModel_TESTING() {
		return gameModel;
	}
}
