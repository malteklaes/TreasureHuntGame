package clientGame;

/**
 * maps currently selected strategy
 * 
 * @author Malte
 *
 */
public enum EGameStrategy {
	TreasureHunting, EnemyFortHunting

}
