package Network;

import clientGame.NetworkReplyInformationBundle;
import clientMap.IMap;

public interface INetworkController {

	/**
	 * register a player at the server
	 * 
	 * @return
	 * @throws RegistrationException
	 */
	public boolean registerPlayer() throws RegistrationException;

	/**
	 * register the players half map at the server
	 * 
	 * @param gameMap
	 * @throws RegisterPlayerHalfMapException
	 */
	public void registerPlayerHalfMap(IMap gameMap) throws RegisterPlayerHalfMapException;

	/**
	 * request the game state from the server and updates the incoming
	 * netReplyInfoBundle with fresh information
	 * 
	 * @param netReplyInfoBundle
	 * @throws RequestGameStateException
	 * @throws ConversionException
	 */
	public void requestGameState(NetworkReplyInformationBundle netReplyInfoBundle)
			throws RequestGameStateException, ConversionException;

	/**
	 * sends the movement, which has been calculated and provided as parameter to
	 * the server
	 * 
	 * @param nextStep
	 * @throws SendPlayerMovementExcpetion
	 */
	public void sendPlayerMovement(messagesbase.messagesfromclient.EMove nextStep) throws SendPlayerMovementExcpetion;

}
