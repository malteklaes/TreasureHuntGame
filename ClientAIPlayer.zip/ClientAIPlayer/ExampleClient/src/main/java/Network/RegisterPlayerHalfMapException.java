package Network;

/**
 * Exception regarding: register player with players half map went wrong
 * 
 * @author Malte
 *
 */
public class RegisterPlayerHalfMapException extends Exception {

	public RegisterPlayerHalfMapException(String message) {
		super("regarding registration of clients half map: " + message);
	}

}
