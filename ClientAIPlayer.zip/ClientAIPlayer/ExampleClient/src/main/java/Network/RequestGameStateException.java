package Network;

/**
 * Exception regarding: request a a game state form server
 * 
 * @author Malte
 *
 */
public class RequestGameStateException extends Exception {
	public RequestGameStateException(String message) {
		super("regarding request game state from server: " + message);
	}

}
