package Network;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import clientGame.EGameState;
import clientGame.NetworkReplyInformationBundle;
import clientMap.IMap;
import messagesbase.ResponseEnvelope;
import messagesbase.UniquePlayerIdentifier;
import messagesbase.messagesfromclient.ERequestState;
import messagesbase.messagesfromclient.PlayerHalfMap;
import messagesbase.messagesfromclient.PlayerMove;
import messagesbase.messagesfromclient.PlayerRegistration;
import messagesbase.messagesfromserver.GameState;
import messagesbase.messagesfromserver.PlayerState;
import reactor.core.publisher.Mono;

/**
 * this class connects with a distant server via API and endpoint management and
 * manages all interaction between this client and the targeted server
 * 
 * @author Malte
 *
 */
public class ClientNetworkController implements INetworkController {

	private static Logger logger = LoggerFactory.getLogger(ClientNetworkController.class);

	private static final String STUDENT_FIRSTNAME = "Malte";
	private static final String STUDENT_LASTNAME = "Klaes";
	private static final String STUDENT_UACCOUNT = "maltek28";

	private WebClient baseWebClient = null;
	private ClientDataConverter dataConverter;
	private String gameID;
	private String playerID;

	/**
	 * @param serverBaseUrl (not null)
	 * @param gameId        (not null)
	 */
	public ClientNetworkController(String serverBaseUrl, String gameId) {
		this.dataConverter = new ClientDataConverter();
		this.baseWebClient = WebClient.builder().baseUrl(serverBaseUrl + "/games")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE)
				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_XML_VALUE).build();
		this.gameID = gameId;

	}

	@Override
	public boolean registerPlayer() throws RegistrationException {
		PlayerRegistration playerReg = new PlayerRegistration(STUDENT_FIRSTNAME, STUDENT_LASTNAME, STUDENT_UACCOUNT);

		Mono<ResponseEnvelope> webAccess = baseWebClient.method(HttpMethod.POST).uri("/" + this.gameID + "/players")
				.body(BodyInserters.fromValue(playerReg)).retrieve().bodyToMono(ResponseEnvelope.class);

		ResponseEnvelope<UniquePlayerIdentifier> resultReg = webAccess.block();

		if (resultReg.getState() == ERequestState.Error) {
			logger.error("Client error in regsiterPlayer() " + resultReg.getExceptionMessage());
			throw new RegistrationException(
					"Client error in regsiterPlayer(), errormessage: " + resultReg.getExceptionMessage());
		} else {
			UniquePlayerIdentifier uniqueID = resultReg.getData().get();
			this.playerID = uniqueID.getUniquePlayerID();
			logger.info("Client registered successfully.");
		}
		return this.playerID != null;
	}

	@Override
	public void registerPlayerHalfMap(IMap gameMap) throws RegisterPlayerHalfMapException {

		// [1] convert gameMap to halfMap
		PlayerHalfMap playerHalfMap = new PlayerHalfMap();
		playerHalfMap = dataConverter.convertHalfMap_CS(playerID, gameMap);

		// [2] send it via block
		Mono<ResponseEnvelope> webAccess = baseWebClient.method(HttpMethod.POST).uri("/" + this.gameID + "/halfmaps")
				.body(BodyInserters.fromValue(playerHalfMap)).retrieve().bodyToMono(ResponseEnvelope.class);

		ResponseEnvelope<GameState> resultReg = webAccess.block();

		if (resultReg.getState() == ERequestState.Error) {
			logger.error(
					"Client could not register the send half map, errormessage: " + resultReg.getExceptionMessage());
			throw new RegisterPlayerHalfMapException(
					"Client could not register the send half map, errormessage: " + resultReg.getExceptionMessage());
		} else {
			logger.info("Client has registered halfmap successfully.");
		}

	}

	@Override
	public void requestGameState(NetworkReplyInformationBundle netReplyInfoBundle)
			throws RequestGameStateException, ConversionException {
		Mono<ResponseEnvelope> webAccess = baseWebClient.method(HttpMethod.GET)
				.uri("/" + this.gameID + "/states/" + this.playerID).retrieve().bodyToMono(ResponseEnvelope.class);

		ResponseEnvelope<GameState> requestResult = webAccess.block();

		if (requestResult.getState() == ERequestState.Error) {
			logger.error("There was an error with requesting state (getState()), errormessage: "
					+ requestResult.getExceptionMessage());
			throw new RequestGameStateException("There was an error with requesting state (getState()), errormessage: "
					+ requestResult.getExceptionMessage());
		} else {
			logger.info("request game state successfully.");
		}

		// [1] get gameState
		GameState recieveGameState = null;
		if (requestResult.getData().isPresent()) {
			recieveGameState = requestResult.getData().get();
		} else {
			logger.info("query game state: nothing received from server.");
		}
		// [2] find client
		PlayerState recieveMyPlayerState = filterPlayer(recieveGameState, false);
		if (recieveMyPlayerState == null) {
			logger.error(
					"own player could not recieved from server, errormessage: " + requestResult.getExceptionMessage());
			throw new RequestGameStateException(
					"own player could not recieved from server, errormessage: " + requestResult.getExceptionMessage());
		} else {
			logger.info("own player received successfully from server.");
		}
		NetworkPlayerRepresentation myPlayer = this.dataConverter.convertPlayerState_SC(recieveMyPlayerState);

		// [3] get egamestate
		EGameState eGameState;
		try {
			eGameState = this.dataConverter.convertEPlayerGameState_SC(recieveMyPlayerState.getState());
		} catch (ConversionException e) {
			logger.error("there has been an error while converting data with this error: {}", e);
			throw new ConversionException("there has been an error while converting data with this error: " + e);
		}

		// [4] get map
		IMap recieveGameMap = null;
		if (!recieveGameState.getMap().isEmpty()) {
			recieveGameMap = this.dataConverter.convertFullMap_SC(recieveGameState.getMap());
		}

		// [5] get players
		PlayerState recieveEnemyPlayerState = filterPlayer(recieveGameState, true);
		if (recieveEnemyPlayerState == null) {
			logger.warn("can not receive any player from server.");
		}
		NetworkPlayerRepresentation enemyPlayer = null;
		if (recieveEnemyPlayerState != null) {
			enemyPlayer = this.dataConverter.convertPlayerState_SC(recieveEnemyPlayerState);
		}

		// [6] return ClientNetworkAnswer:
		// - Entries in the constructor may vary.
		// - Initial situation to be null! e.g. recieveGameMap or enemyPlayer can both
		// be null!
		// - gameState is NEVER NULL (or it should NEVER be)
		logger.debug("Succesfully retrieve all new information from server to process them to game model.");
		netReplyInfoBundle.updateAllInformation(eGameState, recieveGameMap, myPlayer, enemyPlayer);
	}

	/**
	 * returns the player with same playerID than this out of the returned players
	 * from server
	 * 
	 * @param gameState (from server, origin for PlayerState)
	 * @param playerID
	 * @return PlayerState (matches this playerID)
	 */
	private PlayerState filterPlayer(GameState gameState, boolean findEnemy) {
		PlayerState playerState = null;
		// [1] search all players server returns and choose the one, which has the same
		// playerID than this

		for (var player : gameState.getPlayers().toArray()) {
			// [2] compares any playerID with this playerID
			if (!findEnemy && this.playerID.equals(((PlayerState) player).getUniquePlayerID())) {
				playerState = (PlayerState) player;
			} else if (findEnemy && !this.playerID.equals(((PlayerState) player).getUniquePlayerID())) {
				playerState = (PlayerState) player;
			}
		}
		logger.debug("succesfully filtered out playerstate: {}", playerState);
		return playerState;
	}

	@Override
	public void sendPlayerMovement(messagesbase.messagesfromclient.EMove nextStep) throws SendPlayerMovementExcpetion {
		PlayerMove playerMove = new PlayerMove();
		playerMove = playerMove.of(playerID, nextStep);

		Mono<ResponseEnvelope> webAccess = baseWebClient.method(HttpMethod.POST).uri("/" + gameID + "/moves")
				.body(BodyInserters.fromValue(playerMove)).retrieve().bodyToMono(ResponseEnvelope.class);

		ResponseEnvelope<PlayerMove> resultReg = webAccess.block();
		if (resultReg.getState() == ERequestState.Error) {
			logger.error(
					"There's a mistake by sending players movement., errormessage: " + resultReg.getExceptionMessage());
			throw new SendPlayerMovementExcpetion(
					"There's a mistake by sending players movement., errormessage: " + resultReg.getExceptionMessage());
		} else {
			logger.debug("sending players movement was successful! With Movement: " + nextStep);
		}
	}

	@Override
	public String toString() {
		return "ClientNetworkController [baseWebClient=" + baseWebClient + ", gameID=" + gameID + ", playerID="
				+ playerID + "]";
	}

	public String getPlayerID() {
		return playerID;
	}

}
