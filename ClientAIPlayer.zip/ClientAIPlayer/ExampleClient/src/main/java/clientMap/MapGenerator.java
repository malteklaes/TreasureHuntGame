package clientMap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Random;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * generates and validates automatically a correct map according to given
 * business rules (attributes).
 * 
 * @author Malte
 *
 */
public class MapGenerator {

	private static Logger logger = LoggerFactory.getLogger(MapGenerator.class);

	// business rules
	private int mountain_min_fields;
	private int gras_min_fields;
	private int water_min_fields;

	public MapGenerator() {
	}

	/**
	 * @param mountain_min_fields
	 * @param gras_min_fields
	 * @param water_min_fields
	 */
	public MapGenerator(int mountain_min_fields, int gras_min_fields, int water_min_fields) {
		this.mountain_min_fields = mountain_min_fields;
		this.gras_min_fields = gras_min_fields;
		this.water_min_fields = water_min_fields;
	}

	/**
	 * generates a randomly builds grid by given dimensions
	 * 
	 * @param x_dimension
	 * @param y_dimension
	 * @return MapGrid (not null and evaluated by business rules)
	 */
	public Map<Coordinate, MapNode> generateMapGrid(int x_dimension, int y_dimension) {
		logger.debug("the foundation of a grid, an Map<Coordinate, MapNode>, will be generated");
		return this.buildRandomGrid(x_dimension, y_dimension);
	}

	/**
	 * builds a random HalfMap, which is validated according to business rules: (1)
	 * right amount of min gras/mountain/water-fields, (2) right amount of water
	 * fields on the edges and (3) no islands.
	 * 
	 * @return I2DGrid (not null and evaluated by business rules)
	 */
	private Map<Coordinate, MapNode> buildRandomGrid(int x_dimension, int y_dimension) {
		logger.debug("a random grid with dimension {} x {} will be created.", x_dimension, y_dimension);
		Map<Coordinate, MapNode> grid = new TreeMap<>(); // TreeMap ordered by Comparator in Coordinate-Class
		// [1] generate random terrains
		List<ETerrainType> terrains = new ArrayList<>();
		boolean correctMapBuild = false;

		// [2] start process of automtic grid-build and -evaluation
		while (!correctMapBuild) {
			terrains = this.generateRandomTerrain();
			int counterTerrains = 0;
			Coordinate coordinate = new Coordinate(0, 0);

			// [3] initialize all nodes in new grid
			for (int x = 0; x < x_dimension; x++) {
				for (int y = 0; y < y_dimension; y++) {
					coordinate = new Coordinate(x, y);
					MapNode value = new MapNode(coordinate, terrains.get(counterTerrains),
							ETreasureState.NoOrUnknownTreasureState, EFortState.NoOrUnknownFortState,
							EPlayerPositionState.NoPlayerPresent);
					grid.put(coordinate, value);
					counterTerrains++;
				}
			}

			// [4] check for false edges (too many water fields on edges)
			MapValidator mapValidatorFieldAmount = new MapValidator(
					new MapGrid(grid, this.mountain_min_fields, this.gras_min_fields, this.water_min_fields));
			correctMapBuild = mapValidatorFieldAmount.checkForEnoughFields(gras_min_fields, mountain_min_fields,
					water_min_fields, x_dimension, y_dimension);

			// [5] check for false edges (too many water fields on edges)
			if (correctMapBuild) {
				MapValidator mapValidatorEdges = new MapValidator(
						new MapGrid(grid, this.mountain_min_fields, this.gras_min_fields, this.water_min_fields));
				correctMapBuild = mapValidatorEdges.checkForWaterOnEdge(x_dimension, y_dimension);
			}

			// [6] check for false islands
			if (correctMapBuild) {
				Map<Coordinate, MapNode> gridTestForIsland = new TreeMap<>();
				for (Entry<Coordinate, MapNode> entry : grid.entrySet()) {
					gridTestForIsland.put(entry.getKey().deepCopy(), entry.getValue().deepCopy());
				}
				MapValidator mapValidatorIslands = new MapValidator(new MapGrid(gridTestForIsland,
						this.mountain_min_fields, this.gras_min_fields, this.water_min_fields));
				correctMapBuild = mapValidatorIslands.checkForIsland(x_dimension, y_dimension);
			}

		}
		logger.debug("a final, random grid was created: ", grid.toString());
		return grid;
	}

	/**
	 * search for a good place for a fort on grid with this strategy: Select
	 * gras-field in the center of the grid and gradual search with a breadth-first
	 * search for an alternative field, if selected center wasn't a gras-field in
	 * the first place.
	 * 
	 * @param grid        (not null)
	 * @param x_dimension (business rule)
	 * @param y_dimension (business rule)
	 * @return Coordinate (is a grass field, should not be null since business rule
	 *         is that there is at least mountain_min_fields amount of gras-field in
	 *         a given grid)
	 */
	public Coordinate searchForOptimalFortNode(I2DGrid grid, int x_dimension, int y_dimension) {
		logger.debug("a search for an optimal fort node has been started.");
		// [1] choose center point, as the optimal point to each side
		Coordinate centerPoint = new Coordinate(x_dimension / 2, y_dimension / 2);
		// [2] if center point is already a gras-field, than search is done already
		if (grid.getField(centerPoint).getTerrainType() == ETerrainType.Gras) {
			logger.debug("a optimal fort node place has been found here: {}.", centerPoint);
			return centerPoint;
		}

		// [3] breadth-first search for closest gras-field to the origin centerPoint
		Queue<Coordinate> queue = new LinkedList<>();
		boolean[][] visited = new boolean[y_dimension][x_dimension];
		queue.add(centerPoint);
		visited[centerPoint.getY_coord()][centerPoint.getX_coord()] = true;

		while (!queue.isEmpty()) {
			Coordinate currentPoint = queue.remove();
			// [4] if current point is already successful
			if (grid.getField(currentPoint).getTerrainType() == ETerrainType.Gras) {
				logger.debug("a optimal fort node place has been found here: {}.", currentPoint);
				return currentPoint;
			}

			// [5] add unvisited neighbours to queue
			if (currentPoint.getX_coord() > 0 && !visited[centerPoint.getY_coord()][centerPoint.getX_coord() - 1]) {
				queue.add(new Coordinate(centerPoint.getX_coord() - 1, centerPoint.getY_coord()));
				visited[centerPoint.getY_coord()][centerPoint.getX_coord() - 1] = true;
			}
			if (currentPoint.getX_coord() < (x_dimension - 1)
					&& !visited[centerPoint.getY_coord()][centerPoint.getX_coord() + 1]) {
				queue.add(new Coordinate(centerPoint.getX_coord() + 1, centerPoint.getY_coord()));
				visited[centerPoint.getY_coord()][centerPoint.getX_coord() + 1] = true;
			}
			if (currentPoint.getY_coord() > 0 && !visited[centerPoint.getY_coord() - 1][centerPoint.getX_coord()]) {
				queue.add(new Coordinate(centerPoint.getX_coord(), centerPoint.getY_coord() - 1));
				visited[centerPoint.getY_coord() - 1][centerPoint.getX_coord()] = true;
			}
			if (currentPoint.getX_coord() < (y_dimension - 1)
					&& !visited[centerPoint.getY_coord() + 1][centerPoint.getX_coord()]) {
				queue.add(new Coordinate(centerPoint.getX_coord() + 1, centerPoint.getY_coord()));
				visited[centerPoint.getY_coord() + 1][centerPoint.getX_coord()] = true;
			}

		}
		// should never be the case since the business rules demands more than 0
		// gras-field in a grid
		logger.error("no field for the player fort was found, that should not be the case!");
		return null;
	}

	/**
	 * generates a List of ETerrainType, which are randomly chosen and fulfill
	 * map-concerning minimum requirement business rule
	 * 
	 * business rule: (1) min: 5 mountain, 24 gras, 7 water
	 * 
	 * @return List<ETerrainType> (min: 5 mountain, 24 gras, 7 water)
	 */
	private List<ETerrainType> generateRandomTerrain() {
		// [1] generate help-List with all fix field-terrains
		List<ETerrainType> gridPrototyp = new ArrayList<>();

		gridPrototyp.addAll(Collections.nCopies(mountain_min_fields, ETerrainType.Mountain));
		gridPrototyp.addAll(Collections.nCopies(gras_min_fields, ETerrainType.Gras));
		gridPrototyp.addAll(Collections.nCopies(water_min_fields, ETerrainType.Water));

		// [2] fill up the rest of 36 fields by randomly chosen fields
		Random randomNum = new Random();
		int randNum = 0;

		for (int i = 0; i < 14; i++) {
			randNum = randomNum.nextInt(10);
			// chance to be mountain is 0,30
			if (Arrays.asList(2, 3, 6).contains(randNum)) {
				gridPrototyp.add(ETerrainType.Mountain);
			}
			// chance to be water is 0,20
			else if (Arrays.asList(7).contains(randNum)) {
				gridPrototyp.add(ETerrainType.Water);
			} // chance to be mountain is 0,5
			else {
				gridPrototyp.add(ETerrainType.Gras);
			}
		}

		// [3] shuffle help-List
		Collections.shuffle(gridPrototyp);
		logger.debug(
				"ETerraint types has been succesfully distributed to the map, gras field: {}#, mountain field: {}# and water field: {}#.",
				Collections.frequency(gridPrototyp, ETerrainType.Gras),
				Collections.frequency(gridPrototyp, ETerrainType.Mountain),
				Collections.frequency(gridPrototyp, ETerrainType.Water));
		return gridPrototyp;
	}

	/**
	 * generate a whole Map only from a given list without further field
	 * specifiations
	 * 
	 * @param nodeList
	 * @return Map<Coordinate, MapNode>
	 */
	public Map<Coordinate, MapNode> generateGridFromList(List<MapNode> nodeList) {
		Map<Coordinate, MapNode> result = new TreeMap();
		for (MapNode mapNode : nodeList) {
			result.put(new Coordinate(mapNode.getCoordinate()), mapNode);
		}
		return result;
	}

}
