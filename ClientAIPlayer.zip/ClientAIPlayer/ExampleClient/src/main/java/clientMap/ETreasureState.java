package clientMap;

/**
 * enum defines if treasure is on a particular node in the grid
 * [NoOrUnknownTreasureState, MyTreasureIsPresent]
 * 
 * @author Malte
 *
 */
public enum ETreasureState {
	NoOrUnknownTreasureState, MyTreasureIsPresent
}
