package clientMap;

/**
 * enum defines terrain type on a particular node in the grid [Gras, Mountain,
 * Water]
 * 
 * @author Malte
 *
 */
public enum ETerrainType {
	Gras, Mountain, Water
}
