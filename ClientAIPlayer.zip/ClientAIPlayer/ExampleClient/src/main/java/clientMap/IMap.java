package clientMap;

/**
 * has as an underlying foundation an IGrid and represents the idea of a map in
 * a more functional way
 * 
 * @author Malte
 *
 */
public interface IMap {

	/**
	 * creates Map with (1) certain dimension, (2) filled fields according to a
	 * business rule and (3) with a positioned fort
	 * 
	 * @return IMap (not null)
	 */
	public IMap createMap();

	/**
	 * returns a field according to a given Coordinate
	 * 
	 * @param coordinate (not null)
	 * @return MapNode
	 */
	public MapNode readMapEntry(Coordinate coordinate);

	/**
	 * a graphical representation of a map for testing purpose
	 * 
	 * @return String (with MapNode/fields as single characters)
	 */
	public String toString();

	/**
	 * returns the fundamental grid
	 * 
	 * @return I2DGrid (not null)
	 */
	public I2DGrid getGrid();

	/**
	 * returns the start position
	 * 
	 * @return Coordinate (not null)
	 */
	public Coordinate getFort();

	/**
	 * returns a deep copy of an map and use IGrids method deepdopy()
	 */
	public IMap deepCopy();

	public int getXDimension();

	public int getYDimension();
}
