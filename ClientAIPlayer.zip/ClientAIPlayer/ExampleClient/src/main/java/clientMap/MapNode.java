package clientMap;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * defines and models state on a particular node in a grid
 * 
 * @author Malte
 *
 */
public class MapNode {

	private static Logger logger = LoggerFactory.getLogger(MapNode.class);

	private Coordinate coordinate;
	private ETerrainType terrainType;
	private ETreasureState treasureState;
	private EFortState fortState;
	private EPlayerPositionState playerPositionState;

	/**
	 * @param coordinate
	 * @param terrainType
	 * @param treasureState
	 * @param fortState
	 * @param playerPositionState
	 */
	public MapNode(Coordinate coordinate, ETerrainType terrainType, ETreasureState treasureState, EFortState fortState,
			EPlayerPositionState playerPositionState) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
		this.treasureState = treasureState;
		this.fortState = fortState;
		this.playerPositionState = playerPositionState;
		logger.debug("a MapNode was succesfully created with coordinates: {}", this.coordinate);
	}

	/**
	 * only sets terrainType for a specific node (on a specific coordinate)
	 * 
	 * @param coordinate
	 * @param terrainType
	 */
	public MapNode(Coordinate coordinate, ETerrainType terrainType) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
	}

	public MapNode deepCopy() {
		Coordinate coordinateCopy = this.coordinate.deepCopy();
		ETerrainType terrainTypeCopy = this.terrainType;
		ETreasureState treasureStateCopy = this.treasureState;
		EFortState fortStateCopy = this.fortState;
		EPlayerPositionState playerPositionStateCopy = this.playerPositionState;
		logger.debug("a deep copy of an MapNode was succesfully created.");
		return new MapNode(coordinateCopy, terrainTypeCopy, treasureStateCopy, fortStateCopy, playerPositionStateCopy);
	}

	/**
	 * outputs all variables (coordinate, fortState, playerPositionState,
	 * terrainType, treasureState)
	 */
	@Override
	public String toString() {
		return "MapNode [coordinate=" + coordinate + ", terrainType=" + terrainType + ", treasureState=" + treasureState
				+ ", fortState=" + fortState + ", playerPositionState=" + playerPositionState + "]";
	}

	/**
	 * @return the coordinate (Coordinate)
	 */
	public Coordinate getCoordinate() {
		return coordinate;
	}

	/**
	 * @return the terrainType (ETerrainType)
	 */
	public ETerrainType getTerrainType() {
		return terrainType;
	}

	/**
	 * @param terrainType the terrainType to set
	 */
	public void setTerrainType(ETerrainType terrainType) {
		this.terrainType = terrainType;
	}

	/**
	 * @return the treasureState (ETreasureState)
	 */
	public ETreasureState getTreasureState() {
		return treasureState;
	}

	/**
	 * @return the fortState (EFortState)
	 */
	public EFortState getFortState() {
		return fortState;
	}

	/**
	 * @param fortState the fortState to set
	 */
	public void setFortState(EFortState fortState) {
		this.fortState = fortState;
	}

	/**
	 * @return the playerPositionState (EPlayerPositionState)
	 */
	public EPlayerPositionState getPlayerPositionState() {
		return playerPositionState;
	}

	/**
	 * use all variables for hashing
	 */
	@Override
	public int hashCode() {
		return Objects.hash(coordinate, fortState, playerPositionState, terrainType, treasureState);
	}

	/**
	 * a node is equal, if all fields are equal (coordinate, fortState,
	 * playerPositionState, terrainType, treasureState)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MapNode other = (MapNode) obj;
		return Objects.equals(coordinate, other.coordinate) && fortState == other.fortState
				&& playerPositionState == other.playerPositionState && terrainType == other.terrainType
				&& treasureState == other.treasureState;
	}

}
