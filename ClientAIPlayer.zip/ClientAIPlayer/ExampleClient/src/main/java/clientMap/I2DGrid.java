package clientMap;

import java.util.Map;

/**
 * is the underlying foundation of an IMap
 * 
 * @author Malte
 *
 */
public interface I2DGrid {

	/**
	 * generates a random build grid by given dimension and by observance of given
	 * business rules
	 * 
	 * @param x_dimension
	 * @param y_dimension
	 * @return MapGrid (random and not null)
	 */
	public I2DGrid generateGrid(int x_dimension, int y_dimension);

	/**
	 * returns fundamental representation of this grid
	 * 
	 * @return Map<Coordinate, MapNode>
	 */
	public Map<Coordinate, MapNode> getGrid();

	/**
	 * returns requested field by given Coordinate
	 * 
	 * @return MapNode
	 */
	public MapNode getField(Coordinate coordinate);

	/**
	 * sets requested field by given Coordinate with given terrain
	 */
	public void setFieldTerrain(Coordinate coordinate, ETerrainType terrain);

	/**
	 * counts the amount of gras nodes in the actual grid.
	 * 
	 * @return int (amount of gras nodes and -1 if this grid is null)
	 */
	public int countGrasNodes();

	/**
	 * counts the amount of mountain nodes in the actual grid.
	 * 
	 * @return int (amount of mountain nodes and -1 if this grid is null)
	 */
	public int countMountainNodes();

	/**
	 * counts the amount of water nodes in the actual grid.
	 * 
	 * @return int (amount of water nodes and -1 if this grid is null)
	 */
	public int countWaterNodes();

	/**
	 * creates a deep copy of a map by creating everything new and copy each node
	 * 
	 * @return
	 */
	public I2DGrid deepCopy();
}
