package clientMap;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * generally is a MAP-datatype and maps coordinates to a specific MapNode, which
 * provides all details about a specific place in the grid
 * 
 * @author Malte
 *
 */
public class MapGrid implements I2DGrid {

	private static Logger logger = LoggerFactory.getLogger(MapGrid.class);

	private Map<Coordinate, MapNode> grid;
	private MapGenerator gridBuilder;

	private int mountain_fields;
	private int gras_fields;
	private int water_fields;

	/**
	 * Contructor for testing purpose
	 * 
	 * @param grid
	 */
	public MapGrid(Map<Coordinate, MapNode> grid) {
		// [1] generate gridBuilder
		this.gridBuilder = new MapGenerator();
		// [2] generate grid
		this.grid = grid;
		// [3] count field types
		this.gras_fields = this.countGrasNodes();
		this.mountain_fields = this.countMountainNodes();
		this.water_fields = this.countWaterNodes();
		// [4] update field type in gridBuilder
		this.gridBuilder = new MapGenerator(mountain_fields, gras_fields, water_fields);
		logger.debug("a map Grid has been succesfully set up.");
	}

	/**
	 * normal constructor
	 * 
	 * @param nodeList
	 */
	public MapGrid(List<MapNode> nodeList) {
		// [1] generate gridBuilder
		this.gridBuilder = new MapGenerator();
		// [2] generate grid
		this.grid = this.gridBuilder.generateGridFromList(nodeList);
		// [3] count field types
		this.gras_fields = this.countGrasNodes();
		this.mountain_fields = this.countMountainNodes();
		this.water_fields = this.countWaterNodes();
		// [4] update field type in gridBuilder
		this.gridBuilder = new MapGenerator(mountain_fields, gras_fields, water_fields);
		logger.debug("a map Grid has been succesfully set up.");
	}

	/**
	 * @param mountain_fields
	 * @param gras_fields
	 * @param water_fields
	 */
	public MapGrid(int mountain_fields, int gras_fields, int water_fields) {
		this.mountain_fields = mountain_fields;
		this.gras_fields = gras_fields;
		this.water_fields = water_fields;
		this.gridBuilder = new MapGenerator(mountain_fields, gras_fields, water_fields);
	}

	/**
	 * @param grid
	 */
	public MapGrid(Map<Coordinate, MapNode> grid, int mountain_fields, int gras_fields, int water_fields) {
		this.mountain_fields = mountain_fields;
		this.gras_fields = gras_fields;
		this.water_fields = water_fields;
		this.gridBuilder = new MapGenerator(mountain_fields, gras_fields, water_fields);
		this.grid = grid;
	}

	@Override
	public MapGrid generateGrid(int x_dimension, int y_dimension) {
		this.grid = gridBuilder.generateMapGrid(x_dimension, y_dimension);
		logger.debug("a map Grid has been succesfully generated.");
		return this;
	}

	@Override
	public MapNode getField(Coordinate coordinate) {
		logger.debug("a map Grid entry was requested with coordinates:", coordinate);
		return this.grid.get(coordinate);
	}

	/**
	 * @return the gridBuilder
	 */
	public MapGenerator getGridBuilder() {
		return gridBuilder;
	}

	@Override
	public Map<Coordinate, MapNode> getGrid() {
		return grid;
	}

	/**
	 * @param grid the grid to set
	 */
	public void setGrid(Map<Coordinate, MapNode> grid) {
		this.grid = grid;
	}

	/**
	 * @param gridBuilder the gridBuilder to set
	 */
	public void setGridBuilder(MapGenerator gridBuilder) {
		this.gridBuilder = gridBuilder;
	}

	@Override
	public void setFieldTerrain(Coordinate coordinate, ETerrainType terrain) {
		MapNode newNode = this.grid.get(coordinate);
		newNode.setTerrainType(terrain);
		this.grid.put(coordinate, newNode);
		logger.debug("a map Grid entry was succesfully changed with coordinates: {} and ETerrainType: ", coordinate,
				terrain);
	}

	@Override
	public int countGrasNodes() {
		if (this.grid == null)
			return -1;
		Collection<MapNode> values = this.grid.values();
		Stream<MapNode> valuesStream = values.stream();
		return (int) valuesStream.filter(i -> i.getTerrainType() == ETerrainType.Gras).count();
	}

	@Override
	public int countMountainNodes() {
		if (this.grid == null)
			return -1;
		Collection<MapNode> values = this.grid.values();
		Stream<MapNode> valuesStream = values.stream();
		return (int) valuesStream.filter(i -> i.getTerrainType() == ETerrainType.Mountain).count();
	}

	@Override
	public int countWaterNodes() {
		if (this.grid == null)
			return -1;
		Collection<MapNode> values = this.grid.values();
		Stream<MapNode> valuesStream = values.stream();
		return (int) valuesStream.filter(i -> i.getTerrainType() == ETerrainType.Water).count();
	}

	@Override
	public I2DGrid deepCopy() {
		Map<Coordinate, MapNode> newGrid = this.grid;
		int newMountainField = this.mountain_fields;
		int newGrasField = this.gras_fields;
		int newWaterField = this.water_fields;
		MapGrid result = new MapGrid(newGrid, newMountainField, newGrasField, newWaterField);
		result.setGridBuilder(this.gridBuilder);
		logger.debug("a deep copy of an map grid was succesfully created.");
		return result;
	}

}
