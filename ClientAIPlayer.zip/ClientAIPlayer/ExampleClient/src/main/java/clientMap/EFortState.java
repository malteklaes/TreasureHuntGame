package clientMap;

/**
 * enum defines if fort is on a particular node in the grid
 * [NoOrUnknownFortState, MyFortPresent, EnemyFortPresent]
 * 
 * @author Malte
 *
 */
public enum EFortState {
	NoOrUnknownFortState, MyFortPresent, EnemyFortPresent
}
