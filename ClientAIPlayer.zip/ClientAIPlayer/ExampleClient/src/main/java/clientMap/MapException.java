package clientMap;

/**
 * Exception regarding: an error with an IMap has occured
 * 
 * @author Malte
 *
 */
public class MapException extends RuntimeException {

	public MapException(String message) {
		super("regarding IMap: " + message);
	}

}
