package PathfinderAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import clientMap.Coordinate;
import clientMap.ETerrainType;
import clientMap.IMap;
import messagesbase.messagesfromclient.EMove;

public class MyBFS {

	private static Logger logger = LoggerFactory.getLogger(MyBFS.class);

	private IMap map;
	private int minX;
	private int maxX;
	private int minY;
	private int maxY;

	/**
	 * 
	 * @param map
	 * @param minX
	 * @param maxX
	 * @param minY
	 * @param maxY
	 */
	public MyBFS(IMap map, int minX, int maxX, int minY, int maxY) {
		this.map = map;
		this.minX = minX;
		this.maxX = maxX;
		this.minY = minY;
		this.maxY = maxY;
	}

	/**
	 * activates the BFS
	 * 
	 * @param start
	 * @param target
	 * @return
	 * @throws MovementException
	 */
	public List<Coordinate> findShortestPath(Coordinate start, Coordinate target) throws MovementException {
		logger.debug("start to find shortest path between {} and {}", start, target);
		// [1] initialize queue and visited set
		Queue<Coordinate> queueCoord = new LinkedList<>();
		Set<Coordinate> visitedCoord = new HashSet<>();
		queueCoord.add(start);

		// [2] initialize a map to store the parent of each visited coordinate
		Map<Coordinate, Coordinate> parent = new HashMap<>();
		parent.put(start, null);

		// [3] start actually BFS
		while (!queueCoord.isEmpty()) {
			Coordinate currCoord = queueCoord.poll();
			visitedCoord.add(currCoord);

			// Check if the current node is the target
			if (currCoord.equals(target)) {
				logger.debug("a path has succesfully found");
				return buildPath(parent, currCoord);
			}

			// add all the unvisited neighbors to the queue: try first to add non mountain
			// fields to travel faster, if there is no such way, than take the steep way
			for (EMove move : EMove.values()) {
				Coordinate neighbor = getNeighbor(currCoord, move);
				if (isValidCoordinateOptimalWay(neighbor)) {
					if (isValidCoordinateOptimalWay(neighbor) && !visitedCoord.contains(neighbor)) {
						queueCoord.add(neighbor);
						visitedCoord.add(neighbor);
						parent.put(neighbor, currCoord);
					}
				} else {
					if (isValidCoordinate(neighbor) && !visitedCoord.contains(neighbor)) {
						queueCoord.add(neighbor);
						visitedCoord.add(neighbor);
						parent.put(neighbor, currCoord);
					}
				}

			}
		}

		logger.warn("target could not been found");
		return null;
	}

	/**
	 * builds up final path as a result of BFS by going backwards and adding
	 * everytime the neighbor of ones coordinate to the final path
	 * 
	 * @param parent
	 * @param target
	 * @return
	 */
	private List<Coordinate> buildPath(Map<Coordinate, Coordinate> parent, Coordinate target) {
		List<Coordinate> path = new ArrayList<>();
		path.add(target);

		Coordinate currCoord = target;
		while (parent.get(currCoord) != null) {
			currCoord = parent.get(currCoord);
			path.add(currCoord);
		}

		// finally reverse path which was created from backwards
		Collections.reverse(path);
		logger.debug("a path to the target has succesfully be backtraced.");
		return path;
	}

	/**
	 * calculates coordinate which is reached by incoming move
	 * 
	 * @param coord
	 * @param move
	 * @return
	 * @throws MovementException
	 */
	private Coordinate getNeighbor(Coordinate coord, EMove move) throws MovementException {
		int x = coord.getX_coord();
		int y = coord.getY_coord();

		switch (move) {
		case Up:
			return new Coordinate(x - 1, y);
		case Down:
			return new Coordinate(x + 1, y);
		case Left:
			return new Coordinate(x, y - 1);
		case Right:
			return new Coordinate(x, y + 1);
		default:
			logger.error("there has been an error occured and no move could be found while backtracing.");
			throw new MovementException(
					"there has been an error occured and no move could be found while backtracing.");
		}
	}

	/**
	 * checks incoming coordinate in terms of if its in zone limits and if it is not
	 * a water-field
	 * 
	 * @param coord
	 * @return
	 */
	private boolean isValidCoordinate(Coordinate coord) {
		logger.debug("checks wether coordinate {} is a valid coordinate.", coord);
		int x = coord.getX_coord();
		int y = coord.getY_coord();
		return x >= minX && x <= maxX && y >= minY && y <= maxY && map.getGrid().getField(coord) != null
				&& map.getGrid().getField(coord).getTerrainType() != ETerrainType.Water;
	}

	/**
	 * checks incoming coordinate in terms of if its in zone limits and if it is not
	 * a water-field and not a mountain-field, so could deliver an more optimate
	 * path
	 * 
	 * @param coord
	 * @return
	 */
	private boolean isValidCoordinateOptimalWay(Coordinate coord) {
		logger.debug("checks wether coordinate {} is a optimal and valid coordinate.", coord);
		int x = coord.getX_coord();
		int y = coord.getY_coord();
		return x >= minX && x <= maxX && y >= minY && y <= maxY && map.getGrid().getField(coord) != null
				&& map.getGrid().getField(coord).getTerrainType() != ETerrainType.Water
				&& map.getGrid().getField(coord).getTerrainType() != ETerrainType.Mountain;
	}

	/**
	 * string-representation for testing and debugging purpose
	 */
	public String toString() {
		return "MyBFS [map=" + map + ", minX=" + minX + ", maxX=" + maxX + ", minY=" + minY + ", maxY=" + maxY + "]";
	}

}
