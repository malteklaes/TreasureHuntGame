package PathfinderAlgorithm;

/**
 * Exception regarding: there was an error with finding the right movement
 * 
 * @author Malte
 *
 */
public class MovementException extends Exception {
	public MovementException(String message) {
		super("regarding choosing a right movement: " + message);
	}
}
