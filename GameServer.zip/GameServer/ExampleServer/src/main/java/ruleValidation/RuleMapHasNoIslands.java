package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.ETerrainType;
import map.IServerMap;
import server.exceptions.RuleMapHasNoIslandsException;

/**
 * checks whether a given half map has no islands and so no fields, which can
 * not be entered
 * 
 * @author Malte
 *
 */
public class RuleMapHasNoIslands implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapHasNoIslands.class);

	private final int xDimension = 10;
	private final int yDimension = 5;

	@Override
	public void checkRuleMapHasNoIslands(IServerMap incomingHalfGameMap) {
		IServerMap halfGameMap = incomingHalfGameMap.clone();
		if (halfGameMap != null) {
			if (!this.checkForIsland(halfGameMap)) {
				logger.error(DevMessage.mError("Half map has islands and so fields, which can not be entered!"));
				throw new RuleMapHasNoIslandsException("RuleMapHasNoIslandsViolation",
						"Half map has islands and so fields, which can not be entered!");
			}
		}
	};

	/**
	 * checks, if given halfMap (HalfMap with 50 fields total) contains any fields,
	 * which can not be reached
	 * 
	 * @param halfGameMap (not null)
	 * @return boolean (false, if islands were found)
	 */
	public boolean checkForIsland(IServerMap halfGameMap) {
		if (halfGameMap == null)
			return false;
		else {
			// [1] initial coordinate is a no water field
			Coordinate initCoord = this.findStartPoint(xDimension, yDimension, halfGameMap);

			// [2] start flood fill algorithm
			this.floodFillAlgorithm(halfGameMap, initCoord, xDimension, yDimension);
			return halfGameMap.countWaterNodes() == 50;
		}
	}

	/**
	 * finds the start point for flood fill algorithm, which should not be a water
	 * field.
	 * 
	 * @param xDimension  (not null)
	 * @param yDimension  (not null)
	 * @param halfGameMap (not null)
	 * @return Coordinate (which is only technical null, but since Pre-Condition
	 *         should not be null)
	 */
	private Coordinate findStartPoint(int xDimension, int yDimension, IServerMap halfGameMap) {
		for (int x = 0; x < xDimension; x++) {
			for (int y = 0; y < yDimension; y++) {
				Coordinate initialCoord = new Coordinate(x, y);
				if (halfGameMap.getMapNode(initialCoord).getTerrainType() != ETerrainType.Water)
					return initialCoord;
			}
		}
		return null;
	}

	/**
	 * checks if the reachable fields were water fields and if not, paints over them
	 * as water fields. The Result should be a halfMap which consist purely of water
	 * fields (== is flooded all over).
	 * 
	 * @param halfGameMap (not null)
	 * @param initCoord   (not null)
	 * @param xDimension  (not null)
	 * @param yDimension  (not null)
	 */
	private void floodFillAlgorithm(IServerMap halfGameMap, Coordinate initCoord, int xDimension, int yDimension) {
		int xValue = initCoord.getXCoord();
		int yValue = initCoord.getYCoord();
		// [1] Check if Coordinate is out of bounds or this field is already water
		if (xValue < 0 || xDimension <= xValue || yValue < 0 || yDimension <= yValue
				|| halfGameMap.getMapNode(initCoord).getTerrainType() == ETerrainType.Water) {
		} else {
			// [2] paint field as water
			halfGameMap.setFieldTerrain(initCoord, ETerrainType.Water);
			// [3] go on in all four directions recursively
			this.floodFillAlgorithm(halfGameMap, new Coordinate(xValue + 1, yValue), xDimension, yDimension);
			this.floodFillAlgorithm(halfGameMap, new Coordinate(xValue - 1, yValue), xDimension, yDimension);
			this.floodFillAlgorithm(halfGameMap, new Coordinate(xValue, yValue + 1), xDimension, yDimension);
			this.floodFillAlgorithm(halfGameMap, new Coordinate(xValue, yValue - 1), xDimension, yDimension);
		}
	}

}