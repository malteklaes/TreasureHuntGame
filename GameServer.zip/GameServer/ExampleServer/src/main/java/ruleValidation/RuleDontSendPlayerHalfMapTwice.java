package ruleValidation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import game.PlayerID;
import server.exceptions.RuleDontSendPlayerHalfMapTwiceExeption;

/**
 * checks whether a player tries to send the same map twice
 * 
 * @author Malte
 *
 */
public class RuleDontSendPlayerHalfMapTwice implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleDontSendPlayerHalfMapTwice.class);

	@Override
	public void checkRuleDontSendPlayerHalfMapTwice(PlayerID playerID, List<PlayerID> playerHalfMapsRegistrations) {
		if (this.listContainsDuplicatePlayerID(playerHalfMapsRegistrations, playerID)) {
			logger.error(DevMessage.mError("playerID " + playerID + " has tried to add half map twice."));
			throw new RuleDontSendPlayerHalfMapTwiceExeption("HalfMapAlreadyRecieved",
					"playerID " + playerID + " has tried to add half map twice.");
		}
	};

	/**
	 * checks whether player is duplicated in given playerslist
	 * 
	 * @param players  (not null)
	 * @param playerID (not null)
	 * @return true (if duplicate)
	 */
	private boolean listContainsDuplicatePlayerID(List<PlayerID> players, PlayerID playerID) {
		int duplicate = 0;
		for (PlayerID player : players) {
			for (int i = 0; i < players.size(); i++) {
				if (players.get(i).equals(player)) {
					duplicate++;
				}
			}
			if (duplicate > 1 && player.equals(playerID)) {
				return true;
			}
			duplicate = 0;
		}
		return false;
	}

}
