package ruleValidation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import game.GameID;
import game.GameInfo;
import game.PlayerID;
import server.exceptions.RulePlayerIsExistingException;

/**
 * checks whether a player is existing in actualGames
 * 
 * @author Malte
 *
 */
public class RulePlayerIsExisting implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RulePlayerIsExisting.class);

	@Override
	public void checkRulePlayerIsExisting(PlayerID playerID, Map<GameID, GameInfo> actualGames) {
		boolean containsPlayer = false;
		if (actualGames != null && actualGames.size() > 0) {
			for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
				if (game.getValue().containsPlayer(playerID)) {
					containsPlayer = true;
				}
			}
		}
		if (!containsPlayer) {
			logger.error(DevMessage.mError("playerID could not be found in the actual games."));
			throw new RulePlayerIsExistingException("NoPlayerIDInGames",
					"playerID could not be found in the actual games.");
		}
	};

}
