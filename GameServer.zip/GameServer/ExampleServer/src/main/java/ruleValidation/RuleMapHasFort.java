package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.EGameFortState;
import map.IServerMap;
import server.exceptions.RuleMapHasFortException;

/**
 * checks whether a half game map has exactly on fort
 * 
 * @author Malte
 *
 */
public class RuleMapHasFort implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapHasFort.class);

	@Override
	public void checkRuleMapHasFort(IServerMap halfGameMap) {
		int fortCounter = 0;
		for (int y = 0; y < 5; y++) {
			for (int x = 0; x < 10; x++) {
				Coordinate actualCoord = new Coordinate(x, y);
				if (halfGameMap.getMapNode(actualCoord) != null
						&& halfGameMap.getMapNode(actualCoord).getFortState() == EGameFortState.FortPresent) {
					fortCounter++;
				}
			}
		}
		if (fortCounter != 1) {
			logger.error(DevMessage.mError(
					"Half map has not exactly one fort present on its half map! Forts counted: " + fortCounter));
			throw new RuleMapHasFortException("RuleMapHasFortViolation",
					"Half map has not exactly one fort present on its half map! Forts counted: " + fortCounter);
		}
	}

}
