package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.ETerrainType;
import map.IServerMap;
import server.exceptions.RuleMapNotRightTerrainAmountException;

/**
 * checks whether the right amount of fields are on a given half map (at least:
 * 5 mountainfields, 7 grasfields, 7 waterfields)
 * 
 * @author Malte
 *
 */
public class RuleMapRightTerrainAmount implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapRightTerrainAmount.class);

	@Override
	public void checkRuleMapRightTerrainAmount(IServerMap halfGameMap) {
		int grasfieldCounter = 0;
		int mountainfieldCounter = 0;
		int waterfieldCounter = 0;
		for (int y = 0; y < 5; y++) {
			for (int x = 0; x < 10; x++) {
				Coordinate actualCoord = new Coordinate(x, y);
				if (halfGameMap.getMapNode(actualCoord) != null
						&& halfGameMap.getMapNode(actualCoord).getTerrainType() == ETerrainType.Gras)
					grasfieldCounter++;
				if (halfGameMap.getMapNode(actualCoord) != null
						&& halfGameMap.getMapNode(actualCoord).getTerrainType() == ETerrainType.Mountain)
					mountainfieldCounter++;
				if (halfGameMap.getMapNode(actualCoord) != null
						&& halfGameMap.getMapNode(actualCoord).getTerrainType() == ETerrainType.Water)
					waterfieldCounter++;
			}
		}

		if (grasfieldCounter < 7) {
			logger.error(DevMessage
					.mError("Half map has not the right amount of gras fields, has this: " + grasfieldCounter));
			throw new RuleMapNotRightTerrainAmountException("RuleMapRightTerrainAmountViolation",
					"Half map has not the right amount of gras fields, has this: " + grasfieldCounter);
		}
		if (mountainfieldCounter < 5) {
			logger.error(DevMessage
					.mError("Half map has not the right amount of mountain fields, has this: " + mountainfieldCounter));
			throw new RuleMapNotRightTerrainAmountException("RuleMapRightTerrainAmountViolation",
					"Half map has not the right amount of mountain fields, has this: " + mountainfieldCounter);
		}
		if (waterfieldCounter < 7) {
			logger.error(DevMessage
					.mError("Half map has not the right amount of water fields, has this: " + waterfieldCounter));
			throw new RuleMapNotRightTerrainAmountException("RuleMapRightTerrainAmountViolation",
					"Half map has not the right amount of water fields, has this: " + waterfieldCounter);
		}
	};

}
