package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.IServerMap;
import server.exceptions.RuleMapHasCorrectDimensionAndCoordinatesException;

/**
 * checks whether a half game map has the right coordinates (x (0-9) and y
 * (0-4)) and thus has the right dimension
 * 
 * @author Malte
 *
 */
public class RuleMapHasCorrectDimensionAndCoordinates implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapHasCorrectDimensionAndCoordinates.class);

	@Override
	public void checkRuleMapHasCorrectDimensionAndCoordinates(IServerMap halfGameMap) {
		for (int y = 0; y < 5; y++) {
			for (int x = 0; x < 10; x++) {
				Coordinate actualCoord = new Coordinate(x, y);
				if (halfGameMap.getMapNode(actualCoord) == null) {
					logger.error(DevMessage.mError(
							"Half map has not the right coordinates and thus has not the right dimension with actual coordinate: "
									+ actualCoord));
					throw new RuleMapHasCorrectDimensionAndCoordinatesException("RuleHasCorrectDimensionViolation",
							"Half map has not the right coordinates and thus has not the right dimension with actual coordinate: "
									+ actualCoord);
				}
			}
		}
	}

}
