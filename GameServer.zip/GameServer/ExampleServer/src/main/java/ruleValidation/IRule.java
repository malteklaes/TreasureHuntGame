package ruleValidation;

import java.util.List;
import java.util.Map;

import game.GameID;
import game.GameInfo;
import game.PlayerID;
import map.IServerMap;

public interface IRule {

	/**
	 * checks whether a given gameID is already in the actual volume of games
	 * 
	 * @param gameID
	 */
	public default void checkRuleGameIsExisting(GameID gameID, Map<GameID, GameInfo> actualGames) {
	};

	/**
	 * checks whether a given gameID is already in the actual volume of games
	 * 
	 * @param gameID
	 */
	public default void checkRulePlayerIsExisting(PlayerID playerID, Map<GameID, GameInfo> actualGames) {
	};

	public default void checkRuleDontSendPlayerHalfMapTwice(PlayerID playerID,
			List<PlayerID> playerHalfMapsRegistrations) {
	};

	/**
	 * checks whether it is really the players turn (MustAct) instead of (MustWait)
	 * 
	 * @param player (not null)
	 */
	public default void checkRuleIfItIsPlayersTurn(PlayerID player, Map<GameID, GameInfo> actualGames) {
	};

	/**
	 * checks whether a half game map has the right coordinates (x (0-9) and y
	 * (0-4)) and thus has the right dimension
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapHasCorrectDimensionAndCoordinates(IServerMap halfGameMap) {
	};

	/**
	 * checks whether a given half map has exactly on fort
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapHasFort(IServerMap halfGameMap) {
	};

	/**
	 * checks whether a given half map has placed its fort on a gras field
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapFortSetOnGras(IServerMap halfGameMap) {
	};

	/**
	 * checks whether the right amount of fields are on a given half map (at least:
	 * 5 mountainfields, 7 grasfields, 7 waterfields)
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapRightTerrainAmount(IServerMap halfGameMap) {
	};

	/**
	 * checks whether a given half map has the right amount of map nodes
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapRightSizeOfHalfMap(IServerMap halfGameMap) {
	};

	/**
	 * checks whether a given half map has the right amount of water fields on its
	 * edges
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapNotToMuchWaterfieldOnEdges(IServerMap halfGameMap) {
	};

	/**
	 * checks whether a given half map has no islands and so no fields, which can
	 * not be entered
	 * 
	 * @param halfGameMap (not null)
	 */
	public default void checkRuleMapHasNoIslands(IServerMap halfGameMap) {
	};

}
