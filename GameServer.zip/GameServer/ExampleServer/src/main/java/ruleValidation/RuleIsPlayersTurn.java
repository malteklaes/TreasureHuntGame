package ruleValidation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import game.EPlayerActualGameState;
import game.GameID;
import game.GameInfo;
import game.PlayerID;
import server.exceptions.RuleIsPlayersTurnException;

/**
 * checks whether it is really the players turn to act
 * 
 * @author Malte
 *
 */
public class RuleIsPlayersTurn implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleIsPlayersTurn.class);

	@Override
	public void checkRuleIfItIsPlayersTurn(PlayerID player, Map<GameID, GameInfo> actualGames) {
		EPlayerActualGameState playerState;
		for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
			if (game.getValue().containsPlayer(player) && game.getValue().getPlayerByPlayerID(player) != null) {
				playerState = game.getValue().getPlayerByPlayerID(player).getPlayerGameState();
				if (playerState == EPlayerActualGameState.MustWait) {
					logger.error(DevMessage
							.mError("player with id: " + player + " trys to act with illegal state: " + playerState));
					throw new RuleIsPlayersTurnException("RuleIsPlayersTurnViolation",
							"player with id: " + player + " trys to act with illegal state: " + playerState);
				}
			}
		}

	}

}
