package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.IServerMap;
import server.exceptions.RuleMapNotRightSizeOfHalfMapException;

/**
 * checks whether a given half map has the right amount of map nodes
 * 
 * @author Malte
 *
 */
public class RuleMapRightSizeOfHalfMap implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapRightSizeOfHalfMap.class);

	private final int rightAmountOfTotalHalfMapNodes = 50;

	@Override
	public void checkRuleMapRightSizeOfHalfMap(IServerMap halfGameMap) {
		if (halfGameMap.getMapNodes().size() != rightAmountOfTotalHalfMapNodes) {
			logger.error(DevMessage.mError("Half map has not the right amount of total map nodes, but this amount: "
					+ halfGameMap.getMapNodes().size()));
			throw new RuleMapNotRightSizeOfHalfMapException("RuleMapRightSizeOfHalfMapViolation",
					"Half map has not the right amount of total map nodes, but this amount: "
							+ halfGameMap.getMapNodes().size());
		}
	};

}
