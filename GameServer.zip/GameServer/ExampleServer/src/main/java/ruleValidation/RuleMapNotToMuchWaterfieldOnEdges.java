package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.ETerrainType;
import map.IServerMap;
import server.exceptions.RuleMapNotToMuchWaterfieldOnEdgesException;

/**
 * checks whether a given half map has the right amount of water fields on its
 * edges
 * 
 * @author Malte
 *
 */
public class RuleMapNotToMuchWaterfieldOnEdges implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapNotToMuchWaterfieldOnEdges.class);

	private final int xDimension = 10;
	private final int yDimension = 5;

	@Override
	public void checkRuleMapNotToMuchWaterfieldOnEdges(IServerMap halfGameMap) {
		if (!this.checkForWaterOnEdge(halfGameMap)) {
			logger.error(DevMessage.mError("Half map has not the right amount of water fields on its edges!"));
			throw new RuleMapNotToMuchWaterfieldOnEdgesException("RuleMapNotToMuchWaterfieldOnEdgesViolation",
					"Half map has not the right amount of water fields on its edges!");
		}
	};

	/**
	 * checks, if there are more than 4 water fields on long x-side (4/10) or more
	 * than 2 water fields on short y-side (2/5)
	 * 
	 * @param halfGameMap (will be checked)
	 * @return boolean (true, if everything is fine)
	 */
	private boolean checkForWaterOnEdge(IServerMap halfGameMap) {
		if (halfGameMap == null) {
			logger.warn("the grid which should be validated is null.");
			return false;
		} else {
			int counterLeftSide = 0;
			int counterRightSide = 0;
			int CounterUpSide = 0;
			int CounterBottomSide = 0;

			Coordinate drawCoordinate = new Coordinate(0, 0);
			for (int y = 0; y < yDimension; y++) {
				for (int x = 0; x < xDimension; x++) {
					drawCoordinate.setXCoord(x);
					drawCoordinate.setYCoord(y);
					// ETerrainType terrainType =
					// this.gridToBeValidated.getField(drawCoordinate).getTerrainType();
					ETerrainType terrainType = halfGameMap.getMapNode(drawCoordinate).getTerrainType();
					// [1] checks left side
					if (drawCoordinate.getXCoord() == 0 && terrainType == ETerrainType.Water) {
						counterLeftSide++;
					}
					// [2] checks right side
					if (drawCoordinate.getXCoord() == 9 && terrainType == ETerrainType.Water) {
						counterRightSide++;
					}
					// [3] checks up side
					if (drawCoordinate.getYCoord() == 0 && terrainType == ETerrainType.Water) {
						CounterUpSide++;
					}
					// [4] checks bottom side
					if (drawCoordinate.getYCoord() == 4 && terrainType == ETerrainType.Water) {
						CounterBottomSide++;
					}
				}
			}

			return (counterLeftSide <= 2 && counterRightSide <= 2 && CounterUpSide <= 4 && CounterBottomSide <= 4);
		}
	}

}