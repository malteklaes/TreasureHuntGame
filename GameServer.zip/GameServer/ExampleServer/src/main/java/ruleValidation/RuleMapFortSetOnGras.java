package ruleValidation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.Coordinate;
import map.EGameFortState;
import map.ETerrainType;
import map.IServerMap;
import server.exceptions.RuleMapFortNotSetOnGrasException;

/**
 * checks whether a given half map has placed its fort on a gras field
 * 
 * @author Malte
 *
 */
public class RuleMapFortSetOnGras implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleMapFortSetOnGras.class);

	@Override
	public void checkRuleMapFortSetOnGras(IServerMap halfGameMap) {
		for (int y = 0; y < 5; y++) {
			for (int x = 0; x < 10; x++) {
				Coordinate actualCoord = new Coordinate(x, y);
				if (halfGameMap.getMapNode(actualCoord) != null
						&& halfGameMap.getMapNode(actualCoord).getFortState() == EGameFortState.FortPresent) {
					if (halfGameMap.getMapNode(actualCoord).getTerrainType() != ETerrainType.Gras) {
						logger.error(
								DevMessage.mError("Half map has not set its fort on a gras field but on this field: "
										+ halfGameMap.getMapNode(actualCoord).getTerrainType()));
						throw new RuleMapFortNotSetOnGrasException("RuleMapFortSetOnGrasViolation",
								"Half map has not set its fort on a gras field but on this field: "
										+ halfGameMap.getMapNode(actualCoord).getTerrainType());
					}
				}
			}
		}
	};

}