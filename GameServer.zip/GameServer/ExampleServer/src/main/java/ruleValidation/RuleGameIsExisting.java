package ruleValidation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import game.GameID;
import game.GameInfo;
import server.exceptions.RuleGameIsExistingException;

/**
 * checks whether a game is existing in actualGames
 * 
 * @author Malte
 *
 */
public class RuleGameIsExisting implements IRule {

	private static Logger logger = LoggerFactory.getLogger(RuleGameIsExisting.class);

	@Override
	public void checkRuleGameIsExisting(GameID gameID, Map<GameID, GameInfo> actualGames) {
		if (!actualGames.containsKey(gameID)) {
			logger.error(DevMessage.mError("gameID could not be found in the actual games."));
			throw new RuleGameIsExistingException("GameIDInGames", "gameID could not be found in the actual games.");
		}

	};

}
