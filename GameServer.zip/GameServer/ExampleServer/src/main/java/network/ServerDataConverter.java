package network;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import game.GameID;
import game.PlayerID;
import game.PlayerInfo;
import messagesbase.UniqueGameIdentifier;
import messagesbase.UniquePlayerIdentifier;
import messagesbase.messagesfromclient.PlayerRegistration;

/**
 * converts all network classes to own data classes regarding data types
 * 
 * @author Malte
 *
 */
public class ServerDataConverter {

	private static Logger logger = LoggerFactory.getLogger(ServerDataConverter.class);

	/**
	 * converts a given GameID to UniqueGameIdentifier
	 * 
	 * @param gameID (not null)
	 * @return UniqueGameIdentifier (from messagesbase and not null)
	 */
	public static UniqueGameIdentifier convertGameIDToUniqueGameIdentifier(GameID gameID) {
		return new UniqueGameIdentifier(gameID.getGameID());
	}

	/**
	 * converts a given UniqueGameIdentifier to GameID
	 * 
	 * @param uniqueGameIdentifier (not null)
	 * @return GameID (not null)
	 */
	public static GameID convertUniqueGameIdentifierToGameID(UniqueGameIdentifier uniqueGameIdentifier) {
		return new GameID(uniqueGameIdentifier.getUniqueGameID());
	}

	/**
	 * converts a given PlayerRegistration to PlayerInfo
	 * 
	 * @param playerRegistration (not null)
	 * @param playerID           (not null)
	 * @return PlayerInfo (not null)
	 */
	public static PlayerInfo convertPlayerRegistrationToPlayerInfo(PlayerRegistration playerRegistration,
			PlayerID playerID) {
		return new PlayerInfo(playerRegistration.getStudentFirstName(), playerRegistration.getStudentLastName(),
				playerRegistration.getStudentUAccount(), playerID);
	}

	/**
	 * converts a given UniquePlayerIdentifier to PlayerID
	 * 
	 * @param uniquePlayerIdentifier (not null)
	 * @return PlayerID (not null)
	 */
	public static PlayerID convertUniquePlayerIdentifierToPlayerID(UniquePlayerIdentifier uniquePlayerIdentifier) {
		return new PlayerID(uniquePlayerIdentifier.getUniquePlayerID());
	}

	/**
	 * converts a given PlayerID to UniquePlayerIdentifier
	 * 
	 * @param playerID (not null)
	 * @return UniquePlayerIdentifier (not null)
	 */
	public static UniquePlayerIdentifier convertUniquePlayerIDToPlayerIdentifier(PlayerID playerID) {
		return new UniquePlayerIdentifier(playerID.getPlayerID());
	}

	/**
	 * creates a new reandom gameStateUUID
	 * 
	 * @return String (not null)
	 */
	public static String createNewRandomGameStateUUID() {
		return UUID.randomUUID().toString();
	}

}
