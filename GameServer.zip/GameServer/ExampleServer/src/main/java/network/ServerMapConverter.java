package network;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.ConversionException;

import devTools.DevMessage;
import game.BundleAnswerGameState;
import game.BundleAnswerRegisterPlayerHalfMap;
import game.EPlayerActualGameState;
import game.PlayerID;
import game.PlayerInfo;
import game.PlayerPair;
import map.Coordinate;
import map.EGameFortState;
import map.ETerrainType;
import map.GameMap;
import map.IServerMap;
import map.MapNode;
import messagesbase.UniquePlayerIdentifier;
import messagesbase.messagesfromclient.ETerrain;
import messagesbase.messagesfromclient.PlayerHalfMap;
import messagesbase.messagesfromclient.PlayerHalfMapNode;
import messagesbase.messagesfromserver.EFortState;
import messagesbase.messagesfromserver.EPlayerGameState;
import messagesbase.messagesfromserver.EPlayerPositionState;
import messagesbase.messagesfromserver.ETreasureState;
import messagesbase.messagesfromserver.FullMap;
import messagesbase.messagesfromserver.FullMapNode;
import messagesbase.messagesfromserver.GameState;
import messagesbase.messagesfromserver.PlayerState;

/**
 * converts all network classes to own map-data classes regarding mainly to map
 * related data types
 * 
 * @author Malte
 *
 */
public class ServerMapConverter {

	private static Logger logger = LoggerFactory.getLogger(ServerMapConverter.class);

	/**
	 * extract the playerID from a PlayerHalfMap and returns a PlayerID
	 * 
	 * @param playerHalfMap (not null)
	 * @return PlayerID (not null)
	 */
	public static PlayerID retrievePlayerIDFromPlayerHalfMap(PlayerHalfMap playerHalfMap) {
		logger.debug(DevMessage.mDebug("retrieved playerHalfMap"));
		return new PlayerID(playerHalfMap.getUniquePlayerID());
	}

	/**
	 * converts a given PlayerHalfMap to IServerMap
	 * 
	 * @param playerHalfMap
	 * @return IServerMap (not null)
	 */
	public static IServerMap convertNewPlayerHalfMapToIServerMap(PlayerHalfMap playerHalfMap, PlayerID playerID) {
		IServerMap gameMap = new GameMap();
		for (var mapNode : playerHalfMap.getMapNodes()) {
			MapNode newMapNode = convertNewPlayerHalfMapNodeToMapNode(mapNode, playerID);
			gameMap.addMapNode(newMapNode);
			if (newMapNode.getFortState() == EGameFortState.FortPresent) {
				gameMap.addPlayerFort(newMapNode.getCoordinate(), playerID);
			}
		}
		return gameMap;
	}

	/**
	 * creates a new random gamestate-UUID
	 * 
	 * @return String (not null)
	 */
	public static String createNewRandomGameStateUUID() {
		return UUID.randomUUID().toString();
	}

	/**
	 * converts a BundleAnswerRegisterPlayerHalfMap to GameState
	 * 
	 * @param bundleAnswerRegisterPlayerHalfMap (not null)
	 * @return GameState (not null)
	 */
	public static GameState convertBundleAnswerRegisterPlayerHalfMapToGameState(
			BundleAnswerRegisterPlayerHalfMap bundleAnswerRegisterPlayerHalfMap) {
		List<PlayerState> players = new ArrayList<>();
		PlayerState playerState = convertPlayerInfoToPlayerState(bundleAnswerRegisterPlayerHalfMap.getPlayerInfo());
		players.add(playerState);
		return new GameState(players, bundleAnswerRegisterPlayerHalfMap.getActualGameStateUUID());
	}

	/**
	 * converts a BundleAnswerGameState to GameState (filling with all information:
	 * map, players and gameStateID)
	 * 
	 * @param gameStateAnswer (not null)
	 * @return GameState (not null)
	 */
	public static GameState convertBundleAnswerGameStateToGameState(BundleAnswerGameState gameStateAnswer) {
		FullMap map = (gameStateAnswer.getFullGameMap() != null
				&& gameStateAnswer.getFullGameMap().getMapNodes().size() > 0)
						? convertIServerMapToFullMap(gameStateAnswer.getFullGameMap(), gameStateAnswer.getPlayerID(),
								gameStateAnswer.getRoundNumberHidePosition())
						: new FullMap();
		List<PlayerState> players = (gameStateAnswer.getPlayerPair() != null
				&& gameStateAnswer.getPlayerPair().toList().size() > 0)
						? convertPlayerPairToListOfPlayerState(gameStateAnswer.getPlayerPair(),
								gameStateAnswer.getPlayerID())
						: new ArrayList<>();
		String gameStateID = gameStateAnswer.getGameStateUUID();
		return new GameState(map, players, gameStateID);
	}

	/**
	 * converts own IServerMap to FullMap (hides position depending on round
	 * information)
	 * 
	 * @param fullGameMap             (not null)
	 * @param playerID                (not null)
	 * @param roundNumberHidePosition (not null)
	 * @return FullMap (not null)
	 */
	public static FullMap convertIServerMapToFullMap(IServerMap fullGameMap, PlayerID playerID,
			int roundNumberHidePosition) {
		Set<FullMapNode> mapNodes = new HashSet<>();
		Coordinate hidePlayersEnemyPosition = fullGameMap.hidePlayersPosition(playerID);
		for (var mapNode : fullGameMap.getMapNodes()) {
			FullMapNode convertedNode = convertMapNodeToFullMapNode(fullGameMap, mapNode, playerID);
			if (convertedNode
					.getPlayerPositionState() == messagesbase.messagesfromserver.EPlayerPositionState.EnemyPlayerPosition
					&& roundNumberHidePosition > 0) {
				convertedNode = new FullMapNode(convertedNode.getTerrain(),
						messagesbase.messagesfromserver.EPlayerPositionState.NoPlayerPresent,
						convertedNode.getTreasureState(), convertedNode.getFortState(), convertedNode.getX(),
						convertedNode.getY());
			}
			if (convertedNode.getFortState() == messagesbase.messagesfromserver.EFortState.EnemyFortPresent
					&& roundNumberHidePosition > 0) {
				convertedNode = new FullMapNode(convertedNode.getTerrain(), convertedNode.getPlayerPositionState(),
						convertedNode.getTreasureState(),
						messagesbase.messagesfromserver.EFortState.NoOrUnknownFortState, convertedNode.getX(),
						convertedNode.getY());
			}
			if (convertedNode.getTreasureState() == ETreasureState.MyTreasureIsPresent && roundNumberHidePosition > 0) {
				convertedNode = new FullMapNode(convertedNode.getTerrain(), convertedNode.getPlayerPositionState(),
						messagesbase.messagesfromserver.ETreasureState.NoOrUnknownTreasureState,
						convertedNode.getFortState(), convertedNode.getX(), convertedNode.getY());
			}
			if (mapNode.getCoordinate().equals(hidePlayersEnemyPosition) && roundNumberHidePosition > 0) {
				convertedNode = new FullMapNode(convertedNode.getTerrain(),
						messagesbase.messagesfromserver.EPlayerPositionState.EnemyPlayerPosition,
						convertedNode.getTreasureState(), convertedNode.getFortState(), convertedNode.getX(),
						convertedNode.getY());
			}
			mapNodes.add(convertedNode);
		}
		return new FullMap(mapNodes);
	}

	/**
	 * converts MapNode to FullMapNode
	 * 
	 * @param fullGameMap (not null)
	 * @param mapNode     (not null)
	 * @param playerID    (not null)
	 * @return FullMapNode (not null)
	 */
	public static FullMapNode convertMapNodeToFullMapNode(IServerMap fullGameMap, MapNode mapNode, PlayerID playerID) {
		ETerrain terrain = convertETerrainToETerrainType(mapNode.getTerrainType());
		messagesbase.messagesfromserver.EPlayerPositionState playerPos = retrievesPlayer(mapNode, playerID);
		messagesbase.messagesfromserver.ETreasureState treasure = retrievesTreasureState(fullGameMap, mapNode,
				playerID);
		messagesbase.messagesfromserver.EFortState fort = retrievesFortState(fullGameMap, mapNode, playerID);
		int X = mapNode.getCoordinate().getXCoord();
		int Y = mapNode.getCoordinate().getYCoord();
		return new FullMapNode(terrain, playerPos, treasure, fort, X, Y);
	}

	/**
	 * converts NewPlayerHalfMapNode to MapNode
	 * 
	 * @param playerHalfMapNode (not null)
	 * @param playerID          (not null)
	 * @return MapNode (not null)
	 * @throws ConversionException
	 */
	public static MapNode convertNewPlayerHalfMapNodeToMapNode(PlayerHalfMapNode playerHalfMapNode, PlayerID playerID)
			throws ConversionException {
		Coordinate coordinate = new Coordinate(playerHalfMapNode.getX(), playerHalfMapNode.getY());
		ETerrainType terrainType = convertETerrainToETerrainType(playerHalfMapNode.getTerrain());
		EGameFortState fortState = (playerHalfMapNode.isFortPresent()) ? EGameFortState.FortPresent
				: EGameFortState.NoFortStatePresent;
		MapNode newMapNode = new MapNode(coordinate, terrainType, fortState);
		if (fortState == EGameFortState.FortPresent)
			newMapNode.setPlayer1(playerID);

		return newMapNode;
	}

	/**
	 * converts PlayerPair to a list of PlayerState
	 * 
	 * @param players  (not null)
	 * @param playerID (not null)
	 * @return List<PlayerState> (not null)
	 */
	public static List<PlayerState> convertPlayerPairToListOfPlayerState(PlayerPair players, PlayerID playerID) {
		List<PlayerState> convertedPlayers = new ArrayList<>();
		UniquePlayerIdentifier fakePlayerID = new UniquePlayerIdentifier("");
		for (PlayerInfo player : players.toList()) {
			String firstName = player.getStudentFirstName();
			String lastName = player.getStudentLastName();
			String uaccount = player.getStudentUAccount();
			EPlayerGameState state = convertEPlayerActualGameStateToEPlayerGameState(player.getPlayerGameState());
			UniquePlayerIdentifier playerIdentifier;
			if (!playerID.equals(player.getPlayerID()))
				playerIdentifier = fakePlayerID;
			else
				playerIdentifier = ServerDataConverter.convertUniquePlayerIDToPlayerIdentifier(player.getPlayerID());

			boolean collectedTreasure = player.hasCollectedTreasure();
			convertedPlayers
					.add(new PlayerState(firstName, lastName, uaccount, state, playerIdentifier, collectedTreasure));
		}
		return convertedPlayers;
	}

	/**
	 * converts PlayerInfo to PlayerState
	 * 
	 * @param player (not null)
	 * @return PlayerState (not null)
	 */
	public static PlayerState convertPlayerInfoToPlayerState(PlayerInfo player) {
		String firstName = player.getStudentFirstName();
		String lastName = player.getStudentLastName();
		String uaccount = player.getStudentUAccount();
		EPlayerGameState state = convertEPlayerActualGameStateToEPlayerGameState(player.getPlayerGameState());
		UniquePlayerIdentifier playerIdentifier;
		playerIdentifier = ServerDataConverter.convertUniquePlayerIDToPlayerIdentifier(player.getPlayerID());
		boolean collectedTreasure = player.hasCollectedTreasure();
		return new PlayerState(firstName, lastName, uaccount, state, playerIdentifier, collectedTreasure);
	}

	// help methods
	// -------------------------------------------------------------------------------------------------------------------

	/**
	 * converts ETerrain to ETerrainType
	 * 
	 * @param eTerrain (not null)
	 * @return ETerrainType (not null)
	 */
	private static ETerrainType convertETerrainToETerrainType(ETerrain eTerrain) {
		ETerrainType eTerrainType = null;
		switch (eTerrain) {
		case Grass:
			eTerrainType = ETerrainType.Gras;
			break;
		case Mountain:
			eTerrainType = ETerrainType.Mountain;
			break;
		case Water:
			eTerrainType = ETerrainType.Water;
			break;
		}
		return eTerrainType;
	}

	/**
	 * converts ETerrain to ETerrainType
	 * 
	 * @param eTerrainType (not null)
	 * @return ETerrain (not null)
	 */
	private static ETerrain convertETerrainToETerrainType(ETerrainType eTerrainType) {
		ETerrain eTerrain = null;
		switch (eTerrainType) {
		case Gras:
			eTerrain = ETerrain.Grass;
			break;
		case Mountain:
			eTerrain = ETerrain.Mountain;
			break;
		case Water:
			eTerrain = ETerrain.Water;
			break;
		}
		return eTerrain;
	}

	/**
	 * retrieves a Player from a mapNode
	 * 
	 * @param mapNode  (not null)
	 * @param playerID (not null)
	 * @return messagesbase.messagesfromserver.EPlayerPositionState (not null)
	 */
	private static messagesbase.messagesfromserver.EPlayerPositionState retrievesPlayer(MapNode mapNode,
			PlayerID playerID) {
		if (mapNode.hasBothPlayers()) {
			return EPlayerPositionState.BothPlayerPosition;
		} else {
			if (mapNode.getPlayer1() != null && mapNode.getPlayer1().equals(playerID))
				return EPlayerPositionState.MyPlayerPosition;
			else if (mapNode.getPlayer1() != null && !mapNode.getPlayer1().equals(playerID))
				return EPlayerPositionState.EnemyPlayerPosition;
			else if (mapNode.getPlayer2() != null && mapNode.getPlayer2().equals(playerID))
				return EPlayerPositionState.MyPlayerPosition;
			else if (mapNode.getPlayer2() != null && !mapNode.getPlayer2().equals(playerID))
				return EPlayerPositionState.EnemyPlayerPosition;
			else
				return EPlayerPositionState.NoPlayerPresent;

		}
	}

	/**
	 * 
	 * 
	 * @param fullGameMap (not null)
	 * @param mapNode     (not null)
	 * @param playerID    (not null)
	 * @return messagesbase.messagesfromserver.ETreasureState (not null)
	 */
	private static messagesbase.messagesfromserver.ETreasureState retrievesTreasureState(IServerMap fullGameMap,
			MapNode mapNode, PlayerID playerID) {
		if (fullGameMap.getPlayerTreasures() != null && fullGameMap.getPlayerTreasures().size() > 0
				&& fullGameMap.getPlayerTreasures().get(playerID).equals(mapNode.getCoordinate()))
			return messagesbase.messagesfromserver.ETreasureState.MyTreasureIsPresent;
		else
			return messagesbase.messagesfromserver.ETreasureState.NoOrUnknownTreasureState;

	}

	/**
	 * retrieves the FortState from a fullGameMap and a MapNode
	 * 
	 * @param fullGameMap (not null)
	 * @param mapNode     (not null)
	 * @param playerID    (not null)
	 * @return EFortState (not null)
	 */
	private static EFortState retrievesFortState(IServerMap fullGameMap, MapNode mapNode, PlayerID playerID) {
		if (mapNode.getFortState() == EGameFortState.FortPresent && fullGameMap != null
				&& fullGameMap.getPlayerForts() != null && fullGameMap.getPlayerForts().size() > 0) {
			if (mapNode.getCoordinate().equals(fullGameMap.getPlayerForts().get(playerID)))
				return EFortState.MyFortPresent;
			else
				return EFortState.EnemyFortPresent;
		} else {
			return EFortState.NoOrUnknownFortState;
		}
	}

	/**
	 * converts EPlayerActualGameState to EPlayerGameState
	 * 
	 * @param gameState (not null)
	 * @return EPlayerGameState (not null)
	 */
	private static EPlayerGameState convertEPlayerActualGameStateToEPlayerGameState(EPlayerActualGameState gameState) {
		switch (gameState) {
		case Won:
			return EPlayerGameState.Won;
		case Lost:
			return EPlayerGameState.Lost;
		case MustAct:
			return EPlayerGameState.MustAct;
		default:
			return EPlayerGameState.MustWait;
		}
	}

}
