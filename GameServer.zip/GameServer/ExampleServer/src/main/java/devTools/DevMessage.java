package devTools;

/**
 * class to format logger information in terms of color (to highlight them in
 * the console)
 * 
 * @author Malte
 *
 */
public class DevMessage {

	public static String mInfo(String message) {
		return EColor.YELLOW.getColor() + message + EColor.RESET.getColor();
	}

	public static String mDebug(String message) {
		return EColor.WHITEBOLD.getColor() + message + EColor.RESET.getColor();
	}

	public static String mWarn(String message) {
		return EColor.CYAN.getColor() + message + EColor.RESET.getColor();
	}

	public static String mError(String message) {
		return EColor.RED.getColor() + message + EColor.RESET.getColor();
	}

	public static String markGreen(String message) {
		return EColor.GREEN.getColor() + message + EColor.RESET.getColor();
	}

	public static String markBlue(String message) {
		return EColor.BLUE.getColor() + message + EColor.RESET.getColor();
	}

	public static String markYellow(String message) {
		return EColor.YELLOW.getColor() + message + EColor.RESET.getColor();
	}

	public static String markRed(String message) {
		return EColor.RED.getColor() + message + EColor.RESET.getColor();
	}

	public static String markBlack(String message) {
		return EColor.BLACK.getColor() + message + EColor.RESET.getColor();
	}

	public static String markPurple(String message) {
		return EColor.PURPLE.getColor() + message + EColor.RESET.getColor();
	}

}
