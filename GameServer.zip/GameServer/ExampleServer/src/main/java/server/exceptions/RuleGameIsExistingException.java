package server.exceptions;

/**
 * documents error when a game with an specific gameID does not exist
 * 
 * @author Malte
 *
 */
public class RuleGameIsExistingException extends GenericServerException {

	public RuleGameIsExistingException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}
