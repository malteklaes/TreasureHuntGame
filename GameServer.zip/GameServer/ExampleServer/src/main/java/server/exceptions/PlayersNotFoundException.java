package server.exceptions;

/**
 * documents error when a player is not found to transact gameID-related
 * information
 * 
 * @author Malte
 *
 */
public class PlayersNotFoundException extends GenericServerException {

	public PlayersNotFoundException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}
