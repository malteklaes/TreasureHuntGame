package server.exceptions;

/**
 * documents error when half map has not the right amount of water field type on
 * its edges
 * 
 * @author Malte
 *
 */
public class RuleMapNotToMuchWaterfieldOnEdgesException extends GenericServerException {

	public RuleMapNotToMuchWaterfieldOnEdgesException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}