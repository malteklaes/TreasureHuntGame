package server.exceptions;

/**
 * documents error when there is a game with gameID but there are already two
 * players registered
 * 
 * @author Malte
 *
 */
public class PlayerInGameOverflowException extends GenericServerException {

	public PlayerInGameOverflowException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}
