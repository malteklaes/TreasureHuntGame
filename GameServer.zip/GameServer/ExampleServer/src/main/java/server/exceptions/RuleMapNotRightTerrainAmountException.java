package server.exceptions;

/**
 * documents error when half map has not the right amount of each field type
 * 
 * @author Malte
 *
 */
public class RuleMapNotRightTerrainAmountException extends GenericServerException {

	public RuleMapNotRightTerrainAmountException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}