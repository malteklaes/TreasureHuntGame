package server.exceptions;

/**
 * documents error when game's half map has placed its fort not on a gras field
 * 
 * @author Malte
 *
 */
public class RuleMapFortNotSetOnGrasException extends GenericServerException {

	public RuleMapFortNotSetOnGrasException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}