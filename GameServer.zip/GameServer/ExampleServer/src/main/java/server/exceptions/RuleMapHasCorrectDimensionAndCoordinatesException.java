package server.exceptions;

/**
 * documents error when no game has not the right coordinates and thus not the
 * right dimension
 * 
 * @author Malte
 *
 */
public class RuleMapHasCorrectDimensionAndCoordinatesException extends GenericServerException {

	public RuleMapHasCorrectDimensionAndCoordinatesException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}
