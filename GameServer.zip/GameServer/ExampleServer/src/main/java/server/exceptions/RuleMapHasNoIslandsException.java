package server.exceptions;

/**
 * documents error when half map has islands and fields, which can not been
 * entered
 * 
 * @author Malte
 *
 */
public class RuleMapHasNoIslandsException extends GenericServerException {

	public RuleMapHasNoIslandsException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}