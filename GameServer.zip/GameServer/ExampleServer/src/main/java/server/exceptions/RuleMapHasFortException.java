package server.exceptions;

/**
 * documents error when half map has not exactly one fort present on map
 * 
 * @author Malte
 *
 */
public class RuleMapHasFortException extends GenericServerException {

	public RuleMapHasFortException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}