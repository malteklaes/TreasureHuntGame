package server.exceptions;

/**
 * documents error when no game is not running anymore
 * 
 * @author Malte
 *
 */
public class GameIsNotActiveAnymoreException extends GenericServerException {

	public GameIsNotActiveAnymoreException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}