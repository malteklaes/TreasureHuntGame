package server.exceptions;

/**
 * documents error when no game contains specific playerID
 * 
 * @author Malte
 *
 */
public class RulePlayerIsExistingException extends GenericServerException {

	public RulePlayerIsExistingException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}
