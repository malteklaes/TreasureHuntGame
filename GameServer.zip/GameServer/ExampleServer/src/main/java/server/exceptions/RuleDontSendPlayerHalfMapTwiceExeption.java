package server.exceptions;

/**
 * documents error when a playerhalfmap is tried to send twice
 * 
 * @author Malte
 *
 */
public class RuleDontSendPlayerHalfMapTwiceExeption extends GenericServerException {

	public RuleDontSendPlayerHalfMapTwiceExeption(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}