package server.exceptions;

/**
 * documents error when half map has not right amount of half map nodes (50)
 * 
 * @author Malte
 *
 */
public class RuleMapNotRightSizeOfHalfMapException extends GenericServerException {

	public RuleMapNotRightSizeOfHalfMapException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}