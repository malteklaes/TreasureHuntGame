package server.exceptions;

/**
 * documents error when there is a player which it is not his turn
 * 
 * @author Malte
 *
 */
public class RuleIsPlayersTurnException extends GenericServerException {

	public RuleIsPlayersTurnException(String errorName, String errorMessage) {
		super(errorName, errorMessage);
	}

}