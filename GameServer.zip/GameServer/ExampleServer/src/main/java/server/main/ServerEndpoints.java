package server.main;

import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import game.BundleAnswerGameState;
import game.BundleAnswerRegisterPlayerHalfMap;
import game.GameController;
import game.GameID;
import game.PlayerID;
import game.PlayerInfo;
import map.IServerMap;
import messagesbase.ResponseEnvelope;
import messagesbase.UniqueGameIdentifier;
import messagesbase.UniquePlayerIdentifier;
import messagesbase.messagesfromclient.PlayerHalfMap;
import messagesbase.messagesfromclient.PlayerRegistration;
import messagesbase.messagesfromserver.GameState;
import network.ServerDataConverter;
import network.ServerMapConverter;
import server.exceptions.GenericServerException;

@RestController
@RequestMapping(value = "/games")
public class ServerEndpoints {

	private static Logger logger = LoggerFactory.getLogger(ServerEndpoints.class);

	private GameController gameC;

	public ServerEndpoints() {
		gameC = new GameController();
	}

	/**
	 * the GET endpoint to create a new game with a specific gameID
	 * 
	 * @param enableDebugMode        (not null)
	 * @param enableDummyCompetition (not null)
	 * @return UniqueGameIdentifier (a unique gameID consist of 5 characters build
	 *         by both string-characters and numbers and is not null)
	 */
	@RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody UniqueGameIdentifier newGame(
			@RequestParam(required = false, defaultValue = "false", value = "enableDebugMode") boolean enableDebugMode,
			@RequestParam(required = false, defaultValue = "false", value = "enableDummyCompetition") boolean enableDummyCompetition) {

		boolean showExceptionHandling = false;
		if (showExceptionHandling) {
			throw new GenericServerException("Name: Something", "Message: went totally wrong");
		}

		UniqueGameIdentifier gameIdentifier = ServerDataConverter
				.convertGameIDToUniqueGameIdentifier(this.gameC.startGame());
		return gameIdentifier;
	}

	/**
	 * the POST endpoint based on /games/{gameID}/players for registering a client
	 * 
	 * @param gameID             (not null)
	 * @param playerRegistration (not null)
	 * @return playerIDMessage (a unique playerID which is not null)
	 */
	@RequestMapping(value = "/{gameID}/players", method = RequestMethod.POST, consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody ResponseEnvelope<UniquePlayerIdentifier> registerPlayer(
			@Validated @PathVariable UniqueGameIdentifier gameID,
			@Validated @RequestBody PlayerRegistration playerRegistration) {
		// [1] create new and unique gameID
		UniquePlayerIdentifier newPlayerID = new UniquePlayerIdentifier(UUID.randomUUID().toString());
		// [2] convert steps
		GameID convertedGameID = ServerDataConverter.convertUniqueGameIdentifierToGameID(gameID);
		PlayerID playerID = ServerDataConverter.convertUniquePlayerIdentifierToPlayerID(newPlayerID);
		PlayerInfo player = ServerDataConverter.convertPlayerRegistrationToPlayerInfo(playerRegistration, playerID);
		// [3] check rules
		this.gameC.registerPlayer(convertedGameID, player);
		// [4] bundle result to ResponseEnvelope
		ResponseEnvelope<UniquePlayerIdentifier> playerIDMessage = new ResponseEnvelope<>(newPlayerID);

		return playerIDMessage;
	}

	/**
	 * anwers a request to register a clients half map by running multiple business
	 * rule checkings and saving the half map to a specific gameID. The answer will
	 * be bundled and returned as ResponseEnvelope<GameState>
	 * 
	 * @param gameID        (not null)
	 * @param playerHalfMap (not null)
	 * @return ResponseEnvelope<GameState> (not null)
	 */
	@RequestMapping(value = "/{gameID}/halfmaps", method = RequestMethod.POST, consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody ResponseEnvelope<GameState> registerClientHalfMap(
			@Validated @PathVariable UniqueGameIdentifier gameID, @Validated @RequestBody PlayerHalfMap playerHalfMap) {
		// [1] convert incoming data
		GameID convertedGameID = ServerDataConverter.convertUniqueGameIdentifierToGameID(gameID);
		PlayerID playerID = ServerMapConverter.retrievePlayerIDFromPlayerHalfMap(playerHalfMap);
		IServerMap gameHalfMap = ServerMapConverter.convertNewPlayerHalfMapToIServerMap(playerHalfMap, playerID);

		// [2] check (business) rules
		BundleAnswerRegisterPlayerHalfMap gameStateAnswer = this.gameC.registerPlayerHalfMap(convertedGameID, playerID,
				gameHalfMap);

		GameState gameState = ServerMapConverter.convertBundleAnswerRegisterPlayerHalfMapToGameState(gameStateAnswer);
		return new ResponseEnvelope<>(gameState);
	}

	/**
	 * answers a game state request by first retrieving and checking all necessary
	 * data and bundles them afterwards into a ResponseEnvelope<GameState>
	 * 
	 * @param gameID   (not null)
	 * @param playerID (not null)
	 * @return ResponseEnvelope<GameState> (not null)
	 */
	@RequestMapping(value = "/{gameID}/states/{playerID}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody ResponseEnvelope<GameState> answerGameState(
			@Validated @PathVariable UniqueGameIdentifier gameID,
			@Validated @PathVariable UniquePlayerIdentifier playerID) {
		// [1] convert incoming data
		GameID convertedGameID = ServerDataConverter.convertUniqueGameIdentifierToGameID(gameID);
		PlayerID convertedPlayerID = ServerDataConverter.convertUniquePlayerIdentifierToPlayerID(playerID);

		// [2] process game state
		BundleAnswerGameState gameStateAnswer = this.gameC.processGameState(convertedGameID, convertedPlayerID);

		GameState gameState = ServerMapConverter.convertBundleAnswerGameStateToGameState(gameStateAnswer);
		return new ResponseEnvelope<>(gameState);
	}

	/*
	 * Note, this is only the most basic way of handling exceptions in Spring (but
	 * sufficient for our task) it would, for example struggle if you use multiple
	 * controllers. Add the exception types to the @ExceptionHandler which your
	 * exception handling should support the superclass catches subclasses aspect of
	 * try/catch also applies here. Hence, we recommend to simply extend your own
	 * Exceptions from the GenericExampleException. For larger projects, one would
	 * most likely want to use the HandlerExceptionResolver; see here
	 * https://www.baeldung.com/exception-handling-for-rest-with-spring
	 * 
	 * Ask yourself: Why is handling the exceptions in a different method than the
	 * endpoint methods a good solution? This applies a principle from Block 4,
	 * which one?
	 */
	@ExceptionHandler({ GenericServerException.class })
	public @ResponseBody ResponseEnvelope<?> handleException(GenericServerException ex, HttpServletResponse response) {
		ResponseEnvelope<?> result = new ResponseEnvelope<>(ex.getErrorName(), ex.getMessage());

		// reply with 200 OK as defined in the network documentation
		// Side note: We only do this here for simplicity reasons. For future projects,
		// you should check out HTTP status codes and
		// what they can be used for. Note, the WebClient used during the Client
		// implementation can react
		// to them using the .onStatus(...) method.
		response.setStatus(HttpServletResponse.SC_OK);
		return result;
	}
}
