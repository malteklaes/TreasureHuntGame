package map;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import game.ECompass;
import game.EPlayersPositionOnFullGameMap;
import game.PlayerID;

/**
 * represents both a clientHalfMap and a full game map
 * 
 * @author Malte
 *
 */
public class GameMap implements IServerMap, Cloneable {

	private static Logger logger = LoggerFactory.getLogger(GameMap.class);

	private Set<MapNode> mapNodes;
	private EPlayersPositionOnFullGameMap playersPositionOnFullMap;
	private Map<PlayerID, Coordinate> playerPositions;
	private Map<PlayerID, Coordinate> playerForts;
	private Map<PlayerID, Coordinate> playerTreasures;

	public GameMap() {
		mapNodes = new HashSet();
		playerPositions = new HashMap<>();
		playerForts = new HashMap<>();
		playerTreasures = new HashMap<>();
	}

	public GameMap(Set<MapNode> mapNodes) {
		this.mapNodes = mapNodes;
		playerPositions = new HashMap<>();
		playerForts = new HashMap<>();
		playerTreasures = new HashMap<>();
	}

	/**
	 * mainly for clone purpose
	 * 
	 * @param mapNodes                 (not null)
	 * @param playersPositionOnFullMap (not null)
	 * @param playerPositions          (not null)
	 * @param playerForts              (not null)
	 * @param playerTreasures          (not null)
	 */
	public GameMap(Set<MapNode> mapNodes, EPlayersPositionOnFullGameMap playersPositionOnFullMap,
			Map<PlayerID, Coordinate> playerPositions, Map<PlayerID, Coordinate> playerForts,
			Map<PlayerID, Coordinate> playerTreasures) {
		this.mapNodes = mapNodes;
		this.playersPositionOnFullMap = playersPositionOnFullMap;
		this.playerPositions = playerPositions;
		this.playerForts = playerForts;
		this.playerTreasures = playerTreasures;
	}

	@Override
	public void addMapNode(MapNode mapNode) {
		mapNodes.add(mapNode);
		this.playersPositionOnFullMap = EPlayersPositionOnFullGameMap.NoPositioning;
	}

	@Override
	public void addPlayerPosition(Coordinate coordinate, PlayerID playerID) {
		this.playerPositions.put(playerID, coordinate);
	}

	@Override
	public void addPlayerFort(Coordinate coordinate, PlayerID playerID) {
		this.playerForts.put(playerID, coordinate);
	}

	@Override
	public Coordinate getPlayerFortCoordinateByPlayerID(PlayerID playerID) {
		return playerForts.get(playerID);
	}

	@Override
	public Map<PlayerID, Coordinate> getPlayerForts() {
		return playerForts;
	}

	@Override
	public void addPlayerTreasure(Coordinate coordinate, PlayerID playerID) {
		this.playerTreasures.put(playerID, coordinate);
	}

	@Override
	public Map<PlayerID, Coordinate> getPlayerTreasures() {
		return playerTreasures;
	}

	@Override
	public IServerMap joinMapsRandomly(IServerMap[] playerHalfMaps, PlayerID[] playersIDOfHalfMaps,
			EPlayersPositionOnFullGameMap playerPosition) {
		IServerMap resultFullMap = new GameMap();
		logger.debug(DevMessage.mDebug("join-strategy: " + playerPosition));
		switch (playerPosition) {
		case SquareFirstPlayerSouth:
			resultFullMap = joinMapsToSquareByNorthFirstmapSouthSecondMap(playerHalfMaps[0], playersIDOfHalfMaps[0],
					playerHalfMaps[1], playersIDOfHalfMaps[1]);
			resultFullMap.setPlayersPosition(playerPosition);
			return resultFullMap;
		case SquareFirstPlayerNorth:
			resultFullMap = joinMapsToSquareBySouthFirstmapNorthSecondMap(playerHalfMaps[0], playersIDOfHalfMaps[0],
					playerHalfMaps[1], playersIDOfHalfMaps[1]);
			resultFullMap.setPlayersPosition(playerPosition);
			return resultFullMap;
		case RectangleFirstPlayerWest:
			resultFullMap = joinMapsToRectangleByEastFirstmapWestSecondMap(playerHalfMaps[0], playersIDOfHalfMaps[0],
					playerHalfMaps[1], playersIDOfHalfMaps[1]);
			resultFullMap.setPlayersPosition(playerPosition);
			return resultFullMap;
		default:
			resultFullMap = joinMapsToRectangleByWestFirstmapEastSecondMap(playerHalfMaps[0], playersIDOfHalfMaps[0],
					playerHalfMaps[1], playersIDOfHalfMaps[1]);
			resultFullMap.setPlayersPosition(playerPosition);
			return resultFullMap;
		}
	}

	/**
	 * joins two halfMaps on the north side of the first map and the south side of
	 * the second map, so the result is a square: first player/firstMap is on south
	 * side
	 * 
	 * @param firstMap  (not null)
	 * @param player1   (not null)
	 * @param secondMap (not null)
	 * @param player2   (not null)
	 * @return IServerMap (not null)
	 */
	private IServerMap joinMapsToSquareByNorthFirstmapSouthSecondMap(IServerMap firstMap, PlayerID player1,
			IServerMap secondMap, PlayerID player2) {
		return joinMaps(secondMap, player2, firstMap, player1, 0, 5);
	}

	/**
	 * joins two halfMaps on the south side of the first map and the north side of
	 * the second map, so the result is a square: first player/firstMap is on north
	 * side
	 * 
	 * @param firstMap  (not null)
	 * @param player1   (not null)
	 * @param secondMap (not null)
	 * @param player2   (not null)
	 * @return IServerMap (not null)
	 */
	private IServerMap joinMapsToSquareBySouthFirstmapNorthSecondMap(IServerMap firstMap, PlayerID player1,
			IServerMap secondMap, PlayerID player2) {
		return joinMaps(firstMap, player1, secondMap, player2, 0, 5);
	}

	/**
	 * joins two halfMaps on the east side of the first map and the west side of the
	 * second map, so the result is a rectangle: first player/firstMap is on west
	 * side
	 * 
	 * @param firstMap  (not null)
	 * @param player1   (not null)
	 * @param secondMap (not null)
	 * @param player2   (not null)
	 * @return IServerMap (not null)
	 */
	private IServerMap joinMapsToRectangleByEastFirstmapWestSecondMap(IServerMap firstMap, PlayerID player1,
			IServerMap secondMap, PlayerID player2) {
		return joinMaps(firstMap, player1, secondMap, player2, 10, 0);
	}

	/**
	 * joins two halfMaps on the west side of the first map and the east side of the
	 * second map, so the result is a rectangle: first player/firstMap is on east
	 * side
	 * 
	 * @param firstMap  (not null)
	 * @param player1   (not null)
	 * @param secondMap (not null)
	 * @param player2   (not null)
	 * @return IServerMap (not null)
	 */
	private IServerMap joinMapsToRectangleByWestFirstmapEastSecondMap(IServerMap firstMap, PlayerID player1,
			IServerMap secondMap, PlayerID player2) {
		return joinMaps(secondMap, player2, firstMap, player1, 10, 0);
	}

	/**
	 * joins two maps
	 * 
	 * @param firstMap  (belongs to player1) (not null)
	 * @param player1   (owns firstMap) (not null)
	 * @param secondMap (belongs to player2) (not null)
	 * @param player2   (owns second Map) (not null)
	 * @param shiftX    (how much a given coordinate should be shifted in x
	 *                  direction) (not null)
	 * @param shiftY    (how much a given coordinate should be shifted in y
	 *                  direction) (not null)
	 * @return IServerMap (not null)
	 */
	private IServerMap joinMaps(IServerMap firstMap, PlayerID player1, IServerMap secondMap, PlayerID player2,
			int shiftX, int shiftY) {
		Coordinate treasureCoordOfplayer1 = firstMap.setTreasureRandomly();
		Coordinate treasureCoordOfplayer2 = secondMap.setTreasureRandomly();
		IServerMap fullGameMap = firstMap;
		fullGameMap.addPlayerFort(firstMap.getPlayerFortCoordinateByPlayerID(player1), player1);
		fullGameMap.addPlayerPosition(firstMap.getPlayerFortCoordinateByPlayerID(player1), player1);
		for (int x = 0; x < secondMap.getMaxCoordinate().getXCoord() + 1; x++) {
			for (int y = 0; y < secondMap.getMaxCoordinate().getYCoord() + 1; y++) {
				Coordinate actualCoord = new Coordinate(x, y);
				Coordinate shiftedCoord = new Coordinate(x + shiftX, y + shiftY);
				ETerrainType terrainType = secondMap.getMapNode(actualCoord).getTerrainType();
				EGameFortState fortState = secondMap.getMapNode(actualCoord).getFortState();
				ETreasureState treasureState = secondMap.getMapNode(actualCoord).getTreasureState();
				MapNode newMapNode = new MapNode(shiftedCoord, terrainType, fortState, treasureState);
				if (secondMap.getMapNode(actualCoord).getPlayer1() != null) {
					newMapNode.setPlayer1(secondMap.getMapNode(actualCoord).getPlayer1());
				}
				if (fortState == EGameFortState.FortPresent) {
					fullGameMap.addPlayerFort(shiftedCoord, player2);
					fullGameMap.addPlayerPosition(shiftedCoord, player2);
				}
				fullGameMap.addMapNode(newMapNode);
			}
		}
		fullGameMap.addPlayerTreasure(treasureCoordOfplayer1, player1);
		fullGameMap.addPlayerTreasure(treasureCoordOfplayer2, player2);
		return fullGameMap;
	}

	@Override
	public Coordinate hidePlayersPosition(PlayerID playerID) {
		if (playerPositions.size() == 2) {
			for (var playersPosition : playerPositions.entrySet()) {
				if (playersPosition.getKey() != playerID && playerPositions.get(playersPosition.getKey()) != null) {
					return this.findrandomPlayersPosition(playersPosition.getValue());
				}
			}
		}
		return null;
	}

	/**
	 * finds player position which is on a gras field unlike the first Position
	 * 
	 * @param playerID (not null)
	 * @return Coordinate (not null)
	 */
	private Coordinate findrandomPlayersPosition(Coordinate actualPosition) {
		boolean playersHide = false;
		int randomXCoord = new Random().nextInt(this.getMaxCoordinate().getXCoord() + 1);
		int randomYCoord = new Random().nextInt(this.getMaxCoordinate().getYCoord() + 1);
		Coordinate newHiddenPlayersPosition = new Coordinate(0, 0);
		while (!playersHide) {
			for (MapNode mapNode : this.mapNodes) {
				if (mapNode != null
						&& mapNode.getCoordinate().compareTo(new Coordinate(randomXCoord, randomYCoord)) == 0
						&& mapNode.getTerrainType() == ETerrainType.Gras
						&& actualPosition.compareTo(new Coordinate(randomXCoord, randomYCoord)) != 0 && !playersHide) {
					playersHide = true;
					newHiddenPlayersPosition = new Coordinate(randomXCoord, randomYCoord);
				}
			}
			randomXCoord = new Random().nextInt(this.getMaxCoordinate().getXCoord() + 1);
			randomYCoord = new Random().nextInt(this.getMaxCoordinate().getYCoord() + 1);
		}
		return newHiddenPlayersPosition;
	}

	@Override
	public Coordinate setTreasureRandomly() {
		boolean treasurePlaced = false;
		int randomXCoord = new Random().nextInt(this.getMaxCoordinate().getXCoord() + 1);
		int randomYCoord = new Random().nextInt(this.getMaxCoordinate().getYCoord() + 1);
		Coordinate finalTreasureCoordinate = new Coordinate(0, 0);
		while (!treasurePlaced) {
			for (MapNode mapNode : this.mapNodes) {
				if (mapNode != null
						&& mapNode.getCoordinate().compareTo(new Coordinate(randomXCoord, randomYCoord)) == 0
						&& mapNode.getTerrainType() == ETerrainType.Gras
						&& mapNode.getFortState() == EGameFortState.NoFortStatePresent && !treasurePlaced) {
					treasurePlaced = true;
					mapNode.setTreasureState(ETreasureState.MyTreasureIsPresent);
					finalTreasureCoordinate = new Coordinate(randomXCoord, randomYCoord);
				}
			}
			randomXCoord = new Random().nextInt(this.getMaxCoordinate().getXCoord() + 1);
			randomYCoord = new Random().nextInt(this.getMaxCoordinate().getYCoord() + 1);
		}
		return finalTreasureCoordinate;
	}

	@Override
	public MapNode getMapNode(Coordinate coordinate) {
		for (MapNode mapNode : mapNodes) {
			if (mapNode.getCoordinate().compareTo(coordinate) == 0) {
				return mapNode;
			}
		}
		return null;
	}

	@Override
	public Collection<MapNode> getMapNodes() {
		return this.mapNodes;
	}

	@Override
	public Coordinate getMaxCoordinate() {
		Coordinate maxCoord = new Coordinate(0, 0);
		for (MapNode mapNode : mapNodes) {
			if (mapNode.getCoordinate().compareTo(maxCoord) == 1) {
				maxCoord = mapNode.getCoordinate();
			}
		}
		return maxCoord;
	}

	public EPlayersPositionOnFullGameMap getPlayersPositionOnFullMap() {
		return playersPositionOnFullMap;
	}

	@Override
	public void setPlayersPosition(EPlayersPositionOnFullGameMap playersPositionOnFullMap) {
		this.playersPositionOnFullMap = playersPositionOnFullMap;
	}

	@Override
	public void setFieldTerrain(Coordinate coordinate, ETerrainType terrain) {
		this.transformMapNodeFieldTypeByCoordinate(coordinate, terrain);
	}

	/**
	 * sets a demanden coordinate's terrain to given terrain-value
	 * 
	 * @param coordinate (not null)
	 * @param terrain    (not null)
	 * @return true (if terrain was set to terrain-value given as parameter)
	 */
	private boolean transformMapNodeFieldTypeByCoordinate(Coordinate coordinate, ETerrainType terrain) {
		for (var mapNode : mapNodes) {
			if (mapNode.getCoordinate().equals(coordinate)) {
				mapNode.setTerrainType(terrain);
				return true;
			}
		}
		return false;
	}

	@Override
	public int countWaterNodes() {
		if (mapNodes == null)
			return -1;

		int countWaterFields = 0;
		for (var mapNode : mapNodes) {
			if (mapNode.getTerrainType() == ETerrainType.Water) {
				countWaterFields++;
			}
		}
		return countWaterFields;
	}

	@Override
	public String toString() {
		String mapShape = (this.isSquare()) ? "shape:SQUARE" : "shape:RECTANGLE";
		String resultMap = DevMessage
				.markYellow("\n\nMAP " + mapShape + " -------------------------------------------\n\n");
		for (int y = 0; y < this.getMaxCoordinate().getYCoord() + 1; y++) {
			for (int x = 0; x < this.getMaxCoordinate().getXCoord() + 1; x++) {
				Coordinate actualCoord = new Coordinate(x, y);
				// [1] fort was found
				if (this.getMapNode(actualCoord) != null
						&& this.getMapNode(actualCoord).getFortState() == EGameFortState.FortPresent) {
					if (this.compareECompassWithPlayersPosition(this.whereIsCoordInMap(actualCoord))) {
						String fortSymbolFirstPlayer = DevMessage.markBlack(" F ");
						resultMap += fortSymbolFirstPlayer;
					} else {
						String fortSymbolSecondPlayer = DevMessage.markPurple(" f ");
						resultMap += fortSymbolSecondPlayer;
					}
				}
				// [2] treasure states
				else if (this.getMapNode(actualCoord) != null
						&& this.getMapNode(actualCoord).getTreasureState() == ETreasureState.MyTreasureIsPresent) {
					if (this.compareECompassWithPlayersPosition(this.whereIsCoordInMap(actualCoord))) {
						String treasureSymbolFirstPlayer = DevMessage.markYellow(" T ");
						resultMap += treasureSymbolFirstPlayer;
					} else {
						String treasureSymbolSecondPlayer = DevMessage.markYellow(" t ");
						resultMap += treasureSymbolSecondPlayer;
					}
				}
				// [3] general field type
				else {
					if (this.getMapNode(actualCoord) != null)
						resultMap += this.convertTerrainTypToString(this.getMapNode(actualCoord).getTerrainType());
				}
			}
			resultMap += "\n";
		}
		return resultMap
				+ DevMessage.markYellow("\n---------------------------------------------------------------- \n");
	}

	/**
	 * converts a given terrain field to a corresponding colored String
	 * 
	 * @param terrainType (not null)
	 * @return String (not null)
	 */
	private String convertTerrainTypToString(ETerrainType terrainType) {
		switch (terrainType) {
		case Gras:
			return DevMessage.markGreen(" g ");
		case Mountain:
			return DevMessage.markRed(" m ");
		default:
			return DevMessage.markBlue(" w ");
		}
	}

	/**
	 * compares a given direction with this, two cases: square and rectangle
	 * 
	 * @param direction (not null)
	 * @return true (if playersPositionOnFullMap is equal to given direction
	 *         depending on square or rectangle)
	 */
	private boolean compareECompassWithPlayersPosition(ECompass direction) {
		if (this.playersPositionOnFullMap == EPlayersPositionOnFullGameMap.NoPositioning)
			return false;
		if (this.isSquare()) {
			if (((direction == ECompass.North)
					&& this.playersPositionOnFullMap == EPlayersPositionOnFullGameMap.SquareFirstPlayerNorth)
					|| ((direction == ECompass.South)
							&& this.playersPositionOnFullMap == EPlayersPositionOnFullGameMap.SquareFirstPlayerSouth)) {
				return true;
			} else
				return false;
		} else {
			if (((direction == ECompass.East)
					&& this.playersPositionOnFullMap == EPlayersPositionOnFullGameMap.RectangleFirstPlayerEast)
					|| ((direction == ECompass.West)
							&& this.playersPositionOnFullMap == EPlayersPositionOnFullGameMap.RectangleFirstPlayerWest)) {
				return true;
			} else
				return false;
		}
	}

	/**
	 * checks where given coordinate is located on this map
	 * 
	 * @param coord (not null)
	 * @return ECompass (not null, north/south/east/west)
	 */
	private ECompass whereIsCoordInMap(Coordinate coord) {
		if (this.isSquare()) {
			int yDim = 5;
			ECompass result = (coord.getYCoord() < yDim) ? ECompass.North : ECompass.South;
			return result;
		} else {
			int xDim = 10;
			ECompass result = (coord.getXCoord() < xDim) ? ECompass.West : ECompass.East;
			return result;
		}
	}

	/**
	 * checks, if this map is a sqaure in terms of dimension
	 * 
	 * @return boolean (if it is a square)
	 */
	private boolean isSquare() {
		return this.getMaxCoordinate().getXCoord() == this.getMaxCoordinate().getYCoord();
	}

	@Override
	public int hashCode() {
		return Objects.hash(mapNodes);
	}

	@Override
	public IServerMap clone() {
		Set<MapNode> mapNodesCopy = new HashSet<>();
		for (MapNode mapNode : mapNodes) {
			mapNodesCopy.add(mapNode.clone());
		}
		EPlayersPositionOnFullGameMap copiedPosition = this.getPlayersPositionOnFullMap();
		// playerPositions clone
		Map<PlayerID, Coordinate> playerPositionsClone = new HashMap<>();
		for (Map.Entry<PlayerID, Coordinate> entry : playerPositions.entrySet()) {
			PlayerID playerID = new PlayerID(entry.getKey());
			Coordinate coordinate = entry.getValue().clone();
			playerPositionsClone.put(playerID, coordinate);
		}
		// playerForts clone
		Map<PlayerID, Coordinate> playerFortsClone = new HashMap<>();
		for (Map.Entry<PlayerID, Coordinate> entry : playerForts.entrySet()) {
			PlayerID playerID = new PlayerID(entry.getKey());
			Coordinate coordinate = entry.getValue().clone();
			playerFortsClone.put(playerID, coordinate);
		}
		// playerTreasures clone
		Map<PlayerID, Coordinate> playerTreasuresClone = new HashMap<>();
		for (Map.Entry<PlayerID, Coordinate> entry : playerTreasures.entrySet()) {
			PlayerID playerID = new PlayerID(entry.getKey());
			Coordinate coordinate = entry.getValue().clone();
			playerTreasuresClone.put(playerID, coordinate);
		}
		return new GameMap(mapNodesCopy, copiedPosition, playerPositionsClone, playerFortsClone, playerTreasuresClone);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GameMap other = (GameMap) obj;
		return this.checkEachMapNodeIsEqual(this, other);
	}

	/**
	 * compares given map and this map, if every mapNode is equal
	 * 
	 * @param gameMap      (will be checked)
	 * @param otherGameMap (will be checked)
	 * @return true (if every mapnode is equal)
	 */
	private boolean checkEachMapNodeIsEqual(GameMap gameMap, GameMap otherGameMap) {
		if (gameMap != null && otherGameMap != null
				&& gameMap.getMapNodes().size() != otherGameMap.getMapNodes().size())
			return false;
		boolean equal = true;
		Coordinate actualCoordinate = new Coordinate(0, 0);
		for (int y = 0; y < gameMap.getMaxCoordinate().getYCoord(); y++) {
			for (int x = 0; x < gameMap.getMaxCoordinate().getXCoord(); x++) {
				actualCoordinate = new Coordinate(x, y);
				if (gameMap.getMapNode(actualCoordinate).getTerrainType() != otherGameMap.getMapNode(actualCoordinate)
						.getTerrainType()) {
					equal = false;
				}
			}
		}
		return equal;
	}

}
