package map;

/**
 * enum defines terrain type on a particular node [Gras, Mountain, Water]
 * 
 * @author Malte
 *
 */
public enum ETerrainType {
	Gras, Mountain, Water
}
