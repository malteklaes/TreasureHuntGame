package map;

/**
 * enum defines if treasure is on a particular node [NoOrUnknownTreasureState,
 * MyTreasureIsPresent]
 * 
 * @author Malte
 *
 */
public enum ETreasureState {
	NoOrUnknownTreasureState, MyTreasureIsPresent
}
