package map;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import game.PlayerID;

/**
 * defines and models state on a particular node
 * 
 * @author Malte
 *
 */
public class MapNode implements Cloneable {

	private static Logger logger = LoggerFactory.getLogger(MapNode.class);

	private Coordinate coordinate;
	private ETerrainType terrainType;
	private EGameFortState fortState;
	private ETreasureState treasureState;
	private PlayerID player1;
	private PlayerID player2;

	public MapNode(Coordinate coordinate, ETerrainType terrainType, EGameFortState fortState,
			ETreasureState treasureState) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
		this.fortState = fortState;
		this.treasureState = treasureState;
		logger.debug("a MapNode was succesfully created with coordinates: {}", this.coordinate);
	}

	public MapNode(Coordinate coordinate, ETerrainType terrainType, EGameFortState fortState, PlayerID player1,
			PlayerID player2) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
		this.fortState = fortState;
		this.treasureState = ETreasureState.NoOrUnknownTreasureState;
		this.player1 = player1;
		this.player2 = player2;
	}

	public MapNode(Coordinate coordinate, ETerrainType terrainType, EGameFortState fortState) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
		this.fortState = fortState;
		this.treasureState = ETreasureState.NoOrUnknownTreasureState;
	}

	/**
	 * only sets terrainType for a specific node (on a specific coordinate)
	 * 
	 * @param coordinate  (not null)
	 * @param terrainType (not null)
	 */
	public MapNode(Coordinate coordinate, ETerrainType terrainType) {
		this.coordinate = coordinate;
		this.terrainType = terrainType;
		this.treasureState = ETreasureState.NoOrUnknownTreasureState;
	}

	@Override
	public MapNode clone() {
		Coordinate coordinateCopy = this.coordinate.clone();
		ETerrainType terrainTypeCopy = this.terrainType;
		EGameFortState fortStateCopy = this.fortState;
		logger.debug("a deep copy of an MapNode was succesfully created.");
		PlayerID newPlayer1 = (player1 != null) ? new PlayerID(player1.getPlayerID()) : null;
		PlayerID newPlayer2 = (player2 != null) ? new PlayerID(player2.getPlayerID()) : null;
		MapNode deepCopiedMapNode = new MapNode(coordinateCopy, terrainTypeCopy, fortStateCopy, newPlayer1, newPlayer2);
		deepCopiedMapNode.setTreasureState(this.treasureState);
		return deepCopiedMapNode;
	}

	/**
	 * outputs all variables (coordinate, fortState, playerPositionState,
	 * terrainType, treasureState)
	 */
	@Override
	public String toString() {
		return "MapNode [coordinate=" + coordinate + ", terrainType=" + terrainType + ", fortState=" + fortState + "]";
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public ETerrainType getTerrainType() {
		return terrainType;
	}

	/**
	 * @param terrainType (not null)
	 */
	public void setTerrainType(ETerrainType terrainType) {
		this.terrainType = terrainType;
	}

	public EGameFortState getFortState() {
		return fortState;
	}

	/**
	 * @param fortState (not null)
	 */
	public void setFortState(EGameFortState fortState) {
		this.fortState = fortState;
	}

	public PlayerID getPlayer1() {
		return player1;
	}

	/**
	 * @param player1 (not null)
	 */
	public void setPlayer1(PlayerID player1) {
		this.player1 = player1;
	}

	public PlayerID getPlayer2() {
		return player2;
	}

	/**
	 * @param player2 (not null)
	 */
	public void setPlayer2(PlayerID player2) {
		this.player2 = player2;
	}

	/**
	 * checks if both players are available
	 * 
	 * @return true (if both players are available)
	 */
	public boolean hasBothPlayers() {
		return (player1 != null) && (player2 != null);
	}

	/**
	 * @return true (if player1 exists)
	 */
	public boolean containsPlayer1() {
		return player1 != null;
	}

	/**
	 * checks if a certain player exists on this node
	 * 
	 * @param playerID (will be checked)
	 * @return true (if player exists)
	 */
	public boolean containsPlayer(PlayerID playerID) {
		return (player1 != null && player1.equals(playerID)) || (player2 != null && player2.equals(playerID));
	}

	public ETreasureState getTreasureState() {
		return treasureState;
	}

	public void setTreasureState(ETreasureState treasureState) {
		this.treasureState = treasureState;
	}

	@Override
	public int hashCode() {
		return Objects.hash(coordinate, fortState, terrainType);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MapNode other = (MapNode) obj;
		return Objects.equals(coordinate, other.coordinate) && fortState == other.fortState
				&& terrainType == other.terrainType && treasureState == other.treasureState;
	}

}
