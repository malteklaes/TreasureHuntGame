package map;

/**
 * enum defines if fort is on a particular node [NoFortStatePresent,
 * FortPresent]
 * 
 * @author Malte
 *
 */
public enum EGameFortState {
	NoFortStatePresent, FortPresent
}
