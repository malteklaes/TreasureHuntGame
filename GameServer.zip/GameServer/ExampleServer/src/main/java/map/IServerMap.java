package map;

import java.util.Collection;
import java.util.Map;

import game.EPlayersPositionOnFullGameMap;
import game.PlayerID;

/**
 * has as an underlying foundation an IGrid and represents the idea of a map in
 * a more functional way
 * 
 * @author Malte
 *
 */
public interface IServerMap {

	/**
	 * adds a mapNode to this map
	 * 
	 * @param mapNode
	 */
	public void addMapNode(MapNode mapNode);

	/**
	 * add players position to map
	 * 
	 * @param coordinate (not null)
	 * @param playerID   (not null)
	 */
	public void addPlayerPosition(Coordinate coordinate, PlayerID playerID);

	/**
	 * adds forts position of a player to map
	 * 
	 * @param coordinate (not null)
	 * @param playerID   (not null)
	 */
	public void addPlayerFort(Coordinate coordinate, PlayerID playerID);

	public Map<PlayerID, Coordinate> getPlayerForts();

	public Coordinate getPlayerFortCoordinateByPlayerID(PlayerID playerID);

	/**
	 * adds treasures position of a player to map
	 * 
	 * @param coordinate (not null)
	 * @param playerID   (not null)
	 */
	public void addPlayerTreasure(Coordinate coordinate, PlayerID playerID);

	public Map<PlayerID, Coordinate> getPlayerTreasures();

	/**
	 * joins two maps randomly depending on playerspostiion
	 * 
	 * @param playerHalfMaps      (not null and an Array of exactly two
	 *                            playersHalfMaps)
	 * @param playersIDOfHalfMaps (not null)
	 * @param playerPosition      (not null)
	 * @return IServerMap (not null)
	 */
	public IServerMap joinMapsRandomly(IServerMap[] playerHalfMaps, PlayerID[] playersIDOfHalfMaps,
			EPlayersPositionOnFullGameMap playerPosition);

	/**
	 * sets randomly treasure due to business rules (on no water- nor
	 * mountain-field)
	 * 
	 * @return Coordinate (not null)
	 */
	public Coordinate setTreasureRandomly();

	/**
	 * hides the enemy of the given playerID
	 * 
	 * @param playerID (not null)
	 * @return (might be null and must be checked outside)
	 */
	public Coordinate hidePlayersPosition(PlayerID playerID);

	/**
	 * searchs for the greatest Coordinate in a map
	 * 
	 * @return Coordinate (not null)
	 */
	public Coordinate getMaxCoordinate();

	/**
	 * searchs for mapNode in a map by given Coordinate
	 * 
	 * @param coordinate (not null)
	 * @return MapNode (might be null if given Coordinate exceeds maps dimension,
	 *         must be checked)
	 */
	public MapNode getMapNode(Coordinate coordinate);

	/**
	 * get container for MapNodes
	 * 
	 * @return Collection<MapNode> (not null)
	 */
	public Collection<MapNode> getMapNodes();

	/**
	 * clearify where players are on a map
	 * 
	 * @param playersPosition (not null)
	 */
	public void setPlayersPosition(EPlayersPositionOnFullGameMap playersPosition);

	/**
	 * set a field type to a specific coordinate (mostly for testing purpose like
	 * floodfill-algorithm)
	 * 
	 * @param coordinate (not null)
	 * @param terrain    (not null)
	 */
	public void setFieldTerrain(Coordinate coordinate, ETerrainType terrain);

	/**
	 * counts the total amount of water nodes in a map
	 * 
	 * @return int (-1, if halfMap has no nodes at all, otherwise 0 or higher)
	 */
	public int countWaterNodes();

	/**
	 * print map for testing purpose
	 * 
	 * @return String (not null)
	 */
	public String toString();

	public int hashCode();

	/**
	 * creates a deep copy of this
	 * 
	 * @return IServerMap (not null)
	 */
	public IServerMap clone();

	/**
	 * two maps are equal, if each MapNode is equal
	 * 
	 * @param obj (not null)
	 * @return true (if equal)
	 */
	public boolean equals(Object obj);

}
