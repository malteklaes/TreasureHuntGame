package map;

/**
 * enum defines which player is on a particular node [NoPlayerPresent,
 * EnemyPlayerPosition, MyPlayerPosition, BothPlayerPosition]
 * 
 * @author Malte
 *
 */
public enum EPlayerPositionState {
	NoPlayerPresent, EnemyPlayerPosition, MyPlayerPosition, BothPlayerPosition

}
