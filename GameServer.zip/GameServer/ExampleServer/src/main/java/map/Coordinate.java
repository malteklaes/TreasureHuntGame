package map;

import java.util.Comparator;
import java.util.Objects;

/**
 * basic 2D representation for a map
 * 
 * @author Malte
 *
 */
public class Coordinate implements Comparator<Coordinate>, Comparable<Coordinate>, Cloneable {

	private int xCoord;
	private int yCoord;

	/**
	 * @param x_coord (not null)
	 * @param y_coord (not null)
	 */
	public Coordinate(int xCoord, int yCoord) {
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}

	/**
	 * @param coordinates (not null)
	 */
	public Coordinate(Coordinate coordinates) {
		this.xCoord = coordinates.xCoord;
		this.yCoord = coordinates.yCoord;
	}

	@Override
	public Coordinate clone() {
		int result_x = xCoord;
		int result_y = yCoord;
		return new Coordinate(result_x, result_y);
	}

	/**
	 * get x_coord
	 * 
	 * @return int
	 */
	public int getXCoord() {
		return xCoord;
	}

	/**
	 * set x_coord
	 * 
	 * @param x_coord (int)
	 */
	public void setXCoord(int xCoord) {
		this.xCoord = xCoord;
	}

	/**
	 * get y_coord
	 * 
	 * @return int
	 */
	public int getYCoord() {
		return yCoord;
	}

	/**
	 * set y_coord
	 * 
	 * @param y_coord (int)
	 */
	public void setYCoord(int yCoord) {
		this.yCoord = yCoord;
	}

	/**
	 * outputs all of both variables x_coord and y_coord
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return "[" + xCoord + ", " + yCoord + "]";
	}

	/**
	 * hashs with both variables
	 * 
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(xCoord, yCoord);
	}

	/**
	 * equals, only if x_coord and y_coord are equal
	 * 
	 * @return boolean
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		return xCoord == other.xCoord && yCoord == other.yCoord;
	}

	/**
	 * important for a possible ordering in a TreeMap.
	 * 
	 * Compares two Coordinates by firstly their x_coordinate and if equal secondly
	 * by their y_coordinate. Hereby -1 means o1 is smaller and early in a Map than
	 * o2. (Compares its two arguments for order. Returns a negative integer, zero,
	 * or a positive integer as the first argument is less than, equal to, or
	 * greater than the second. source:
	 * https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html#compare-T-T-)
	 * 
	 * @return int (-1,0,1)
	 */
	@Override
	public int compare(Coordinate o1, Coordinate o2) {
		if (o1 == null)
			return 1;
		if (o2 == null)
			return -1;
		if (o1.xCoord < o2.xCoord)
			return -1;
		if (o1.xCoord > o2.xCoord)
			return 1;
		else {
			if (o1.yCoord < o2.yCoord)
				return -1;
			if (o1.yCoord > o2.yCoord)
				return 1;
			return 0;
		}
	}

	@Override
	public int compareTo(Coordinate o) {
		return this.compare(this, o);
	}

}
