package game;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.GameMap;
import map.IServerMap;
import server.exceptions.PlayerInGameOverflowException;
import server.exceptions.PlayersNotFoundException;

/**
 * bundles all information about one game
 * 
 * @author Malte
 *
 */
public class GameInfo {

	private static Logger logger = LoggerFactory.getLogger(GameInfo.class);

	private GameID gameID;
	private LocalDateTime initGameDate;
	private MapRessource playerMaps;
	private IServerMap fullGameMap;
	private GameState gameState;

	public GameInfo(GameID gameID) {
		this.gameID = gameID;
		this.initGameDate = LocalDateTime.now();
		this.playerMaps = new MapRessource();
		this.fullGameMap = new GameMap();
		this.gameState = new GameState(true, false);

	}

	/**
	 * try to add player to local PlayerPair
	 * 
	 * @param player (not null)
	 */
	public void addPlayer(PlayerInfo player) {
		if (gameState.getPlayerPair().isFull()) {
			logger.error(DevMessage.mError(gameState.getPlayerPair().toString()));
			throw new PlayerInGameOverflowException("PlayerOverflow", "trying to add player "
					+ player.getPlayerID().getPlayerID()
					+ " failed because there are already two players registered in this game. Mayber bogus gameID?");
		}
		if (!gameState.isGameIsActive()) {
			logger.error(DevMessage.mError("trying to add a player could not be done because this game is inactive!"));
			throw new PlayerInGameOverflowException("GameIsInactive",
					"trying to add a player could not be done because this game is inactive!");
		}

		gameState.addPlayer(player);

		logger.debug(DevMessage.mDebug(gameState.getPlayerPair().toString()));
		gameState.updateActualGameStateUUID();
	}

	/**
	 * search for player with specific playerID
	 * 
	 * @param player (not null)
	 * @return PlayerInfo (might be null and must be checked outside)
	 */
	public PlayerInfo getPlayerByPlayerID(PlayerID player) {
		if (this.containsPlayer(player)) {
			return gameState.getPlayerPairByPlayerID(player);
		}
		return null;
	}

	/**
	 * checks whether a player is part of this pair
	 * 
	 * @param player (not null)
	 * @return boolean (true if part of this pair)
	 */
	public boolean containsPlayer(PlayerID player) {
		return gameState.getPlayerPair().containsPlayer(player);
	}

	/**
	 * adds players halfmap to playersmap-ressources, if both players added their
	 * map, than a fullmap is created automatically and this game is ready to start
	 * 
	 * @param gameHalfMap (not null)
	 * @param playerID    (not null, ID will be checked if valid for this game)
	 */
	public void addPlayersHalfMap(IServerMap gameHalfMap, PlayerID playerID) {

		// if player with playerID isn't found in this game
		if (!gameState.getPlayerPair().containsPlayer(playerID)) {
			logger.error(DevMessage.mError("Trying recieve a halfmap failed, because a player with ID: " + playerID
					+ " cannot match to this game: " + this.gameID + " with players: " + gameState.getPlayerPair()));
			throw new PlayersNotFoundException("PlayersHalfMapTransactionProblem",
					"Trying recieve a halfmap failed, because a player with ID: " + playerID
							+ " cannot match to this game: " + this.gameID + " with players: "
							+ gameState.getPlayerPair());
		}
		// if game is not active anymore
		if (!gameState.isGameIsActive()) {
			logger.error(DevMessage
					.mError("trying to add a player's half map could not be done because this game is inactive!"));
			throw new PlayerInGameOverflowException("GameIsInactive",
					"trying to add a player's half map could not be done because this game is inactive!");
		}

		if (!this.playerMaps.isReadyToJoinToFullMap()) {
			this.playerMaps.addPlayerHalfMap(gameHalfMap, playerID);
			gameState.setSendHalfMapFirst(playerID);
			gameState.switchGameTurn();
			fullGameMap = gameHalfMap;
		}
		// initialize map join
		if (this.playerMaps.isReadyToJoinToFullMap()) {
			fullGameMap = playerMaps.joinMapsRandomly();
			gameState.setGameReadyToStart(true);
			logger.debug(DevMessage.mDebug("A fullMap was created! Game now ready to start."));
		}
		gameState.updateActualGameStateUUID();
	}

	/**
	 * terminate game and sets looser and winner
	 * 
	 * @param looserPlayerID (not null)
	 */
	public void terminateGame(PlayerID looserPlayerID) {
		gameState.terminateGame(looserPlayerID);
		gameState.updateActualGameStateUUID();
	}

	/**
	 * ends game with no specific looser and winner
	 */
	public void endGame() {
		gameState.endGame();
		gameState.updateActualGameStateUUID();
	}

	/**
	 * @return boolean (true if game is ready to start and there is a valid full
	 *         game map)
	 */
	public boolean isGameReadyToStart() {
		return gameState.isGameReadyToStart();
	}

	/**
	 * formats initGameDate to time format "(dd.mm.yyyy|hh:mm:ss)"
	 * 
	 * @return String (not null)
	 */
	private String convertToTimeFormat() {
		return "(" + initGameDate.getDayOfMonth() + "." + initGameDate.getMonthValue() + "." + initGameDate.getYear()
				+ "|" + initGameDate.getHour() + ":"
				+ ((initGameDate.getMinute() < 10) ? "0" + initGameDate.getMinute() : initGameDate.getMinute()) + ":"
				+ initGameDate.getSecond() + ")";
	}

	public GameState getGameState() {
		return gameState;
	}

	public GameID getGameID() {
		return gameID;
	}

	public boolean isGameActive() {
		return gameState.isGameIsActive();
	}

	public LocalDateTime getInitGameDate() {
		return initGameDate;
	}

	public PlayerPair getPlayerPair() {
		return gameState.getPlayerPair();
	}

	public String getActualGameStateUUID() {
		return gameState.getActualGameStateUUID();
	}

	public int getRoundNumber() {
		return gameState.getRoundNumberHidePosition();
	}

	public IServerMap getFullGameMap() {
		return fullGameMap;
	}

	public MapRessource getPlayerMaps() {
		return playerMaps;
	}

	@Override
	public String toString() {
		return "GameInfo [gameID=" + gameID + ", initGameDate=" + this.convertToTimeFormat() + "]";
	}

}
