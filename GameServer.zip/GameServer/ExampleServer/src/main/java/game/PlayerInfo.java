package game;

import java.util.Objects;

/**
 * contains and bundles all necessary information regarding a single player
 * (basic information and game related information)
 * 
 * @author Malte
 *
 */
public class PlayerInfo {

	private final String studentFirstName;
	private final String studentLastName;
	private final String studentUAccount;
	private final PlayerID playerID;
	private boolean collectedTreasure;
	private EPlayerActualGameState playerGameState;

	/**
	 * @param studentFirstName
	 * @param studentLastName
	 * @param studentUAccount
	 * @param playerID
	 */
	public PlayerInfo(String studentFirstName, String studentLastName, String studentUAccount, PlayerID playerID) {
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.studentUAccount = studentUAccount;
		this.playerID = playerID;
		this.collectedTreasure = false;
		this.playerGameState = EPlayerActualGameState.MustWait;
	}

	/**
	 * @return the studentFirstName
	 */
	public String getStudentFirstName() {
		return studentFirstName;
	}

	/**
	 * @return the studentLastName
	 */
	public String getStudentLastName() {
		return studentLastName;
	}

	/**
	 * @return the studentUAccount
	 */
	public String getStudentUAccount() {
		return studentUAccount;
	}

	/**
	 * @return the playerID
	 */
	public PlayerID getPlayerID() {
		return playerID;
	}

	public boolean hasCollectedTreasure() {
		return collectedTreasure;
	}

	public EPlayerActualGameState getPlayerGameState() {
		return playerGameState;
	}

	public void setPlayerGameState(EPlayerActualGameState playerGameState) {
		this.playerGameState = playerGameState;
	}

	@Override
	public int hashCode() {
		return Objects.hash(playerID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlayerInfo other = (PlayerInfo) obj;
		return playerID.equals(other.playerID);
	}

	@Override
	public String toString() {
		return "PlayerInfo [studentFirstName=" + studentFirstName + ", studentLastName=" + studentLastName
				+ ", studentUAccount=" + studentUAccount + ", playerID=" + playerID + ", collectedTreasure="
				+ collectedTreasure + ", playerGameState=" + playerGameState + "]";
	}

}
