package game;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import map.IServerMap;
import ruleValidation.IRule;
import ruleValidation.RuleDontSendPlayerHalfMapTwice;
import ruleValidation.RuleGameIsExisting;
import ruleValidation.RuleIsPlayersTurn;
import ruleValidation.RuleMapFortSetOnGras;
import ruleValidation.RuleMapHasCorrectDimensionAndCoordinates;
import ruleValidation.RuleMapHasFort;
import ruleValidation.RuleMapHasNoIslands;
import ruleValidation.RuleMapNotToMuchWaterfieldOnEdges;
import ruleValidation.RuleMapRightSizeOfHalfMap;
import ruleValidation.RuleMapRightTerrainAmount;
import ruleValidation.RulePlayerIsExisting;
import server.exceptions.GenericServerException;

/**
 * responsible for handling all games running on this server, process
 * information regarding games and also checking basic and business rules
 * 
 * @author Malte
 *
 */
public class GameController {

	private static Logger logger = LoggerFactory.getLogger(GameController.class);

	private static final int MAX_GAMES = 99;

	private Map<GameID, GameInfo> actualGames;

	private List<PlayerID> playerHalfMapsRegistrations;

	private List<IRule> rules;

	public GameController() {
		this.actualGames = new HashMap<>();
		this.rules = new ArrayList<>();
		this.playerHalfMapsRegistrations = new ArrayList<>();
		this.initializeRules();
	}

	/**
	 * intilialize all basic and business-rules
	 */
	private void initializeRules() {
		rules.add(new RuleGameIsExisting());
		rules.add(new RulePlayerIsExisting());
		rules.add(new RuleDontSendPlayerHalfMapTwice());
		rules.add(new RuleIsPlayersTurn());
		rules.add(new RuleMapHasCorrectDimensionAndCoordinates());
		rules.add(new RuleMapHasFort());
		rules.add(new RuleMapFortSetOnGras());
		rules.add(new RuleMapRightTerrainAmount());
		rules.add(new RuleMapRightSizeOfHalfMap());
		rules.add(new RuleMapNotToMuchWaterfieldOnEdges());
		rules.add(new RuleMapHasNoIslands());
	}

	/**
	 * FIRST ENDPOINT: generates a new game with a unique gameID
	 * 
	 * @return GameID (not null)
	 */
	public GameID startGame() {
		this.eraseGamesOlderThan10Minutes();
		if (MAX_GAMES <= actualGames.size()) {
			this.eraseOldestGame();
		}
		GameID gameID = new GameID();
		while (actualGames.containsKey(gameID)) {
			logger.warn(DevMessage.mError("Warning: gameID " + gameID + " has already been used."));
			gameID.generateNewGameId();
		}
		GameInfo newGame = new GameInfo(gameID);
		actualGames.put(newGame.getGameID(), newGame);
		logger.debug(DevMessage.mDebug("New game was created: " + newGame));

		return gameID;
	}

	/**
	 * SECOND ENDPOINT: register a player with an gameID by first check, whether
	 * gameID exists and so is valid and if so than add player to actualGames
	 * 
	 * @param gameID (not null)
	 * @param player (not null)
	 */
	public void registerPlayer(GameID gameID, PlayerInfo player) {
		this.eraseGamesOlderThan10Minutes();
		logger.debug(DevMessage.mDebug("try to register player :" + player.getPlayerID() + " in game: " + gameID));
		// [1] check if there is a game like gameID
		for (IRule rule : rules) {
			rule.checkRuleGameIsExisting(gameID, actualGames);
		}

		// [2] put player into one of those games
		this.putPlayerIntoGame(gameID, player);
	}

	/**
	 * THIRD ENDPOINT: register players half map with gameID, playerID and a
	 * gameHalfMap. Here there will be especially the half map checked against
	 * several business rules
	 * 
	 * @param gameID      (not null)
	 * @param playerID    (not null)
	 * @param gameHalfMap (not null)
	 * @return BundleAnswerRegisterPlayerHalfMap (not null)
	 */
	public BundleAnswerRegisterPlayerHalfMap registerPlayerHalfMap(GameID gameID, PlayerID playerID,
			IServerMap gameHalfMap) {
		this.eraseGamesOlderThan10Minutes();
		logger.debug(DevMessage.markGreen("HalfMap of player " + playerID + " is going to be added."));
		playerHalfMapsRegistrations.add(playerID);
		// [1] check all business rules
		try {
			for (IRule rule : rules) {
				rule.checkRuleGameIsExisting(gameID, actualGames);
				rule.checkRulePlayerIsExisting(playerID, actualGames);
				rule.checkRuleDontSendPlayerHalfMapTwice(playerID, playerHalfMapsRegistrations);
				rule.checkRuleIfItIsPlayersTurn(playerID, actualGames);
				rule.checkRuleMapRightSizeOfHalfMap(gameHalfMap);
				rule.checkRuleMapHasCorrectDimensionAndCoordinates(gameHalfMap);
				rule.checkRuleMapHasFort(gameHalfMap);
				rule.checkRuleMapFortSetOnGras(gameHalfMap);
				rule.checkRuleMapRightTerrainAmount(gameHalfMap);
				rule.checkRuleMapNotToMuchWaterfieldOnEdges(gameHalfMap);
				rule.checkRuleMapHasNoIslands(gameHalfMap);
			}
		} catch (GenericServerException e) {
			logger.error(DevMessage.mError("terminate game with reason: " + e.getMessage()));
			this.terminateGame(gameID, playerID);
			throw e;
		}
		// [2] assemble all data for answer
		GameInfo actualGame = this.getGameByID(gameID);
		actualGame.addPlayersHalfMap(gameHalfMap, playerID);
		String actualGameStateUUID = actualGame.getActualGameStateUUID();
		PlayerInfo gameStateForPlayer = actualGame.getPlayerByPlayerID(playerID);

		return new BundleAnswerRegisterPlayerHalfMap(actualGameStateUUID, gameStateForPlayer);
	}

	/**
	 * FOURTH ENDPOINT: process a game-state request and returns an answer as bundle
	 * consist of (fullGameMap, actualGamePlayerPair, gameStateUUID, playerID,
	 * roundNumberHidePosition)
	 * 
	 * @param gameID   (not null)
	 * @param playerID (not null)
	 * @return BundleAnswerGameState (not null)
	 */
	public BundleAnswerGameState processGameState(GameID gameID, PlayerID playerID) {
		this.eraseGamesOlderThan10Minutes();
		// [1] check basic rules
		for (IRule rule : rules) {
			rule.checkRuleGameIsExisting(gameID, actualGames);
			rule.checkRulePlayerIsExisting(playerID, actualGames);
		}

		// [2] collect 3 information: gameMap, gameID, Collection<PlayerState> players
		GameInfo actualGame = this.getGameByID(gameID);
		IServerMap fullGameMap = actualGame.getFullGameMap();
		PlayerPair actualGamePlayerPair = actualGame.getPlayerPair();
		String gameStateUUID = actualGame.getActualGameStateUUID();
		int roundNumberHidePosition = actualGame.getRoundNumber();

		if (actualGamePlayerPair.getPlayer1() != null
				&& (actualGamePlayerPair.getPlayer1().getPlayerGameState() == EPlayerActualGameState.Lost
						|| actualGamePlayerPair.getPlayer1().getPlayerGameState() == EPlayerActualGameState.Won)) {
			logger.debug(DevMessage.mDebug("GAMESTATE: " + actualGamePlayerPair.getPlayer1().getPlayerGameState()));
		}
		if (actualGamePlayerPair.getPlayer2() != null
				&& (actualGamePlayerPair.getPlayer2().getPlayerGameState() == EPlayerActualGameState.Lost
						|| actualGamePlayerPair.getPlayer2().getPlayerGameState() == EPlayerActualGameState.Won)) {
			logger.debug(DevMessage.mDebug("GAMESTATE: " + actualGamePlayerPair.getPlayer2().getPlayerGameState()));
		}

		return new BundleAnswerGameState(fullGameMap, actualGamePlayerPair, gameStateUUID, playerID,
				roundNumberHidePosition);

	}

	/**
	 * terminates a given game and decides, who is the looser and who the winner
	 * 
	 * @param gameID   (not null)
	 * @param playerID (not null)
	 */
	private void terminateGame(GameID gameID, PlayerID playerID) {
		GameInfo actualGame = this.getGameByID(gameID);
		if (actualGame != null && actualGame.isGameActive()) {
			actualGame.terminateGame(playerID);
		}
	}

	/**
	 * retrieves a game (GameInfo) by given gameID from actualGames
	 * 
	 * @param gameID (not null)
	 * @return GameInfo (might be null, if a game with given gameID does not exists
	 *         in actualGames
	 */
	private GameInfo getGameByID(GameID gameID) {
		for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
			if (game.getKey().equals(gameID)) {
				return game.getValue();
			}
		}
		return null;
	}

	/**
	 * puts a player with correct gameID into specifiv (gameID) game
	 * 
	 * @param gameID (is already checked and not null)
	 * @param player (not null)
	 */
	private void putPlayerIntoGame(GameID gameID, PlayerInfo player) {
		for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
			if (game.getKey().equals(gameID)) {
				game.getValue().addPlayer(player);
			}
		}
	}

	/**
	 * erase game from actualGames and also end this game (regarding status)
	 * 
	 * @param gameID (not null)
	 */
	public void eraseGameFromMap(GameID gameID) {
		int sizebefore = actualGames.size();
		GameInfo actualGame = this.getGameByID(gameID);
		actualGame.endGame();
		actualGames.remove(gameID);
		logger.debug(DevMessage.markRed("Game with ID: " + gameID + " was erased from actualGames. Size before: "
				+ sizebefore + ", Size after: " + actualGames.size()));
	}

	/**
	 * first finds oldest game and than removes it from this actualGames-Map and
	 * also end this game (regarding status)
	 */
	private void eraseOldestGame() {
		GameID oldestGameID = this.findOldestGame();
		if (actualGames != null && actualGames.size() > 0) {
			GameInfo actualGame = this.getGameByID(oldestGameID);
			actualGame.endGame();
			actualGames.remove(oldestGameID);
		}
	}

	/**
	 * finds oldest game in actualGames-Map
	 * 
	 * @return GameID (not null)
	 */
	private GameID findOldestGame() {
		GameID oldestGameID = null;
		LocalDateTime oldestInitGameDate = null;

		for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
			GameID gameId = game.getKey();
			GameInfo actualGame = game.getValue();
			LocalDateTime initGameDate = actualGame.getInitGameDate();

			if (oldestInitGameDate == null || initGameDate.isBefore(oldestInitGameDate)) {
				oldestGameID = gameId;
				oldestInitGameDate = initGameDate;
			}
		}
		return oldestGameID;
	}

	/**
	 * erase game which is older than 10 minutes after activation
	 */
	public void eraseGamesOlderThan10Minutes() {
		LocalDateTime now = LocalDateTime.now();

		List<GameID> tooOldGames = new ArrayList<>();
		for (Map.Entry<GameID, GameInfo> game : actualGames.entrySet()) {
			LocalDateTime gamesOlderThan10Minutes = game.getValue().getInitGameDate().plusMinutes(10);
			if (gamesOlderThan10Minutes.isBefore(now)) {
				tooOldGames.add(game.getKey());
			}
		}

		for (var game : tooOldGames) {
			this.eraseGameFromMap(game);
		}
	}

}
