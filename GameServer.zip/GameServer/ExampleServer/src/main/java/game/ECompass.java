package game;

/**
 * gives general orientation on a map (important for
 * map.compareECompassWithPlayersPosition())
 * 
 * @author Malte
 *
 */
public enum ECompass {
	North, South, East, West
}
