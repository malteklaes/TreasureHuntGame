package game;

/**
 * organize what a player is actually about when requesting its state
 * 
 * @author Malte
 *
 */
public enum EPlayerActualGameState {
	Won, Lost, MustAct, MustWait;

}
