package game;

/**
 * tracks where the players are in the fullGame map
 * 
 * @author Malte
 *
 */
public enum EPlayersPositionOnFullGameMap {
	SquareFirstPlayerNorth, SquareFirstPlayerSouth, RectangleFirstPlayerEast, RectangleFirstPlayerWest, NoPositioning
}
