package game;

/**
 * bundles information (actualGameStateUUID, playerInfo) to set state as anwer,
 * when client sends half map
 * 
 * @author Malte
 *
 */
public class BundleAnswerRegisterPlayerHalfMap {

	private String actualGameStateUUID;
	private PlayerInfo playerInfo;

	/**
	 * @param actualGameStateUUID
	 * @param playerInfo
	 */
	public BundleAnswerRegisterPlayerHalfMap(String actualGameStateUUID, PlayerInfo playerInfo) {
		super();
		this.actualGameStateUUID = actualGameStateUUID;
		this.playerInfo = playerInfo;
	}

	/**
	 * @return the actualGameStateUUID
	 */
	public String getActualGameStateUUID() {
		return actualGameStateUUID;
	}

	/**
	 * @return the playerInfo
	 */
	public PlayerInfo getPlayerInfo() {
		return playerInfo;
	}

	@Override
	public String toString() {
		return "BundleAnswerRegisterPlayerHalfMap [actualGameStateUUID=" + actualGameStateUUID + ", playerInfo="
				+ playerInfo + "]";
	}

}
