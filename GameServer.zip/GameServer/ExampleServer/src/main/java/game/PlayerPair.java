package game;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * bundles two players to a pair (as datastructur)
 * 
 * @author Malte
 *
 */
public class PlayerPair {

	private static Logger logger = LoggerFactory.getLogger(PlayerPair.class);

	private PlayerInfo[] playerPair;

	public PlayerPair() {
		this.playerPair = new PlayerInfo[2];
	}

	/**
	 * adds player to PlayerPair and updates players game state (MustAct)
	 * 
	 * @param player (not null)
	 * @return should always be true since there is an unique gameID
	 */
	public boolean addPlayer(PlayerInfo player) {
		if (playerPair[0] == null) {
			playerPair[0] = player;
			return true;
		} else if (playerPair[1] == null) {
			playerPair[1] = player;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * checks whether a player is part of this pair
	 * 
	 * @param player (not null)
	 * @return boolean (true if part of this pair)
	 */
	public boolean containsPlayer(PlayerID player) {
		if (playerPair[0] == null && playerPair[1] == null)
			return false;
		if (playerPair[0] != null && playerPair[0].getPlayerID().equals(player))
			return true;
		else if (playerPair[1] != null && playerPair[1].getPlayerID().equals(player))
			return true;
		else
			return false;
	}

	/**
	 * get first player
	 * 
	 * @return (might be null and must be checked outside, scenario: game has just
	 *         been started and player is about to added to this game)
	 */
	public PlayerInfo getPlayer1() {
		if (playerPair[0] != null) {
			return playerPair[0];
		}
		return null;
	}

	/**
	 * get second player
	 * 
	 * @return (might be null and must be checked outside)
	 */
	public PlayerInfo getPlayer2() {
		if (playerPair[1] != null) {
			return playerPair[1];
		}
		return null;
	}

	/**
	 * search for player with specific playerID
	 * 
	 * @param player (not null)
	 * @return PlayerInfo (might be null and must be checked outside, scenario: game
	 *         has just been started and player is about to added to this game)
	 */
	public PlayerInfo getPlayerByPlayerID(PlayerID player) {
		if (playerPair[0] != null && playerPair[0].getPlayerID().equals(player))
			return playerPair[0];
		else if (playerPair[1] != null && playerPair[1].getPlayerID().equals(player))
			return playerPair[1];
		else
			return null;
	}

	/**
	 * sets the gameState for a specific player
	 * 
	 * @param playerID    (not null)
	 * @param playerState (not null)
	 */
	public void updatePlayerGameState(PlayerID playerID, EPlayerActualGameState playerState) {
		if (playerPair[0] != null)
			playerPair[0].setPlayerGameState(playerState);
		else if (playerPair[1] != null)
			playerPair[1].setPlayerGameState(playerState);
	}

	/**
	 * checks if pair is already filled
	 * 
	 * @return true (if filled)
	 */
	public boolean isFull() {
		return ((playerPair[0] != null) && (playerPair[1] != null));
	}

	/**
	 * converts the player-Array to a List-structure
	 * 
	 * @return List<PlayerInfo> (not null)
	 */
	public List<PlayerInfo> toList() {
		List<PlayerInfo> playersToList = new ArrayList<>();
		if (playerPair[0] != null) {
			playersToList.add(playerPair[0]);
		}
		if (playerPair[1] != null) {
			playersToList.add(playerPair[1]);
		}
		return playersToList;
	}

	@Override
	public String toString() {
		String player1 = (playerPair[0] == null) ? " - " : playerPair[0].getPlayerID().getPlayerID();
		String player2 = (playerPair[1] == null) ? " - " : playerPair[1].getPlayerID().getPlayerID();
		return "PlayerPair [player1=" + player1 + " : player2=" + player2 + "]";
	}

}
