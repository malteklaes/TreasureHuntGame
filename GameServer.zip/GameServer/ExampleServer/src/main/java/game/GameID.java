package game;

import java.util.Objects;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;

/**
 * makes a game (GameInfo) unique, has 5 characters at all and consists of both
 * characters and numbers
 * 
 * @author Malte
 *
 */
public class GameID {

	private static Logger logger = LoggerFactory.getLogger(GameID.class);

	private final String CHARACTERS_RESSOURCE = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	private final int GAME_ID_LENGTH = 5;

	private String gameID;

	public GameID() {
		this.generateNewGameId();
	};

	/**
	 * 
	 * @param gameID
	 */
	public GameID(String gameID) {
		this.gameID = gameID;
	}

	/**
	 * generates new and unique gameID with max. length of 5 characters and consists
	 * of lower and upper letters (a-z,A-Z) and numbers 0-9
	 * 
	 * @return String not null
	 */
	public String generateNewGameId() {
		StringBuilder gameID = new StringBuilder(GAME_ID_LENGTH);
		Random random = new Random();

		for (int i = 0; i < GAME_ID_LENGTH; i++) {
			int randomIndex = random.nextInt(CHARACTERS_RESSOURCE.length());
			char randomChar = CHARACTERS_RESSOURCE.charAt(randomIndex);
			gameID.append(randomChar);
		}
		this.gameID = gameID.toString();
		return this.gameID;
	}

	/**
	 * checks if given gameID has right size
	 * 
	 * @param gameID (not null)
	 * @return GameID (not null)
	 */
	public GameID checkCorrectGameID(String gameID) {
		if (gameID.length() == GAME_ID_LENGTH) {
			logger.error(DevMessage.mError("Wrong size!"));
			throw new IllegalArgumentException("Wrong size!");
		}
		return new GameID(gameID);
	}

	public String getGameID() {
		return gameID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(gameID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GameID other = (GameID) obj;
		return Objects.equals(gameID, other.gameID) && this.gameID.equals(other.getGameID());
	}

	@Override
	public String toString() {
		return "GameID [" + gameID + "]";
	}

}
