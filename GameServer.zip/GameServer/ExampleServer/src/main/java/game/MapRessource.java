package game;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import map.GameMap;
import map.IServerMap;

/**
 * bundles all information regarding halfMap of both players and also generates
 * a fullgamemap
 * 
 * @author Malte
 *
 */
public class MapRessource {

	private static Logger logger = LoggerFactory.getLogger(MapRessource.class);

	private IServerMap[] playersHalfMaps;
	private PlayerID[] playersIDOfHalfMaps;
	private EPlayersPositionOnFullGameMap playersPosition;

	public MapRessource() {
		this.playersHalfMaps = new IServerMap[2];
		this.playersIDOfHalfMaps = new PlayerID[2];
		this.playersPosition = EPlayersPositionOnFullGameMap.NoPositioning;
	}

	/**
	 * adds players halfmap and player itself to MapRessource
	 * 
	 * @param playerHalfMap (not null)
	 * @param player        (not null)
	 * @return true (if playerHalfMap and player can be added)
	 */
	public boolean addPlayerHalfMap(IServerMap playerHalfMap, PlayerID player) {
		if (playersHalfMaps[0] == null) {
			playersHalfMaps[0] = playerHalfMap;
			playersIDOfHalfMaps[0] = player;
			return true;
		} else if (playersHalfMaps[1] == null) {
			playersHalfMaps[1] = playerHalfMap;
			playersIDOfHalfMaps[1] = player;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * checks whether this map ressource contains a given gamemap
	 * 
	 * @param otherGameMap (not null)
	 * @return true (if given map is contained)
	 */
	public boolean containsMap(IServerMap otherGameMap) {
		if (playersHalfMaps[0] != null) {
			if (playersHalfMaps[0].equals(otherGameMap))
				return true;
		} else if (playersHalfMaps[1] != null) {
			if (playersHalfMaps[1].equals(otherGameMap))
				return true;
		}
		return false;
	}

	/**
	 * checks if both halfmaps are avaible and so is ready to join them to one
	 * fullgamemap
	 * 
	 * @return true (if filled)
	 */
	public boolean isReadyToJoinToFullMap() {
		return ((playersHalfMaps[0] != null) && (playersHalfMaps[1] != null));
	}

	/**
	 * joins the maps this ressource contains randomly on one of the edges (4
	 * possibilities)
	 * 
	 * @return IServerMap (not null)
	 */
	public IServerMap joinMapsRandomly() {
		int joinDirectionVariants = 4;
		int randomDirectionChoice = new Random().nextInt(joinDirectionVariants);
		switch (randomDirectionChoice) {
		case 0:
			this.playersPosition = EPlayersPositionOnFullGameMap.SquareFirstPlayerSouth;
			return new GameMap().joinMapsRandomly(playersHalfMaps, playersIDOfHalfMaps, this.playersPosition);
		case 1:
			this.playersPosition = EPlayersPositionOnFullGameMap.SquareFirstPlayerNorth;
			return new GameMap().joinMapsRandomly(playersHalfMaps, playersIDOfHalfMaps, this.playersPosition);
		case 2:
			this.playersPosition = EPlayersPositionOnFullGameMap.RectangleFirstPlayerWest;
			return new GameMap().joinMapsRandomly(playersHalfMaps, playersIDOfHalfMaps, this.playersPosition);
		default:
			this.playersPosition = EPlayersPositionOnFullGameMap.RectangleFirstPlayerEast;
			return new GameMap().joinMapsRandomly(playersHalfMaps, playersIDOfHalfMaps, this.playersPosition);
		}
	}

	/**
	 * get first halfMap
	 * 
	 * @return IServerMap (might be null and must be checked)
	 */
	public IServerMap getHalfMap1() {
		return playersHalfMaps[0];
	}

	/**
	 * get second halfMap
	 * 
	 * @return IServerMap (might be null and must be checked)
	 */
	public IServerMap getHalfMap2() {
		return playersHalfMaps[1];
	}

}
