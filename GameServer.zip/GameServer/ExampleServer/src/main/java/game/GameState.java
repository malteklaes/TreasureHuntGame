package game;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import devTools.DevMessage;
import network.ServerDataConverter;

/**
 * organize everything gamestate-related for a specific game like if this game
 * is active, if it is ready to start and organize the turns of the two players
 * of this game and also mainly manages both players
 * 
 * @author Malte
 *
 */
public class GameState {

	private static Logger logger = LoggerFactory.getLogger(GameState.class);

	private boolean gameIsActive;
	private boolean gameReadyToStart;
	private String actualGameStateUUID = "";
	private PlayerID sendHalfMapFirst;
	private boolean alreadyRecordedFirstHalfMap;
	private PlayerID gameTurn;
	private PlayerPair playerPair;
	private int roundNumberHidePosition;

	public GameState(boolean gameIsActive, boolean gameReadyToStart) {
		this.gameIsActive = gameIsActive;
		this.gameReadyToStart = gameReadyToStart;
		this.alreadyRecordedFirstHalfMap = false;
		this.playerPair = new PlayerPair();
		this.updateActualGameStateUUID();
		int businessRuleHowLongEnemysPositionHasToBeHidden = 16;
		this.roundNumberHidePosition = businessRuleHowLongEnemysPositionHasToBeHidden;
	}

	/**
	 * choose randomly which player's turn it is
	 */
	public void setInitialRandomGameTurn() {
		int headOrTails = new Random().nextInt(2) + 1;
		switch (headOrTails) {
		case 1:
			gameTurn = playerPair.getPlayer1().getPlayerID();
			playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustAct);
			playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustWait);
			break;
		default:
			gameTurn = playerPair.getPlayer2().getPlayerID();
			playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustWait);
			playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustAct);
			break;
		}
	}

	/**
	 * switch player's turn
	 */
	public void switchGameTurn() {
		if (playerPair.getPlayer1() != null && playerPair.getPlayer2() != null) {
			if (gameTurn == playerPair.getPlayer1().getPlayerID()) {
				gameTurn = playerPair.getPlayer2().getPlayerID();
				playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustWait);
				playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustAct);
			} else {
				gameTurn = playerPair.getPlayer1().getPlayerID();
				playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustAct);
				playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustWait);
			}
		}
	}

	/**
	 * precondition: both players have already send their halfmaps
	 */
	public void letFirstPlayerAct() {
		if (playerPair.getPlayer1() != null && playerPair.getPlayer2() != null) {
			if (sendHalfMapFirst == playerPair.getPlayer1().getPlayerID()) {
				gameTurn = playerPair.getPlayer1().getPlayerID();
				playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustAct);
				playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustWait);
			} else {
				gameTurn = playerPair.getPlayer2().getPlayerID();
				playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustWait);
				playerPair.getPlayer2().setPlayerGameState(EPlayerActualGameState.MustAct);
			}
		}
	}

	/**
	 * produces a new gameState UUID, when something in this game has changed to
	 * mark this change. UUID is a 5-block Codestring consisting of both numbers and
	 * lowercase characters, where the first and last block contains 8 characters
	 * and the three middle blocks 4 characters (e.g.
	 * 4caf3f41-306a-4248-9ecb-377572e4eab1)
	 */
	public void updateActualGameStateUUID() {
		this.actualGameStateUUID = ServerDataConverter.createNewRandomGameStateUUID();
	}

	/**
	 * add player to this gameState (either player1 is "free" or player2)
	 * 
	 * @param player (not null)
	 * @return true (if player was added, false, if there hasn't be room for
	 *         incoming player)
	 */
	public boolean addPlayer(PlayerInfo player) {
		if (playerPair.getPlayer1() == null) {
			this.playerPair.addPlayer(player);
			playerPair.getPlayer1().setPlayerGameState(EPlayerActualGameState.MustWait);
			return true;
		} else if (playerPair.getPlayer2() == null) {
			this.playerPair.addPlayer(player);
			this.setInitialRandomGameTurn();
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @return the gameIsActive
	 */
	public boolean isGameIsActive() {
		return gameIsActive;
	}

	/**
	 * terminates game, where given player is looser and other player is winner
	 * 
	 * @param looserPlayerID (not null)
	 */
	public void terminateGame(PlayerID looserPlayerID) {
		logger.debug(DevMessage.mDebug("GAME HAS TERMINATED with looserID: " + looserPlayerID));
		gameIsActive = false;
		if (this.getPlayerPairByPlayerID(looserPlayerID) != null)
			this.getPlayerPairByPlayerID(looserPlayerID).setPlayerGameState(EPlayerActualGameState.Lost);
		if (this.getOtherPlayer(looserPlayerID) != null)
			this.getOtherPlayer(looserPlayerID).setPlayerGameState(EPlayerActualGameState.Won);
		logger.debug(DevMessage.mDebug("LOOSER: " + this.playerPair.getPlayer1()));
		logger.debug(DevMessage.mDebug("WINNER: " + this.playerPair.getPlayer2()));
	}

	/**
	 * end game by setting gameIsActive to false
	 */
	public void endGame() {
		logger.debug(DevMessage.mDebug("Game has ended."));
		gameIsActive = false;
	}

	/**
	 * @return true (if game is ready to start)
	 */
	public boolean isGameReadyToStart() {
		return gameReadyToStart;
	}

	public void setGameReadyToStart(boolean gameReadyToStart) {
		this.gameReadyToStart = gameReadyToStart;
	}

	public void setSendHalfMapFirst(PlayerID sendHalfMapFirst) {
		if (!alreadyRecordedFirstHalfMap) {
			this.sendHalfMapFirst = sendHalfMapFirst;
			alreadyRecordedFirstHalfMap = true;
		}
	}

	public String getActualGameStateUUID() {
		return actualGameStateUUID;
	}

	public PlayerID getGameTurn() {
		return gameTurn;
	}

	public PlayerPair getPlayerPair() {
		return playerPair;
	}

	/**
	 * search for player with specific playerID
	 * 
	 * @param player (not null)
	 * @return PlayerInfo (might be null and must be checked outside)
	 */
	public PlayerInfo getPlayerPairByPlayerID(PlayerID playerID) {
		return playerPair.getPlayerByPlayerID(playerID);
	}

	/**
	 * returns the other player than what is given as playerID
	 * 
	 * @param playerID (not null)
	 * @return PlayerInfo (might be null, if player does not exist)
	 */
	public PlayerInfo getOtherPlayer(PlayerID playerIDParam) {
		if (playerPair.getPlayer1() != null && !playerIDParam.equals(playerPair.getPlayer1().getPlayerID())) {
			return playerPair.getPlayer1();
		} else if (playerPair.getPlayer2() != null && !playerIDParam.equals(playerPair.getPlayer2().getPlayerID())) {
			return playerPair.getPlayer2();
		} else {
			return null;
		}
	}

	public int getRoundNumberHidePosition() {
		return roundNumberHidePosition;
	}

}
