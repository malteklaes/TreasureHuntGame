package game;

import java.util.Objects;

/**
 * defines an unique PlayerID like "702ecdb6-b363-462c-a63a-5d0a39222c4e" which
 * consists of lowercase characters and numbers
 * 
 * @author Malte
 *
 */
public class PlayerID {

	private String playerID;

	public PlayerID(String playerID) {
		this.playerID = playerID;
	}

	public PlayerID(PlayerID playerID) {
		this.playerID = playerID.getPlayerID();
	}

	public String getPlayerID() {
		return playerID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(playerID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlayerID other = (PlayerID) obj;
		return Objects.equals(playerID, other.playerID) && this.playerID.equals(other.getPlayerID());
	}

	@Override
	public String toString() {
		return "PlayerID [playerID=" + playerID + "]";
	}

}
