package game;

import map.IServerMap;

/**
 * bundles all necessary information (full game-map, players, gameID) to answer
 * the game state properly
 * 
 * @author Malte
 *
 */
public class BundleAnswerGameState {

	private IServerMap fullGameMap;
	private PlayerPair playerPair;
	private String gameStateUUID;
	private PlayerID playerID;
	private int roundNumberHidePosition;

	/**
	 * @param fullGameMap
	 * @param playerPair
	 * @param gameID
	 */
	public BundleAnswerGameState(IServerMap fullGameMap, PlayerPair playerPair, String gameStateUUID, PlayerID playerID,
			int roundNumberHidePosition) {
		this.fullGameMap = fullGameMap;
		this.playerPair = playerPair;
		this.gameStateUUID = gameStateUUID;
		this.playerID = playerID;
		this.roundNumberHidePosition = roundNumberHidePosition;
	}

	/**
	 * @return the fullGameMap
	 */
	public IServerMap getFullGameMap() {
		return fullGameMap;
	}

	/**
	 * @return the playerPair
	 */
	public PlayerPair getPlayerPair() {
		return playerPair;
	}

	/**
	 * @return the gameStateUUID
	 */
	public String getGameStateUUID() {
		return gameStateUUID;
	}

	/**
	 * @return the playerID
	 */
	public PlayerID getPlayerID() {
		return playerID;
	}

	public int getRoundNumberHidePosition() {
		return roundNumberHidePosition;
	}

}
